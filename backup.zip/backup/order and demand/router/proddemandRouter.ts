import express from 'express';
import { Request, Response, NextFunction } from "express";
import { allProductionDemands, approvedList, createProductionDemand, deletetProductionDemand, demandReport, demandsFrmEachDiv, editDemand, editProductionDemand, getDemandsByShift, getDemandsFromAllDivs, searchByDate, shiftList, supplyProduction, supplyProductionFromPc, updateReceivedItem, reportDemandDetail, receivedDemandList, productDemandHistory } from "../controller/productionDemandController";
import { firebaseValidation } from "../middleware/firebaseValidation";
import { approvalMgmt, demandMgmt, loadInMgmt, reportMgmt } from "../middleware/userValidation";
import { userAccess } from "../middleware/userAccessValidation";
import { generateResponse } from "../utils/responseGenerate";
import { error } from "../config/loggerConfig";

export const prodDemand = express.Router();

let accessValidation : any;

async function demandAccess(req: Request, res: Response, next: NextFunction){
    if((req as any).firebaseData.uid.includes("orgOwner")){
        next();
    }
    else if((req as any).firebaseData.uid.includes("orgAd") || (req as any).firebaseData.uid.includes("divM") || (req as any).firebaseData.uid.includes("divS")){
        accessValidation = "RD";
        userAccess(accessValidation) (req, res, next);
    }
    else{
        error.error(`demandAccess unauthorised user`);
        return res.status(401).json(generateResponse("Unauthorised user", 401, "Failed"));
    }
}

async function tpMainCheck(req: Request, res: Response, next: NextFunction){
    if(req.body.isMain)
    {
        next();
    }
    else{
        error.error(`tpMainCheck unauthorised user`);
        res.status(401).json(generateResponse("Unauthorised user", 401, "Failed"));
    }
}

async function tpDivCheck(req: Request, res: Response, next: NextFunction){
    if(!req.body.main)
    {
        next();
    }
    else{
        error.error(`tpDivCheck unauthorised user`);
        res.status(401).json(generateResponse("Unauthorised user", 401, "Failed"));
    }
}

prodDemand.post("/create",firebaseValidation, demandMgmt, demandAccess,  createProductionDemand);
prodDemand.put("/edit/:itemId", firebaseValidation, demandMgmt, demandAccess, editProductionDemand);
prodDemand.put("/delete/:id", firebaseValidation, demandMgmt, demandAccess, deletetProductionDemand);
prodDemand.get("/all", firebaseValidation, demandMgmt, demandAccess, allProductionDemands);
prodDemand.get("/searchByDate", firebaseValidation,demandMgmt, demandAccess, searchByDate); 


// approval apis
prodDemand.get("/shiftList", firebaseValidation, approvalMgmt, userAccess("prodA"), shiftList);
prodDemand.get("/getDemandsByShift", firebaseValidation, approvalMgmt, userAccess("prodA"), getDemandsByShift);
prodDemand.get("/getDemandsFromAllDivs/:id", firebaseValidation, approvalMgmt, userAccess("prodA"), getDemandsFromAllDivs);
prodDemand.get("/demandsFrmEachDiv",  firebaseValidation, approvalMgmt, userAccess("prodA"), demandsFrmEachDiv);
prodDemand.post("/approvalEdit", firebaseValidation, approvalMgmt, userAccess("prodA"), editDemand);

prodDemand.get("/approvedList", firebaseValidation, loadInMgmt, tpMainCheck, approvedList);
prodDemand.put("/verifyByPc/:id", firebaseValidation, loadInMgmt, tpMainCheck, supplyProductionFromPc);
prodDemand.put("/receivedItem/:id", firebaseValidation, loadInMgmt, tpDivCheck, updateReceivedItem);

// report
prodDemand.get("/report/:id", firebaseValidation, reportMgmt, userAccess("workstation"),  demandReport);

// Report demands list
prodDemand.get("/prcedureReport", firebaseValidation, reportMgmt, userAccess("workstation"), reportDemandDetail);
prodDemand.get("/reportList",firebaseValidation, reportMgmt, userAccess("workstation"), receivedDemandList);
prodDemand.get("/history",productDemandHistory);