import express from 'express';
import { reportMgmt, userMgmt, wastageMgmt } from "../middleware/userValidation";
import { userAccess } from "../middleware/userAccessValidation";
import { firebaseValidation } from "../middleware/firebaseValidation";
import { createReusableWastage, editReusableWastage, deleteReusableWastage, getReusableWastage, reusableWastageReport } from "../controller/reusableWastageContoller";

export const reusableWastageRouter = express.Router();

reusableWastageRouter.post("/create", firebaseValidation, wastageMgmt, createReusableWastage);
reusableWastageRouter.put("/edit/:id", firebaseValidation, wastageMgmt, editReusableWastage);
reusableWastageRouter.delete("/delete/:id", firebaseValidation, wastageMgmt, deleteReusableWastage);
reusableWastageRouter.get("/any/:divId", firebaseValidation, wastageMgmt, getReusableWastage);
reusableWastageRouter.get("/report", firebaseValidation, reportMgmt, userAccess("workstation"), reusableWastageReport);