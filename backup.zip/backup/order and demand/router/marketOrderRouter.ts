import express from 'express';
import { Request, Response, NextFunction } from "express";
import { allMOrders, createMOrder, deleteMOrder, editMOrder, mOrderDelivered, mOrderStored, sUGetMOrder, sUGetMOrderDetail, sUMOrderList, tPCreateMOrder, tPGetMOrder, tPMOrderList, entryReport, itemEntryReport, itemEntryAndDelivery, itemPrice, sectionEntryReport, sUserCreateMOrder } from '../controller/marketOrderController';
import { firebaseValidation } from '../middleware/firebaseValidation';
import { loadInMgmt, loadOutAndInMgmt, mOrderMgmt, reportMgmt } from '../middleware/userValidation';
import { userAccess } from '../middleware/userAccessValidation';
import { generateResponse } from '../utils/responseGenerate';
import { error } from '../config/loggerConfig';

export const marketOrderRouter = express.Router();

async function tpMainCheck(req: Request, res: Response, next: NextFunction){
    if(req.body.isMain)
    {
        next();
    }
    else{
        error.error(`tpMainCheck unauthorised user`);
        res.status(401).json(generateResponse("Unauthorised user", 401, "Failed"));
    }
}

// gUser and admin
marketOrderRouter.post('/create', firebaseValidation, mOrderMgmt, userAccess("PMO"), createMOrder);
marketOrderRouter.get('/allList', firebaseValidation, mOrderMgmt, userAccess("PMO"), allMOrders);
marketOrderRouter.put('/edit/:id', firebaseValidation, mOrderMgmt, userAccess("PMO"), editMOrder);
marketOrderRouter.put('/delete/:id', firebaseValidation, mOrderMgmt, userAccess("PMO"), deleteMOrder);
marketOrderRouter.get('/sUser/list', firebaseValidation, mOrderMgmt, userAccess("PMO"), sUMOrderList);
marketOrderRouter.get('/sUser/getOne/:id', firebaseValidation, mOrderMgmt, userAccess("PMO"), sUGetMOrder);
marketOrderRouter.get('/sUser/getDetail/:id', firebaseValidation, mOrderMgmt, userAccess("PMO"), sUGetMOrderDetail);
marketOrderRouter.post('/sUser/create', firebaseValidation, mOrderMgmt, userAccess("PMO"), sUserCreateMOrder);  // verify if admin can create view market order

// only gUser
marketOrderRouter.put('/stored/:id', firebaseValidation, loadInMgmt, userAccess("PMO"), mOrderStored);

//tp user
marketOrderRouter.put('/delivered/:id', firebaseValidation, loadOutAndInMgmt, tpMainCheck, mOrderDelivered);
marketOrderRouter.get('/tp/list', firebaseValidation, loadOutAndInMgmt, tpMainCheck, tPMOrderList);
marketOrderRouter.get('/tp/getOne/:id', firebaseValidation, loadOutAndInMgmt, tpMainCheck, tPGetMOrder);
marketOrderRouter.post('/tp/create', firebaseValidation, loadOutAndInMgmt, tpMainCheck, tPCreateMOrder);

//report
marketOrderRouter.get('/report/entry', firebaseValidation, reportMgmt, userAccess("godown"), entryReport);
marketOrderRouter.get('/report/item/entry', firebaseValidation, reportMgmt, userAccess("godown"), itemEntryReport);
marketOrderRouter.get('/report/item/entryAndDelivery', firebaseValidation, reportMgmt, userAccess("godown"), itemEntryAndDelivery);
marketOrderRouter.get('/report/item/price', firebaseValidation, reportMgmt, userAccess("godown"), itemPrice);
marketOrderRouter.get('/report/section/entry', firebaseValidation, reportMgmt, userAccess("godown"), sectionEntryReport);