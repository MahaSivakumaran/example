import express from 'express';
import { Request, Response, NextFunction } from "express";
import { allStoreDemands, branchList, createStoreDemand, deletetStoreDemand, editAfterSupply, editForDivPC, editForPC, editStoreDemand, getItemsInDiv, pcVerify, pcVerifyForDiv, searchByDate, storeDemandListForPC, storeDemandSupplyEdit, storeDemandSupplyList, supplyTheDemands, deliveryReport, itemDeliveryReport, sectionDeliveryReport } from "../controller/storeDemandController";
import { firebaseValidation } from '../middleware/firebaseValidation';
import { demandMgmt, godownMgmt, inventoryMgmt, loadOutAndInMgmt, reportMgmt } from '../middleware/userValidation';
import { userAccess } from '../middleware/userAccessValidation';
import { generateResponse } from "../utils/responseGenerate";
import { error } from "../config/loggerConfig";

export const storeDemand = express.Router();

let accessValidation : any;

async function demandAccess(req: Request, res: Response, next: NextFunction){
    if((req as any).firebaseData.uid.includes("orgOwner")){
        next();
    }
    else if((req as any).firebaseData.uid.includes("orgAd") || (req as any).firebaseData.uid.includes("divM") || (req as any).firebaseData.uid.includes("divS")){
        accessValidation = "RD";
        userAccess(accessValidation) (req, res, next);
    }
    else{
        error.error(`demandAccess unauthorised user`);
        return res.status(401).json(generateResponse("Unauthorised user", 401, "Failed"));
    }
}

async function tpMainCheck(req: Request, res: Response, next: NextFunction){
    if(req.body.isMain)
    {
        next();
    }
    else{
        error.error(`tpMainCheck unauthorised user`);
        res.status(401).json(generateResponse("Unauthorised user", 401, "Failed"));
    }
}

async function tpDivCheck(req: Request, res: Response, next: NextFunction){
    if(!req.body.main)
    {
        next();
    }
    else{
        error.error(`tpDivCheck unauthorised user`);
        res.status(401).json(generateResponse("Unauthorised user", 401, "Failed"));
    }
}

storeDemand.post("/create", firebaseValidation, demandMgmt, demandAccess, createStoreDemand);
storeDemand.put("/edit/:id", firebaseValidation, demandMgmt, demandAccess, editStoreDemand);
storeDemand.put("/delete/:id", firebaseValidation, demandMgmt, demandAccess, deletetStoreDemand);
storeDemand.get("/all/:divId", firebaseValidation, demandMgmt, demandAccess, allStoreDemands);
storeDemand.get("/searchByDate", firebaseValidation, searchByDate); // check for s to s or report

// store approvals
storeDemand.get('/branchList/:id', firebaseValidation, godownMgmt, branchList)
storeDemand.get('/supplyList/:id', firebaseValidation, godownMgmt, storeDemandSupplyList)
storeDemand.put('/supplyList/edit/:id', firebaseValidation, godownMgmt, storeDemandSupplyEdit)
storeDemand.put('/supply', firebaseValidation, godownMgmt, supplyTheDemands)
storeDemand.put('/edit/afterSupply/:id', firebaseValidation, godownMgmt, editAfterSupply)


// pc approvals
storeDemand.get('/listForPC/:id', loadOutAndInMgmt, tpMainCheck, storeDemandListForPC)
storeDemand.put('/editForPc/:id', loadOutAndInMgmt, tpMainCheck, editForPC)
storeDemand.post('/verifyByPc', loadOutAndInMgmt, tpMainCheck, pcVerify)

//div
storeDemand.get('/getItems/div/:id', loadOutAndInMgmt, tpDivCheck, getItemsInDiv);
storeDemand.put('/edit/divPc/:id', loadOutAndInMgmt, tpDivCheck, editForDivPC);
storeDemand.put('/verify/divPc', loadOutAndInMgmt, tpDivCheck, pcVerifyForDiv);

//Delivery entry list
storeDemand.get('/report/delivery', reportMgmt, userAccess("godown"), deliveryReport);
storeDemand.get('/report/item/delivery', reportMgmt, userAccess("godown"), itemDeliveryReport);
storeDemand.get('/report/section/delivery', reportMgmt, userAccess("godown"), sectionDeliveryReport);