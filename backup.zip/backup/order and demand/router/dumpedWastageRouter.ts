import express from 'express';
import { reportMgmt, wastageMgmt } from "../middleware/userValidation";
import { userAccess } from "../middleware/userAccessValidation";
import { firebaseValidation } from "../middleware/firebaseValidation";
import { createDumpWastage, editDumpedWastage, deleteDumpedWastage,  getDumpedWastage, dumpedWastageReport, productWastageList } from "../controller/dumpedWastageController";

export const dumpedWastageRouter = express.Router(),
             productWastageRouter = express.Router();

dumpedWastageRouter.post("/create", firebaseValidation, wastageMgmt, createDumpWastage);
dumpedWastageRouter.put("/edit/:id", firebaseValidation, wastageMgmt, editDumpedWastage);
dumpedWastageRouter.delete("/delete/:id", firebaseValidation, wastageMgmt, deleteDumpedWastage);
dumpedWastageRouter.get("/any/:divId", firebaseValidation, wastageMgmt, getDumpedWastage);
dumpedWastageRouter.get("/report", firebaseValidation, reportMgmt, userAccess("workstation"), dumpedWastageReport);
productWastageRouter.get("/product/list", firebaseValidation, productWastageList); // check for s to s or report