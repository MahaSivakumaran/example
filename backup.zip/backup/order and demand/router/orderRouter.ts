import express from 'express';
import { Request, Response, NextFunction } from "express";
import { approvalMgmt, demandMgmt, loadOutAndInMgmt, reportMgmt } from "../middleware/userValidation";
import { userAccess } from "../middleware/userAccessValidation";
import { firebaseValidation } from "../middleware/firebaseValidation";
import { adminOrderDetail, adminOrderList, approveOrder, createOrder, editOrderManager, managerOrderList, orderDelete, orderDetails, receiveOrder, sendOrder, tPBillList, tPDivBillList, tpBillOrderList, tpDivBillOrderList, getAnOrderByDateWise, getOrderReport, orderHistory } from "../controller/orderController";
import { error } from "../config/loggerConfig";
import { generateResponse } from "../utils/responseGenerate";

export const orderRouter = express.Router();

async function tpMainCheck(req: Request, res: Response, next: NextFunction){
    if(req.body.isMain)
    {
        next();
    }
    else{
        error.error(`tpMainCheck unauthorised user`);
        res.status(401).json(generateResponse("Unauthorised user", 401, "Failed"));
    }
}

async function tpDivCheck(req: Request, res: Response, next: NextFunction){
    if(!req.body.main)
    {
        next();
    }
    else{
        error.error(`tpDivCheck unauthorised user`);
        res.status(401).json(generateResponse("Unauthorised user", 401, "Failed"));
    }
}

// manager or supervisor
orderRouter.post("/create", firebaseValidation, demandMgmt, userAccess("TO"), createOrder);
orderRouter.get("/getOne/:id", firebaseValidation, demandMgmt, userAccess("TO"), orderDetails);
orderRouter.get("/managerOrderList", firebaseValidation, demandMgmt, userAccess("TO"), managerOrderList);
orderRouter.put("/edit", firebaseValidation, demandMgmt, userAccess("TO"), editOrderManager);
orderRouter.put('/delete/:id', firebaseValidation, demandMgmt, userAccess("TO"), orderDelete);

// org admin
orderRouter.get("/adminOrderList", firebaseValidation, approvalMgmt, userAccess("ordA"), adminOrderList);
orderRouter.get("/adminOrderDetail/:id", firebaseValidation, approvalMgmt, userAccess("ordA"), adminOrderDetail);
orderRouter.put("/approve", firebaseValidation, approvalMgmt, userAccess("ordA"), approveOrder);


//tp main branch
orderRouter.get('/tp/billList', firebaseValidation, loadOutAndInMgmt, tpMainCheck, tPBillList);
orderRouter.get('/tp/billOrderList/:id', firebaseValidation, loadOutAndInMgmt, tpMainCheck, tpBillOrderList);
orderRouter.put('/send/:id', firebaseValidation, loadOutAndInMgmt, tpMainCheck, sendOrder);

// tp div
orderRouter.get('/tp/divBillList', firebaseValidation, loadOutAndInMgmt, tpDivCheck, tPDivBillList);
orderRouter.get('/tp/divBillOrderList/:id', firebaseValidation, loadOutAndInMgmt, tpDivCheck, tpDivBillOrderList);
orderRouter.put('/receive/:id', firebaseValidation, loadOutAndInMgmt, tpDivCheck, receiveOrder);

// report
orderRouter.get("/report/:divId", firebaseValidation, reportMgmt, userAccess("workstation"), getOrderReport);
orderRouter.get("/dateWise/:divId", firebaseValidation, reportMgmt, userAccess("workstation"), getAnOrderByDateWise);
orderRouter.get("/history", orderHistory);
