import express from 'express';
import { approvalMgmt, godownMgmt } from "../middleware/userValidation";
import { userAccess } from "../middleware/userAccessValidation";
import { firebaseValidation } from "../middleware/firebaseValidation";
import { approvedProductDetail, approvedProductHistory, approvedProductList, createApprovedProduct, productSupplied } from "../controller/approvedProductController";

export const approvedProductRouter = express.Router();

approvedProductRouter.post("/approve", firebaseValidation, approvalMgmt, userAccess("prodA"),createApprovedProduct);
approvedProductRouter.get('/list', firebaseValidation, godownMgmt, approvedProductList);
approvedProductRouter.get('/getDetail/:id', firebaseValidation, godownMgmt, approvedProductDetail);
approvedProductRouter.put('/supply/:id', firebaseValidation, godownMgmt, productSupplied);
approvedProductRouter.get('/history', firebaseValidation, godownMgmt, approvedProductHistory);  