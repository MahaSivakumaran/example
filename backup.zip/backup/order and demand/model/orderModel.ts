import { databaseConnection } from '../app/db';

export async function Order() {
    try {
      const db = await databaseConnection();
      const collection = await db?.collection('order', {
        validator: {
          $jsonSchema: {
            bsonType: 'object',
            title: 'Orders',
            properties: {
              _id: {
                bsonType: 'string'
              },
              orgId: {
                bsonType: 'string'
              },
              billId: {
                bsonType: 'string'
              },
              divId: {
                bsonType: 'string'
              },
              divName: {
                bsonType: 'string'
              },
              date: {
                bsonType: 'date'
              },
              orders:{
                bsonType: 'array',
                items: {
                  bsonType: 'object',
                  properties: {
                    orderedDate: {
                      bsonType: 'date'
                    },
                    shiftsAndTime: {
                      bsonType: 'array',
                      items: {
                        bsonType: 'object',
                        properties: {
                          orderShiftId: {
                            bsonType: 'string'
                          },
                          shift: {
                            bsonType: 'string'
                          },
                          time: {
                            bsonType: 'string'
                          },
                          headCount: {
                            bsonType: 'int'
                          },
                          location: {
                            bsonType: 'string'
                          },
                          isOrderApproved: {
                            bsonType: 'bool'
                          },
                          list: {
                            bsonType: 'array',
                            items: {
                              bsonType: 'object',
                              properties: {
                                orderProductId: {
                                  bsonType: 'string'
                                },
                                isProduct: {      // verify if product
                                  bsonType: 'bool'
                                },
                                isProcedure: {    // verify if procedure
                                  bsonType: 'bool'
                                },
                                groupProducts: {
                                  bsonType: 'array',
                                  items:{
                                    isProduct: {
                                      bsonType: 'string'
                                    },
                                    procedureId:{
                                      bsonType: 'string'
                                    },
                                    name: {
                                      bsonType: 'string'
                                    },
                                    qty: {
                                      bsonType: 'string'
                                    },
                                    unit: {
                                      bsonType: 'string'
                                    },
                                    isApproved: {
                                      bsonType: 'string'
                                    }
                                  }
                                },
                                name: {
                                  bsonType: 'string'
                                },
                                procedureId: {         // productId or procedureId or groupId
                                  bsonType: 'string'   
                                },
                                qty: {
                                  bsonType: 'double'
                                },
                                receivedQty: {
                                  bsonType: 'double'
                                },
                                sentQty: {
                                  bsonType: 'double'
                                },
                                unit: {
                                  bsonType: 'string'
                                },
                                isApproved: {
                                  bsonType: 'bool'
                                },
                                isSent: {
                                  bsonType: 'bool'
                                },
                                isReceived: {
                                  bsonType: 'bool'
                                }
                              }
                            }
                          },
                          createdAt: {
                            bsonType: 'string'
                          },
                          updatedAt: {
                            bsonType: 'string'
                          },
                          isDeleted: {
                            bsonType: 'string'
                          }
                        }
                      }
                    }
                  }
                }
              }
            },
          },
        },
      });
      return collection;
    } catch (err) {
      throw err;
    }
  }