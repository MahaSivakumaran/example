import { databaseConnection } from "../app/db";
import { error } from "../config/loggerConfig";

export async function reusableWastage() {
  try {
    const db = await databaseConnection();
    const collection = await db?.collection("reusableWastage", {
      validator: {
        $jsonSchema: {
          bsonType: "object",
          title: "reusableWastage",
          properties: {
            _id: {
              bsonType: "string",
            },
            orgId: {
              bsonType: "string",
            },
            divId: {
              bsonType: "string",
            },
            reusableDate: {
              bsonType: "date",
            },
            procedureId: {
              bsonType: "string",
            },
            productName: {
              bsonType: "string",
            },
            isProduct: {
              bsonType: "bool",
            },
            price: {
              bsonType: "double",
            },
            qty: {
              bsonType: "double",
            },
            unit: {
              bsonType: "string",
            },
            isDeleted: {
              bsonType: "bool",
            },
            createdAt: {
              bsonType: "date",
            },
            updatedAt: {
              bsonType: "date",
            },
          },
          required: [
            "orgId",
            "divId",
            "reusableDate",
            "productId",
            "qty",
            "unit",
          ],
        },
      },
    });
    return collection;
  } catch (err) {
    console.log("err", err);
    error.error(`reusable wastage database connection failed error${err}`);
    throw err;
  }
}
