import { databaseConnection } from "../app/db";
import { error } from "../config/loggerConfig";

export async function dumpedWastage() {
  try {
    const db = await databaseConnection();
    const collection = await db?.collection("dumpedWastage", {
      validator: {
        $jsonSchema: {
          bsonType: "object",
          title: "dumpedWastage",
          properties: {
            _id: {
              bsonType: "string",
            },
            orgId: {
              bsonType: "string",
            },
            divId: {
              bsonType: "string",
            },
            dumpedDate: {
              bsonType: "date",
            },
            procedureId: {
              bsonType: "string",
            },
            productName: {
              bsonType: "string",
            },
            isProduct: {
              bsonType: "bool",
            },
            price: {
              bsonType: "double",
            },
            qty: {
              bsonType: "double",
            },
            unit: {
              bsonType: "string",
            },
            dumpedImage: {
              bsonType: "string",
            },
            isDeleted: {
              bsonType: "bool",
            },
            createdAt: {
              bsonType: "date",
            },
            updatedAt: {
              bsonType: "date",
            },
          },
          required: [
            "orgId",
            "divId",
            "dumpedDate",
            "productId",
            "qty",
            "unit",
          ],
        },
      },
    });
    return collection;
  } catch (err) {
    console.log("err", err);
    error.error(`dumped wastage database connection failed error${err}`);
    throw err;
  }
}
