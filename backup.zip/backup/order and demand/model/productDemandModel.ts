import { databaseConnection } from "../app/db";

export async function productDemand() {
    try {
      const db = await databaseConnection();
      const collection = await db?.collection('productionDemand', {
        validator: {
          $jsonSchema: {
            bsonType: 'object',
            title: 'productionDemand',
            properties: {
              _id: {
                bsonType: 'string'                
              },
            orgId: {
              bsonType: 'string'
            },
            divId: {
              bsonType: 'string',
            },
            divName: {
              bsonType: 'string'
            },
            orderedDate: {
              bsonType: 'date',
            },
            procedureId: {
              bsonType: 'string',
            },
            name: {
              bsonType: 'string',
            },
            sentQty: {
              bsonType: 'double'
            },
            receivedQty: {
              bsonType: 'double'
            },
            qty: {
              bsonType: 'double'
            },
            unit: {
              bsontype: "string"
            },
            shift: {
              bsonType: 'string'
            },
            isApproved: {
              bsontype: "bool"
            },
            isDeleted: {
              bsonType: 'bool'
            },
            isSentFromTP: {
              bsonType: 'bool'
            },
            isReceived: {
              bsonType: 'bool'
            },
            isProcedure: {
              bsonType: 'bool'
            },
            isProduct: {
              bsonType: 'bool'
            },
            groupProducts: {
              bsonType: 'array',
              items: {
                bsonType: 'object',
                properties: {
                  procedureId: {
                    bsonType: 'bool'
                  },
                  isProduct: {
                    bsonType: 'bool'
                  },
                  name: {
                    bsonType: 'string'
                  },
                  qty: {
                    bsonType: 'number'
                  },
                  unit: {
                    bsonType: 'string'
                  },
                  isApproved: {
                    bsonType: 'bool'
                  },
                }
              }

            },
            createdAt: {
              bsonType: 'date',
            },
            updatedAt: {
              bsonType: 'date',
            },
          },
        },
      },
    });
    return collection;
  } catch (err) {
    throw err;
  }
}