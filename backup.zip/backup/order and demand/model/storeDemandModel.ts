import { databaseConnection } from "../app/db";

export async function storeDemand() {
    try {
      const db = await databaseConnection();
      const collection = await db?.collection('storeDemand', {
        validator: {
          $jsonSchema: {
            bsonType: 'object',
            title: 'storeDemand',
            properties: {
              _id: {
                bsonType: 'string'
                
              },
              orgId:{
                bsonType: 'string'

              },
              orderedDate: {
                bsonType: 'date',
              },
              deliveredDate: {
                bsonType: 'date',
                
              },
              isSentToPickupCounter: {
                bsonType: 'bool',
                
              },
              isSentFromPickupCounter:{
                bsonType: 'bool',
                
              },
              isReceived:{
                bsonType: 'bool'
                
              },
              itemId:{
                bsontype:"string"
              },
              section:{
                bsontype:"string"
              },
              orderedQuantity: {
                bsonType: 'int',
              },
              unit:{
                bsontype:"string"
              },
              receivedQuantity:{
                bsontype:"string"
              },
              sentQuantity:{
                bsontype:"string"
              },
              divId:{
                bsontype:"string"
              },
              divisoinName:{
                bsonType: "string"
              },
              isDeleted:{
                bsonType: "bool"
              },
              createdAt: {
                bsonType: 'date',
              },
              updatedAt: {
                bsonType: 'date',
              },
            },
          },
        },
      });
      return collection;
    } catch (err) {
      throw err;
    }
  }

