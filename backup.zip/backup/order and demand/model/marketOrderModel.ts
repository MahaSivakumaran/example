import { databaseConnection } from "../app/db";
import { info, error } from "../config/loggerConfig";

export async function marketOrder(){

    try {
    const db = await databaseConnection();
    const collection = db.collection('marketOrder',{
        validator:{
            $jsonSchema:{
                bsonType: 'object',
                title: 'Market order',
                properties:{
                    _id:{
                        bsonType: 'string'
                    },
                    orgId:{
                        bsonType: 'string'
                    },
                    itemId:{
                        bsonType: 'string'
                    },
                    sectionName:{
                        bsonType: 'string'
                    },
                    name: {
                        bsonType: 'string'
                    },
                    orderedQty:{
                        bsonType: 'double'
                    },
                    suppliedQty: {
                        bsonType: 'double'
                    },
                    price:{
                        bsonType: 'double'
                    },
                    unit:{
                        bsonType: 'string'
                    },
                    supplier: {
                        bsonType: 'string'
                    },
                    isDeleted:{
                        bsonType: 'bool'
                    },
                    isDelivered: {
                        bsonType: 'bool'
                    },
                    isStored: {
                        bsonType: 'bool'
                    },
                    orderedDate: {
                        bsonType: 'string'
                    },
                    deliveredDate: {
                        bsonType: 'string'
                    },
                    createdAt: {
                        bsonType: 'string'
                    },
                    updatedAt: {
                        bsonType: 'string'
                    },
                }
        }
    }
    });
    return collection;
}
catch(err:any){
    error.error(`marketOrder database connection failed error${err}`);
    throw err;
}
}