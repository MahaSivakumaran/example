import { databaseConnection } from '../app/db';

export async function approvedProduct() {
    try {
      const db = await databaseConnection();
      const collection = await db?.collection('approvedProduct', {
        validator: {
          $jsonSchema: {
            bsonType: 'object',
            title: 'ApprovedProduct',
            properties: {
              _id: {
                bsonType: 'string'
              },
              orgId: {
                bsonType: 'string'
              },
              name: {
                bsonType: 'string'
              },
              divId: {
                bsonType: 'string'
              },
              date: {
                bsonType: 'string'
              },
              isProductionDemand:{
                bsonType: 'bool'
              },
              demandId: {
                bsonType: 'string'
              },
              procedureId: {
                bsonType: 'string'
              },
              qty: {
                bsonType: 'double'
              },
              updatedQty: {
                bsonType: 'double'
              },
              unit: {
                bsonType: 'string'
              },
              rawMaterials: {
                bsonType: 'array',
                items: {
                    bsonType: 'object',
                    properties: {
                        itemId: {
                            bsonType: 'string'
                        },
                        name: {
                            bsonType: 'string'
                        },
                        qty: {
                            bsonType: 'double'
                        },
                        unit: {
                            bsonType: 'string'
                        }
                    }
                }
              },
              processingList: {
                  bsonType: 'array',
                  items: {
                      bsonType: 'object',
                      properties: {
                          name: {
                              bsonType: 'string'
                          },
                          qty: {
                              bsonType: 'double'
                          },
                          unit: {
                              bsonType: 'string'
                          }
                      }
                  }
               },
              isSupplied: {
                bsonType: 'bool'
              },
              createdAt: {
                bsonType: 'date'
              },
              updatedAt: {
                bsonType: 'date'
              },
            },
          },
        },
      });
      return collection;
    } catch (err) {
      throw err;
    }
  }