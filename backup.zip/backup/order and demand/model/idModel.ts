import { databaseConnection } from "../app/db";
import { error } from "../config/loggerConfig";


export async function idModel(){
    
    try{
        const db = await databaseConnection();
        const collection = await db.collection('id',{
            validator:{
                $jsonSchema:{
                    bsonType: 'object',
                    title: 'ID',
                    properties:{
                        orderId:{
                            bsonType: 'int'
                        },
                        billId:{
                            bsonType: 'int'
                        },
                        orderShiftId:{
                            bsonType: 'int'
                        },
                        orderProductId:{
                            bsonType: 'int'
                        },
                        sDemandId: {
                            bsonType: 'int'
                        },
                        prodDemandId: {
                            bsonType: 'int'
                        },
                        dWasteId: {
                            bsonType: 'int'
                        },
                        rWasteId: {
                            bsonType: 'int'
                        },
                        approvedProductId: {
                            bsonType: 'int'
                        }
                    }
                }
            }
        });
        return collection;
    }
    catch(err){
        error.error(`Id database connection failed error${err}`);
        throw err;
    }
}