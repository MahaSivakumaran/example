import { NextFunction, Request, Response } from 'express';
import httpContext from 'express-http-context';
import { uniqueId } from './loggerSyncId';

export const setContextMiddleware =async (req: Request, res: Response, next: NextFunction) => {
    httpContext.set('x_txn_id', await uniqueId());
    httpContext.set('x_user_id', 1);
    httpContext.set('x_api_name', "ooojo");
    httpContext.set('module', 'logger');
    next();
};

