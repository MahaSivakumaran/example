import { Mutex } from 'async-mutex'


let clientLock = new Mutex();
async function serverDelay() {
    return new Promise(resolve => setTimeout(resolve, 1));
}

export var uniqueId = async () => {
    let release = await clientLock.acquire();
    await serverDelay();
    let timeNow = Date.now();
    release();
    return timeNow;
}
