import { createLogger, transports, format } from 'winston';
import httpContext from 'express-http-context';

const info = createLogger({
    transports: [
        new transports.File({
            filename: 'info_log',
            level: 'info',
            format: format.combine(format.timestamp(), format.json())
        })
    ],
    defaultMeta: {
        get txnId() {
            return httpContext.get('x_txn_id');
        },
        get x_user_id() {
            return httpContext.get('x_user_id');
        },
        get x_api_name() {
            return httpContext.get('x_api_name');
        },
        module: 'logger'
    }
});

const error = createLogger({
    transports: [
        new transports.File({
            filename: 'err_log',
            level: 'error',
            format: format.combine(format.timestamp(), format.json(), format.metadata())
        })
    ],
    defaultMeta: {
        get txnId() {
            return httpContext.get('x_txn_id');
        },
        get x_user_id() {
            return httpContext.get('x_user_id');
        },
        get x_api_name() {
            return httpContext.get('x_api_name');
        },
        module: 'logger'
    }
});

export { info, error };
