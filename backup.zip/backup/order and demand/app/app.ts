import dotenv from 'dotenv';
import bodyParser from 'body-parser';
import { databaseConnection } from './db';
import express, { Application } from 'express';
import swaggerUi from 'swagger-ui-express';
import * as YAML from 'yamljs';
import path from 'path';
var cors = require("cors");
dotenv.config();
import httpContext from 'express-http-context';
import { orderInstance } from '../controller/orderController';
import { dumpWastageInstance } from '../controller/dumpedWastageController';
import { reusableWastageInstance } from '../controller/reusableWastageContoller';
import { orderRouter } from '../router/orderRouter';
import { storeDemand } from '../router/storeDemandRouter';
import { storeDemandInstance } from '../controller/storeDemandController';
import { productionDemandInstance } from '../controller/productionDemandController';
import { prodDemand } from '../router/prodDemandRouter';
import { initializeIds } from '../utils/idGenerate';
import { approvedProductInstance } from '../controller/approvedProductController';
import {dumpedWastageRouter, productWastageRouter } from '../router/dumpedWastageRouter';
import { reusableWastageRouter } from '../router/reusableWastageRouter';
import { marketInstance } from '../controller/marketOrderController';
import { marketOrderRouter } from '../router/marketOrderRouter';
import { approvedProductRouter } from '../router/approvedProductRouter';

const swaggerDocument = YAML.load(path.join(__dirname, '../config/swagger.yaml'));
export const app: Application = express();
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument));
databaseConnection()
.then(async ()=>{
    await initializeIds();
    await orderInstance();
    await approvedProductInstance();
    await orderInstance();
    await dumpWastageInstance();
    await reusableWastageInstance();
    await marketInstance();
    await storeDemandInstance();
    await productionDemandInstance();
})
.catch((err)=>{
    console.log(err)
})

const {PORT} = process.env

app.use(express.json());
app.use(bodyParser.json());
app.use(httpContext.middleware);
app.use(cors());


app.use("/api/order",orderRouter);
app.use("/api/storeDemand",storeDemand);
app.use('/api/prodDemand',prodDemand);
app.use("/api/dumped/wastage", dumpedWastageRouter);
app.use("/api/reusable/wastage", reusableWastageRouter);
app.use("/api/marketOrder", marketOrderRouter);
app.use("/api/wastage", productWastageRouter);
app.use("/api/approveProduct", approvedProductRouter);


app.listen(PORT,()=>{
    console.log(`Server connected to the PORT : ${PORT}`)
})

