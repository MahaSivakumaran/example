module.exports = {
    apps: [
      {
        name: 'atvara-orders-and-demands-service',
        script: './app/app.ts',
        interpreter: './node_modules/.bin/ts-node',
      },
    ],
  };
  