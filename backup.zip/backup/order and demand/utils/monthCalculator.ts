export const monthCal = (month: string) => {
    const selectedMonth = parseInt(month);
    const year = new Date().getFullYear();
    let nextYear = year;
    let nextMonth = selectedMonth + 1;
    
    if (selectedMonth === 12) {
        nextYear += 1;
        nextMonth = 1;
    }

    const firstDayOfMonth = `${year}-${selectedMonth.toString().padStart(2, '0')}-01`;
    const lastDayOfMonth = `${nextYear}-${nextMonth.toString().padStart(2, '0')}-01`;

    return { firstDayOfMonth, lastDayOfMonth };
}