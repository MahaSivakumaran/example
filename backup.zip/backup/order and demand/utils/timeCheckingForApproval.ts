export function isWithiInCurrentDay(createdAt: Date): boolean {
    const currentDateTime = new Date();
    const currentYear = currentDateTime.getFullYear();
    const currentMonth = currentDateTime.getMonth();
    const currentDay = currentDateTime.getDate();

    const currentDayEnd = new Date(currentYear, currentMonth, currentDay, 23, 59, 59, 999);

    return createdAt.getTime() > currentDayEnd.getTime() - 24 * 60 * 60 * 1000 && createdAt.getTime() <= currentDayEnd.getTime();
}