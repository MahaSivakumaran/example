function generateResponse(displayMessage: string, statusCode: number, status: string, data: any = {}): any {
    return {
      meta: {
        displayMessage,
        status_code: statusCode,
        status,
      },
      data,
    };
  }

  export {generateResponse}