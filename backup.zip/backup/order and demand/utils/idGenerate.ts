import { idModel } from "../model/idModel";
import { info, error } from "../config/loggerConfig";
 

export async function initializeIds(){
    try{
        info.info(`initializeId initiated`);
        const collection = await idModel();
        const idData = await collection.findOne();
        if(idData == null)
        {
            await collection.insertOne({
                orderId: 1000,
                billId: 100,
                orderShiftId: 1000,
                sDemandId: 1000,
                prodDemandId: 1000,
                dWasteId: 1000,
                rWasteId: 1000,
                orderProductId: 1000,
                approvedProductId: 1000,
                marketOrderId: 1000
            });
            info.info(`initializeIds id db created`);
        }
    }
    catch(err){
        error.error(`initializeIds id error:${err}`);
        throw err;
    }
}
 

export async function createOrderId() {
    try {
        info.info(`createOrderId initiated`);
        const collection = await idModel();
        const idData = await collection.find({}).toArray();
        let id = idData[0]._id;
        let oId = idData[0].orderId + 1;
        await collection.findOneAndUpdate({ _id: id }, {
            $set: { orderId: oId }
        },
            {
                new: true
            });
        oId = "order_" + oId;
        info.info(`createOrderId created orderId:${oId}`);
        return oId;
    }
    catch(err){
        error.error(`createOrderId error:${err}`);
        return false;
    }
}
 

export async function createBillId() {
    try {
        info.info(`createBillId initiated`);
        const collection = await idModel();
        const idData = await collection.find({}).toArray();
        let id = idData[0]._id;
        let bId = idData[0].billId + 1;
        await collection.findOneAndUpdate({ _id: id }, {
            $set: { billId: bId }
        },
            {
                new: true
            });
            bId = "bill_"+bId;
        info.info(`createBillId created billId:${bId}`);
        return bId;
    }
    catch(err){
        error.error(`createBillId error:${err}`);
        return false;
    }
}
 

export async function createOrderShiftId() {
    try {
        info.info(`createOrderShiftId initiated`);
        const collection = await idModel();
        const idData = await collection.find({}).toArray();
        let id = idData[0]._id;
        let oSId = idData[0].orderShiftId + 1;
        await collection.findOneAndUpdate({ _id: id }, {
            $set: { orderShiftId: oSId }
        },
            {
                new: true
            });
        oSId = "orderShift_" + oSId;
        info.info(`createOrderShiftId created orderShiftId:${oSId}`);
        return oSId;
    }
    catch(err){
        error.error(`createOrderShiftId error:${err}`);
        return false;
    }
}

export async function createOrderProductId() {
    try {
        info.info(`createOrderProductId initiated`);
        const collection = await idModel();
        const idData = await collection.find({}).toArray();
        let id = idData[0]._id;
        let oPId = idData[0].orderProductId + 1;
        await collection.findOneAndUpdate({ _id: id }, {
            $set: { orderProductId: oPId }
        },
            {
                new: true
            });
        oPId = "orderProduct_" + oPId;
        info.info(`createOrderProductId created orderShiftId:${oPId}`);
        return oPId;
    }
    catch(err){
        error.error(`createOrderProductId error:${err}`);
        return false;
    }
}

export async function createStoreDemandId() {
    try {
        info.info(`createStoreDemandId initiated`);
        const collection = await idModel();
        const idData = await collection.find({}).toArray();
        let id = idData[0]._id;
        let sDId = idData[0].sDemandId + 1;
        await collection.findOneAndUpdate({ _id: id }, {
            $set: { sDemandId: sDId }
        },
            {
                new: true
            });
        sDId = "sD_" + sDId;
        info.info(`createStoreDemandId created sDemandId:${sDId}`);
        return sDId;
    }
    catch(err){
        error.error(`createStoreDemandId error:${err}`);
        return false;
    }
}
 

export async function createProductionDemandId() {
    try {
        info.info(`createProductionDemandId initiated`);
        const collection = await idModel();
        const idData = await collection.find({}).toArray();
        let id = idData[0]._id;
        let pDId = idData[0].prodDemandId + 1;
        await collection.findOneAndUpdate({ _id: id }, {
            $set: { prodDemandId: pDId }
        },
            {
                new: true
            });
        pDId = "pD_" + pDId;
        info.info(`createProductionDemandId created prodDemandId:${pDId}`);
        return pDId;
    }
    catch(err){
        error.error(`createProductionDemandId error:${err}`);
        return false;
    }
}
 

export async function createDWasteId() {
    try {
        info.info(`createDWasteId initiated`);
        const collection = await idModel();
        const idData = await collection.find({}).toArray();
        let id = idData[0]._id;
        let dWId = idData[0].dWasteId + 1;
        await collection.findOneAndUpdate({ _id: id }, {
            $set: { dWasteId: dWId }
        },
            {
                new: true
            });
        dWId = "dW_" + dWId;
        info.info(`createDWasteId created dWasteId:${dWId}`);
        return dWId;
    }
    catch(err){
        error.error(`createDWasteId error:${err}`);
        return false;
    }
}
 

export async function createRWasteId() {
    try {
        info.info(`createRWasteId initiated`);
        const collection = await idModel();
        const idData = await collection.find({}).toArray();
        let id = idData[0]._id;
        let rWasteId = idData[0].rWasteId + 1;
        await collection.findOneAndUpdate({ _id: id }, {
            $set: { rWasteId: rWasteId }
        },
            {
                new: true
            });
        rWasteId = "rWaste_" + rWasteId;
        info.info(`createRWasteId created rWasteId:${rWasteId}`);
        return rWasteId;
    }
    catch(err){
        error.error(`createRWasteId error:${err}`);
        return false;
    }
}

export async function createApprovedProductId() {
    try {
        info.info(`createApprovedProductId initiated`);
        const collection = await idModel();
        const idData = await collection.find({}).toArray();
        let id = idData[0]._id;
        let aPId = idData[0].approvedProductId + 1;
        await collection.findOneAndUpdate({ _id: id }, {
            $set: { approvedProductId: aPId }
        },
            {
                new: true
            });

        aPId = "approvedProduct_"+aPId;
        info.info(`createApprovedProductId created approvedProductId:${aPId}`);
        return aPId;
    }
    catch(err){
        error.error(`createApprovedProductId error:${err}`);
        return false;
    }
}

export async function createMOrderId() {
    try {
        info.info(`createMOrderId initiated`);
        const collection = await idModel();
        const idData = await collection.find({}).toArray();
        let id = idData[0]._id;
        let mOId = idData[0].marketOrderId + 1;
        await collection.findOneAndUpdate({ _id: id }, {
            $set: { marketOrderId: mOId }
        },
            {
                new: true
            });
        info.info(`createMOrderId created marketOrderId:${mOId}`);
        mOId = "mOrder_"+mOId;
        return mOId;
    }
    catch(err){
        error.error(`createMOrderId error:${err}`);
        return false;
    }
}