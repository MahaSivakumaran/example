import { Request, Response } from "express";
import { info, error } from "../config/loggerConfig";
import { Order } from "../model/orderModel";
import { createBillId, createOrderId, createOrderProductId, createOrderShiftId } from "../utils/idGenerate";
import { generateResponse } from "../utils/responseGenerate";
import moment from 'moment';
import { monthCal } from "../utils/monthCalculator";
const currentDate: moment.Moment = moment();

let collection: any;

export const orderInstance = async () => {
  collection = await Order();
}

export async function createOrder(req: Request, res: Response) {
  info.info(`createOrder initiated`);
  const { orgId } = req.query;
  info.info(`createOrder req.query:${JSON.stringify(req.query)}`);
  info.info(`createOrder req.body:${JSON.stringify(req.body)}`);
  if(!orgId)
  {
    error.error(`createOrder error: orgId missing`);
    return res.status(400).send(generateResponse("Company id is missing", 400, "failed"));
  }
  try {
    const { divId, orders } = req.body;

    if (!divId) {
      error.error(`createOrder orgId:${orgId} error: divId missing`)
      return res.status(400).send(generateResponse("Branch id is missing", 400, "failed"));
    }
    if (!orders) {
      error.error(`createOrder orgId:${orgId} error: oders missing`)
      return res.status(400).send(generateResponse("Order details is missing", 400, "failed"));
    }
    const id = await createOrderId();
    const billId = await createBillId();
    for (let order of orders) {
      for (let shifts of order.shiftsAndTime) {
        let orderShiftId = await createOrderShiftId();
        shifts.orderShiftId = orderShiftId;
        shifts.isOrderApproved = false;
        if(shifts.list){
        for(let list of shifts.list){
          let orderProductId = await createOrderProductId();
          list.orderProductId = orderProductId;
          const groupProducts = list.groupProducts ? list.groupProducts : [];
          if(groupProducts && groupProducts.length > 0)
          {
            for(let products of list.groupProducts){
              products.isApproved =  false;
            } 
          }
          else{
            list.groupProducts = []
          }
          list.receivedQty= 0;
          list.sentQty = 0;
          list.isApproved = false;
          list.isSent = false;
          list.isReceived = false;
        }}
      }
    }
    const date: string = currentDate.format('YYYY-MM-DD');
    const orderData = {
      _id: id,
      billId,
      orgId,
      date,
      divId,
      orders,
      createdAt: new Date(),
      updatedAt: new Date(),
      isDeleted: false
    };
    info.info(`createOrder orgId:${orgId} orderData:${JSON.stringify(orderData)}`);
    await collection.insertOne(
      orderData
    );
    info.info(`createOrder orgId:${orgId} order created`);
    res.status(200).send(generateResponse("Order created successfully", 200, "success"));
  }
  catch (err: any) {
    error.error(`createOrder orgId:${orgId} error:${err.message}`);
    res.status(500).send(generateResponse("Internal server error", 500, "failed"));
  }
}

export async function orderDetails(req: Request, res: Response) {
  const { id } = req.params;
  info.info(`orderDetails id:${id} initiated`);
  info.info(`orderDetails id:${id} req.params:${JSON.stringify(req.params)}`);
  try {
    const projection = {
      _id: 1,
      billId: 1,
      orgId: 1,
      date: 1,
      divId: 1,
      orders: 1,
    };
    let orderData = await collection.findOne({ _id: id, isDeleted: false }, { projection });
    if (!orderData) {
      error.error(`orderDetails id:${id} error: order not found`);
      const response = generateResponse("Order not found..!", 404, "failed");
      return res.status(404).json(response);
    }
    info.info(`orderDetails id:${id} data fetched`);
    const response = generateResponse("Order found..!", 200, "success", orderData);
    res.status(200).json(response);
  }
  catch (err: any) {
    error.error(`orderDetails id:${id} error:${err.message}`);
    res.status(500).send(generateResponse("Internal server error", 500, "failed"));
  }
}

export async function editOrderManager(req: Request, res: Response) {
  info.info(`editOrderManager initiated`);
  info.info(`editOrderManager req.query: ${req.query}`)
  info.info(`editOrderManager req.body: ${req.body}`)

  const orders = req.body.orders;
  const billId: string = req.body.billId;
  if (!billId) {
    error.error(`editOrderManager error: billId missing`)
    return res.status(400).send(generateResponse("Bill id is missing", 400, "failed"));
  }
  if (!orders) {
    error.error(`editOrderManager error: orders missing`)
    return res.status(400).send(generateResponse("Order details is missing", 400, "failed"));
  }

  try {

    for(let order of orders) {
      for(let shifts of order.shiftsAndTime) {
        if(!shifts.orderShiftId)
        {
        let orderShiftId = await createOrderShiftId();
        shifts.orderShiftId = orderShiftId;
        shifts.isOrderApproved = false;
        }
        if(shifts.list){
        for(let list of shifts.list){
          if(!list.orderProductId)
          {
          let orderProductId = await createOrderProductId();
          list.orderProductId = orderProductId;
          const groupProducts = list.groupProducts ? list.groupProducts : [];
          if(groupProducts && groupProducts.length > 0)
          {
            for(let products of list.groupProducts){
              products.isApproved =  false;
            } 
          }
          else{
            list.groupProducts = [];
          }
          list.isApproved = false;
          list.receivedQty= 0;
          list.sentQty = 0;
          list.isSent = false;
          list.isReceived = false;
          }
        }}
      }
    }

    const orderData = await collection.findOne({billId, isDeleted: false});

    if(!orderData){
      error.error(`editOrderManager billId:${billId} error: order not found`);
      return res.status(404).json(generateResponse("Order not found..", 404, "Failed"));
    }

    const updatedData = {
      orders: orders,
      updatedAt: new Date()
      };

    info.info(`editOrderManager billId:${billId} updatedData:${JSON.stringify(updatedData)}`)

    await collection.findOneAndUpdate({ billId }, {
      $set: updatedData
    },
      {
        new: true
      }
    );
    info.info(`editOrderManager billId:${billId} editedDetails:${JSON.stringify(orders)}`);
    res.status(200).send(generateResponse("Order updated successfully", 200, "success"));
  }
  catch (err: any) {
    error.error(`editOrderManager billId:${billId} error:${err.message}`);
    res.status(500).send(generateResponse("Internal server error", 500, "failed"))
  }
}

export async function orderDelete (req: Request, res: Response) {
  const billId = req.params.id;
  info.info(`orderDelete billId:${billId} initiated`);
  info.info(`orderDelete req.params: ${JSON.stringify(req.params)}`)
  try{
    await collection.findOneAndUpdate({billId}, {
      $set: {isDeleted: true}
    });
    info.info(`orderDelete billId:${billId} deleted`);
    res.status(200).json(generateResponse("Order deleted successfully", 200, "Success"));
  }
  catch(err: any)
  {
    error.error(`orderDelete billId:${billId} error:${err.message}`);
    res.status(500).json(generateResponse("Internal server error..", 500, "Failed"));
  }
}

export async function adminOrderList(req: Request, res: Response) {
  info.info(`adminOrderList initiated`);
  info.info(`adminOrderList req.query:${JSON.stringify(req.query)}`);
  info.info(`adminOrderList req.body:${JSON.stringify(req.body)}`);

  const { orgId } = req.query;
  if(!orgId){
    error.error(`adminOrderList error: orgId missing`);
    return res.status(400).json(generateResponse(`Company id is missing`,400,`failed`));
  }
  let date = req.body.date;
  if(!date)
  {
    error.error(`adminOrderList orgId:${orgId} error: date missing`);
    return res.status(400).json(generateResponse(`Date is missing`,400,`failed`));
  }

  try {
    const projection = {
      _id: 1,
      billId: 1,
      date: 1,
      "orders.shiftsAndTime.orderShiftId": 1,
      "orders.shiftsAndTime.shift": 1,
      "orders.shiftsAndTime.isOrderApproved": 1,
    };
    let orderData = await collection.find({ isDeleted: false, orgId, date }, { projection }).toArray();
    if(orderData.length > 0)
    {
      info.info(`adminOrderList orgId:${orgId} data fetched successfully`);
      res.status(200).send(generateResponse("Data fetched successfuly...", 200, "success", orderData));
    }
    else{
      error.error(`adminOrderList orgId:${orgId} error: no data found`);
      res.status(404).send(generateResponse("No data found", 404, "failed"));
    }
  }
  catch (err: any) {
    error.error(`adminOrderList orgId:${orgId} error:${err.message}`);
    res.status(500).json(generateResponse(`Internal server error`,500,`failed`))
  }
}

export async function adminOrderDetail(req: Request, res: Response) {
  let id = req.params.id;
  info.info(`adminOrderDetail orderShiftId:${id} initiated`);
  try {
    let orderData = await collection.aggregate([
      {
        $match: {
          isDeleted: false,
          "orders.shiftsAndTime.orderShiftId": id,
        },
      },
      {
        $unwind: "$orders",
      },
      {
        $unwind: "$orders.shiftsAndTime",
      },
      {
        $match: {
          "orders.shiftsAndTime.orderShiftId": id,
        },
      },
      {
        $project: {
          _id: 1,
          billId: 1,
          "orders.shiftsAndTime": 1,
        },
      },
    ]).toArray();
    if (orderData.length > 0) {
      info.info(`adminOrderDetail orderShiftId:${id} data fetched`);
      res.status(200).send(generateResponse("Data fetched...", 200, "success", orderData));
    }
    else {
      error.error(`adminOrderDetail orderShiftId:${id} error: no data found`);
      res.status(404).send(generateResponse("No data found...", 404, "failed"));
    }
  }
  catch (err: any) {
    error.error(`adminOrderDetail orderShiftId:${id} error:${err.message}`);
    res.status(500).json(generateResponse(`Internal server error`,500,`failed`))
  }
}

export async function managerOrderList(req: Request, res: Response) {
  info.info(`managerOrderList initiated`);
  info.info(`managerOrderList req.query:${req.query}`);
  const { orgId, divId } = req.query;
    if (!orgId) {
      error.error(`managerOrderList error: orgId missing`);
      return res.status(400).send(generateResponse("Company id is missing", 400, "failed"));
    }
    if (!divId) {
      error.error(`managerOrderList error: divId missing`);
      return res.status(400).send(generateResponse("Branch id is missing", 400, "failed"));
    }

  try {
    let projection = {
      _id:1,
      billId:1,
      "orders.orderedDate":1,
      "orders.shiftsAndTime.shift": 1,
      "orders.shiftsAndTime.isOrderApproved":1
    };
    let date: string = currentDate.format('YYYY-MM-DD');
    let orderData = await collection.find({ isDeleted: false, divId, orgId, date }, { projection }).toArray();
    if(orderData.length > 0)
    {
      info.info(`managerOrderList divId:${divId} data fetched`);
      res.status(200).send(generateResponse("Data fetched..", 200, "success", orderData));
    }
    else{
      error.error(`managerOrderList divId:${divId} error: no data found`);
      return res.status(404).send(generateResponse("No data found", 404, "failed"));
    }
  }
  catch (err: any) {
    error.error(`managerOrderList divId:${divId} error:${err.message}`);
    res.status(500).json(generateResponse(`Internal server error`,500,`failed`))
  }
}

export async function approveOrder(req: Request, res: Response) {
  info.info(`approveOrder initiated`);
  info.info(`approveOrder req.body:${JSON.stringify(req.body)}`);
  const { id, orderId, products } = req.body;
  if(!id || !orderId || !products)
  {
    error.error(`approveOrder error: Invalid arguments`);
    return res.status(400).send(generateResponse("Invalid arguments...", 400, "failed"));
  }

  try {
    const orderData = await collection.findOne({_id: orderId, isDeleted: false});
    if(!orderData){
      error.error(`approveOrder orderId:${orderId} orderShiftId:${id} error: order missing`)
      return res.status(400).json(generateResponse("Order not found..", 400, "Failed"));
    }
    const updateOperations = products.map((product: any) => ({
      updateOne: {
        filter: {
          "_id": orderId,
          "orders.shiftsAndTime": { $elemMatch: { orderShiftId: id, "list.orderProductId": product.orderProductId } }
        },
        update: {
          $set: {
            "orders.$[outer].shiftsAndTime.$[inner].list.$[listElem].qty": product.qty,
            "orders.$[outer].shiftsAndTime.$[inner].isOrderApproved": true,
            updatedAt: new Date()
          }
        },
        arrayFilters: [
          { "outer.shiftsAndTime": { $elemMatch: { orderShiftId: id } } },
          { "inner.list.orderProductId": product.orderProductId },
          { "listElem.orderProductId": product.orderProductId }
        ]
      }
    }));

    products.map((product: any) => {
      if(product.isProcedure == false && product.isProduct == false)
      {
        updateOperations.push({updateOne: {
          filter: {
            "_id": orderId,
            "orders.shiftsAndTime": { $elemMatch: { orderShiftId: id, "list.orderProductId": product.orderProductId } }
          },
          update: {
            $mul: {
              "orders.$[outer].shiftsAndTime.$[inner].list.$[listElem].groupProducts.$[].qty": product.qty
            }
          },
          arrayFilters: [
            { "outer.shiftsAndTime": { $elemMatch: { orderShiftId: id } } },
            { "inner.list.orderProductId": product.orderProductId },
            { "listElem.orderProductId": product.orderProductId },
          ]
        }})
      }
    })

    info.info(`approveOrder orderId:${orderId} orderShiftId:${id} updatedOperations:${JSON.stringify(updateOperations)}`);

    const ress = await collection.bulkWrite(updateOperations);
      
    info.info(`approveOrder orderId:${orderId} orderShiftId:${id} completed `)
    res.status(200).json(generateResponse(`Order approved..`,200,`success`))
  }
  catch (err: any) {
    error.error(`approveOrder orderId:${orderId} orderShiftId:${id} error:${err.message}`);
    res.status(500).json(generateResponse(`Internal server error`,500,"failed"))
  }
}

export async function orderData(orgId: any, shift: any, orderedDate: any) {
  try {
    const aggregationPipeline = [
      {
        $match: {
          'orgId': orgId,
          'orders.shiftsAndTime.shift': shift,
          'orders.orderedDate': orderedDate
        }
      },
      {
        $unwind: '$orders'
      },
      {
        $unwind: '$orders.shiftsAndTime'
      },
      {
        $match: {
          'orders.shiftsAndTime.shift': shift
        }
      },
      {
        $unwind: '$orders.shiftsAndTime.list'
      },
      {
        $project: {
          _id: 1, 
          orderProductId: '$orders.shiftsAndTime.list.orderProductId',
          isProduct: '$orders.shiftsAndTime.list.isProduct',
          isProcedure: '$orders.shiftsAndTime.list.isProcedure',
          name: '$orders.shiftsAndTime.list.name',
          procedureId: '$orders.shiftsAndTime.list.procedureId',
          qty: '$orders.shiftsAndTime.list.qty',
          unit: '$orders.shiftsAndTime.list.unit',
          isApproved: '$orders.shiftsAndTime.list.isApproved',
          groupProducts: '$orders.shiftsAndTime.list.groupProducts' 
        }
      },
      {
        $unwind: {
          path: '$groupProducts',
          preserveNullAndEmptyArrays: true 
        }
      },
      {
        $project: {
          _id: 0,
          qty: { $ifNull: ['$groupProducts.qty', '$qty'] },
          name: { $ifNull: ['$groupProducts.name', '$name'] }, 
          unit: { $ifNull: ['$groupProducts.unit', '$unit'] },
          procedureId: { $ifNull: ['$groupProducts.procedureId', '$procedureId'] },
        }
      }
    ];

    const result = await collection.aggregate(aggregationPipeline).toArray();
    return result;
  } catch (err) {
    throw err;
  }
}

// tp apis
export async function tPBillList (req: Request, res: Response) {
  const {orgId} = req.query;
  info.info(`tPBillList orgId:${orgId} initiated`);
  if(!orgId){
    error.error(`tPBillList error: orgId missing`);
    return res.status(400).json(generateResponse(`OrgId missing..`,400,`failed`))
  }
  try{
    const pipeline = [
      {
        $match: {
          orgId,
          isDeleted: false,
          "orders.shiftsAndTime.list": {
            $elemMatch: { "isApproved": true, "isSent": false }
          },
          
        }
      },
      {
        $project: {
          "_id": 1,
          "billId": 1,
          "orgId": 1,
          "divId": 1,
          "divName": 1,
        }
      }
    ];
    info.info(`tPBillList orgId:${orgId} pipeline:${JSON.stringify(pipeline)}`);
    const orderData = await collection.aggregate(pipeline).toArray();
    if(orderData.length > 0)
    {
      info.info(`tpBillList orgId:${orgId} data fetched`);
      res.status(200).json(generateResponse("Data fetched..", 200, "Success", orderData));
    }
    else
    {
      error.error(`tPBillList orgId:${orgId} error: no data found`);
      res.status(404).send(generateResponse("No data found", 404, "failed"));
    }
  }
  catch(err: any){
    error.error(`tpBillList orgId:${orgId} error:${err.message}`);
    res.status(500).json(generateResponse("Internal server error", 500, "Failed"))
  }
}

export async function tpBillOrderList (req: Request, res: Response) {
  const billId = req.params.id;
  info.info(`tpBillOrderList billId:${billId} initiated`);
  info.info(`tpBillOrderList req.params: ${JSON.stringify(req.params)}`);
  info.info(`tpBillOrderList billId:${billId} req.query: ${JSON.stringify(req.query)}`);
  const {orgId} = req.query;
  if(!orgId){
    error.error(`tPBillList billId:${billId} error: orgId missing`);
    return res.status(400).json(generateResponse(`OrgId missing..`,400,`failed`))
  }
  try{
    const pipeline = [
      {
        $match: {
          orgId,
          isDeleted: false,
          billId,
          "orders.shiftsAndTime.list": {
            $elemMatch: {
              "isApproved": true,
              "isSent": false,
              "isReceived": false
            }
          }
        }
      },
      {
        $unwind: "$orders"
      },
      {
        $unwind: "$orders.shiftsAndTime"
      },
      {
        $unwind: "$orders.shiftsAndTime.list"
      },
      {
        $match: {
          "orders.shiftsAndTime.list.isApproved": true,
          "orders.shiftsAndTime.list.isSent": false,
          "orders.shiftsAndTime.list.isReceived": false
        }
      },
      {
        $project: {
          "_id": 0,
          "name": "$orders.shiftsAndTime.list.name",
          "qty": "$orders.shiftsAndTime.list.qty",
          "unit": "$orders.shiftsAndTime.list.unit",
          "orderProductId": "$orders.shiftsAndTime.list.orderProductId"
        }
      }
    ];

    info.info(`tpBillOrderList billId:${billId} pipeline:${JSON.stringify(pipeline)}`);
    const listDetails = await collection.aggregate(pipeline).toArray();
    if(listDetails.length > 0)
    {
      info.info(`tpBillOrderList billId:${billId} data fetched`);
      res.status(200).json(generateResponse("Data fetched..", 200, "Success", listDetails));
    }
    else{
      error.error(`tpBillOrderList billId:${billId} error: no data found`);
      res.status(404).send(generateResponse("No data found", 404, "failed"));
    }
  }
  catch(err: any)
  {
    error.error(`tpBillOrderList billId:${billId} error:${err.message}`);
    res.status(500).json(generateResponse("Internal server error", 500, "Failed"));
  }
}

export async function sendOrder(req: Request, res: Response) {
  const { id } = req.params;
  info.info(`sendOrder id: ${id} initiated`);
  info.info(`sendOrder id:${id} req.query: ${JSON.stringify(req.query)}`);
  info.info(`sendOrder id:${id} req.params: ${JSON.stringify(req.params)}`);
  const {billId, qty} = req.query;
  if(!billId || !qty){
   error.error(`sendOrder id:${id} error: invaild arguments`);
   return res.status(400).json(generateResponse(`Invalid arguments`,400,`failed`))
  }

  try {

    const updatedData = {
      "orders.$[outer].shiftsAndTime.$[inner].list.$[listElem].isSent": true,
      "orders.$[outer].shiftsAndTime.$[inner].list.$[listElem].sentQty": qty,
      updateAt: new Date()
    };
    info.info(`sendOrder id:${id} updatedData:${JSON.stringify(updatedData)}`);

    await collection.updateOne(
      {
        billId,
        "orders.shiftsAndTime.list": { $elemMatch: { "orderProductId": id } }
      },
      {
        $set: updatedData,
      },
      {
        arrayFilters: [
          { "outer.shiftsAndTime.list": { $elemMatch: { orderProductId: id } } },
          { "inner.list.orderProductId": id },
          { "listElem.orderProductId": id }
        ]
      }
    );

    info.info(`sendOrder id:${id} updated successfully`);
    res.status(200).json(generateResponse("Order sent successfully...", 200, "Success"));
  } catch (err: any) {
    error.error(`sendOrder id:${id} error:${err.message}`);
    res.status(500).json(generateResponse("Internal server error", 500, "Failed"));
  }
}

//received div apis

export async function tPDivBillList (req: Request, res: Response) {
  const {divId} = req.query;
  info.info(`tPDivBillList initiated`);
  info.info(`tPDivBillList divId:${divId} req.query:${JSON.stringify(req.query)}`)
  if(!divId){
    error.error(`tPDivBillList error: divId missing`);
    return res.status(400).json(generateResponse(`branchId missing..`,400,`failed`));
  }
  try{
    const pipeline = [
      {
        $match: {
          divId,
          isDeleted: false,
          "orders.shiftsAndTime.list": {
            $elemMatch: { 
              "isSent": { $ne: false },
              "isReceived": {$ne: true}
          }
          }
        }
      },
      {
        $project: {
          "_id": 1,
          "billId": 1,
        }
      }
    ];
    info.info(`tPDivBillList divId:${divId} pipeline:${JSON.stringify(pipeline)}`);
    const orderData = await collection.aggregate(pipeline).toArray();
    if(orderData.length > 0)
    {
      res.status(200).json(generateResponse("Data fetched..", 200, "Success", orderData));
      info.info(`tPDivBillList divId: ${divId} data fetched`);
    }
    else{
      error.error(`tPDivBillList divId:${divId} error: no data found`);
      res.status(404).send(generateResponse("No data found", 404, "failed"));
    }
  }
  catch(err: any){
    error.error(`tPDivBillList divId:${divId} error:${err.message}`);
    res.status(500).json(generateResponse("Internal server error", 500, "Failed"))
  }
}

export async function tpDivBillOrderList (req: Request, res: Response) {
  const billId = req.params.id;
  info.info(`tpDivBillOrderList billId:${billId} initiated`);
  info.info(`tpDivBillOrderList billId:${billId} req.query:${JSON.stringify(req.query)}`);
  const {divId} = req.query;
  if(!divId){
    error.error(`tpDivBillOrderList error: divId missing`);
    return res.status(400).json(generateResponse(`branchId missing..`,400,`failed`));
  }
  try{
    const pipeline = [
      {
        $match: {
          divId,
          isDeleted: false,
          billId,
          "orders.shiftsAndTime.list": {
            $elemMatch: {
              "isApproved": true,
              "isSent": true,
              "isReceived": false
            }
          }
        }
      },
      {
        $unwind: "$orders"
      },
      {
        $unwind: "$orders.shiftsAndTime"
      },
      {
        $unwind: "$orders.shiftsAndTime.list"
      },
      {
        $match: {
          "orders.shiftsAndTime.list.isApproved": true,
          "orders.shiftsAndTime.list.isSent": true,
          "orders.shiftsAndTime.list.isReceived": false
        }
      },
      {
        $project: {
          "_id": 0,
          "name": "$orders.shiftsAndTime.list.name",
          "qty": "$orders.shiftsAndTime.list.qty",
          "unit": "$orders.shiftsAndTime.list.unit",
          "orderProductId": "$orders.shiftsAndTime.list.orderProductId"
        }
      }
    ];

    info.info(`tpDivBillOrderList billId:${billId} pipeline:${JSON.stringify(pipeline)}`);
    const listDetails = await collection.aggregate(pipeline).toArray();
    if(listDetails.length > 0)
    {
      res.status(200).json(generateResponse("Data fetched..", 200, "Success", listDetails));
      info.info(`tpDivBillOrderList divId:${divId} data fetched`);
    }
    else{
      error.error(`tpDivBillOrderList divId:${divId} error: no data found`);
      res.status(404).send(generateResponse("No data found", 404, "failed"));
    }
  }
  catch(err: any)
  {
    error.error(`tpDivBillOrderList billId:${billId} error:${err.message}`);
    res.status(500).json(generateResponse("Internal server error", 500, "Failed"));
  }
}

export async function receiveOrder(req: Request, res: Response) {
  const { id } = req.params;
  info.info(`receiveOrder id:${id} initiated`);
  info.info(`receiveOrder id:${id} req.params:${JSON.stringify(req.params)}`);
  info.info(`receiveOrder id:${id} req.query:${JSON.stringify(req.query)}`);
  const {billId, qty} = req.query;
  if(!billId || !qty){
    error.error(`receiveOrder id:${id} error: Invalid arguments`)
    return res.status(400).json(generateResponse(`Invalid arguments..`,400,`failed`))
  }
  try {

    const updatedData = 
    {
      "orders.$[outer].shiftsAndTime.$[inner].list.$[listElem].isReceived": true,
      "orders.$[outer].shiftsAndTime.$[inner].list.$[listElem].receivedQty": qty,
      updateAt: new Date()
    };
    info.info(`receiveOrder billId:${billId} id:${id} updatedData:${JSON.stringify(updatedData)}`);

    await collection.updateOne(
      {
        billId,
        "orders.shiftsAndTime.list": { $elemMatch: { "orderProductId": id } }
      },
      {
        $set: updatedData,
      },
      {
        arrayFilters: [
          { "outer.shiftsAndTime.list": { $elemMatch: { orderProductId: id } } },
          { "inner.list.orderProductId": id },
          { "listElem.orderProductId": id }
        ]
      }
    );

    info.info(`receiveOrder billId:${billId} id:${id} updated successfully`)
    res.status(200).json(generateResponse("Order received successfully...", 200, "Success"));
  } catch (err: any) {
    error.error(`receiveOrder billId:${billId} id:${id} error:${err.message}`);
    res.status(500).json(generateResponse("Internal server error", 500, "Failed"));
  }
}

export async function getOrderDetails(procedureId: any, orgId: any, shift: any, orderedDate: any) {
  info.info(`getOrderDetails initialized`);
  info.info(`getOrderDetails params: procedureId: ${procedureId}, orgId: ${orgId}, shift: ${shift}, orderedDate: ${orderedDate}`)
  try {
    const pipeline = [
      {
        $match: {
          orgId: orgId,
          'orders.shiftsAndTime.shift': shift,
          'orders.orderedDate': orderedDate,
          $or: [
            {
              'orders.shiftsAndTime.list.procedureId': procedureId,
              'orders.shiftsAndTime.list.isApproved': false,
            },
            {
              'orders.shiftsAndTime.list.groupProducts': {
                $elemMatch: {
                  procedureId: procedureId,
                  isApproved: false
                }
              }
            }
          ]
        },
      },
      {
        $unwind: '$orders',
      },
      {
        $unwind: '$orders.shiftsAndTime',
      },
      {
        $unwind: '$orders.shiftsAndTime.list',
      },
      {
        $match: {
          orgId: orgId,
          'orders.shiftsAndTime.shift': shift,
          'orders.orderedDate': orderedDate,
          $or: [
            {
              'orders.shiftsAndTime.list.procedureId': procedureId,
              'orders.shiftsAndTime.list.isApproved': false,
            },
            {
              'orders.shiftsAndTime.list.groupProducts': {
                $elemMatch: {
                  procedureId: procedureId,
                  isApproved: false
                }
              }
            }
          ]
        },
      },
      {
        $project: {
          divId: '$divId',
          orgId: '$orgId',
          divName: "$divName",
          matchingItems: {
            $filter: {
              input: {
                $concatArrays: [
                  [
                    {
                      type: 'list',
                      name: '$orders.shiftsAndTime.list.name',
                      qty: '$orders.shiftsAndTime.list.qty',
                      unit: '$orders.shiftsAndTime.list.unit',
                      procedureId: '$orders.shiftsAndTime.list.procedureId',
                      isApproved: '$orders.shiftsAndTime.list.isApproved',
                    }
                  ],
                  {
                    $map: {
                      input: '$orders.shiftsAndTime.list.groupProducts',
                      as: 'groupProduct',
                      in: {
                        type: 'groupProduct',
                        name: '$$groupProduct.name',
                        qty: '$$groupProduct.qty',
                        unit: '$$groupProduct.unit',
                        procedureId: '$$groupProduct.procedureId',
                        isApproved: '$$groupProduct.isApproved',
                      }
                    }
                  }
                ]
              },
              as: 'item',
              cond: {
                $eq: ['$$item.procedureId', procedureId]
              }
            }
          }
        },
      },
      {
        $unwind: '$matchingItems',
      },
    ];
    
    info.info(`getOrderDetails orgId:${orgId} pipeline:${JSON.stringify(pipeline)}`);
    const result = await collection.aggregate(pipeline).toArray();
    info.info(`getOrderDetails orgId:${orgId} completed`);
    return (result);
  } catch (err:any) {
    error.error(`getOrderDetails orgId:${orgId} error: ${err.message}`)
    return [];
  }
}


export const supplyOrder = async (procedureId: any, orderedDate: any, orgId: any, shift: any, oldProcedureId?: any) => {
  info.info(`supplyOrder initialized`);
  info.info(`supplyOrder params: procedureId :${procedureId}, orderedDate: ${orderedDate}, orgId:${orgId}, shift:${shift} oldProcedureId:${oldProcedureId}`)
  try {

    const updateGroupProducts = {
      $set: {
        'orders.$[].shiftsAndTime.$[].list.$[].groupProducts.$[groupItem].procedureId': procedureId,
        'orders.$[].shiftsAndTime.$[].list.$[].groupProducts.$[groupItem].isApproved': true,
      },
    };
    
    const groupProductsArrayFilters = [
      { 'groupItem.procedureId': oldProcedureId || procedureId }
    ];
    
    const data = await collection.updateMany({
      'orders.orderedDate': orderedDate,
      'orgId': orgId,
      'orders.shiftsAndTime.list.groupProducts.procedureId': oldProcedureId || procedureId,
      'orders.shiftsAndTime.shift': shift,
      'orders.shiftsAndTime.isOrderApproved': true,
      'orders.shiftsAndTime.list.isApproved': false,
    }, updateGroupProducts, { arrayFilters: groupProductsArrayFilters });


    const filter = {
      'orders.orderedDate': orderedDate,
      'orgId': orgId,
      'orders.shiftsAndTime.list.procedureId': oldProcedureId || procedureId,
      'orders.shiftsAndTime.shift': shift,
      'orders.shiftsAndTime.isOrderApproved': true,
      'orders.shiftsAndTime.list.isApproved': false,
    };
    info.info(`supplyOrder filter:${JSON.stringify(filter)}`);

    let update = {
      $set: {
        'orders.$[order].shiftsAndTime.$[shift].list.$[item].isApproved': true,
        'orders.$[order].shiftsAndTime.$[shift].list.$[item].procedureId': procedureId,
      },
    };
    info.info(`supplyOrder updateData:${JSON.stringify(update)}`);

    const arrayFilters = [
      { 'order.orderedDate': orderedDate },
      { 'shift.shift': shift },
      { 'item.procedureId': oldProcedureId || procedureId },
    ];
    info.info(`supplyOrder arrayFilters:${JSON.stringify(arrayFilters)}`);

    const result = await collection.updateMany(filter, update, { arrayFilters });

    const result2 = await collection.updateMany(
      {
        orgId: orgId,
        isDeleted: false,
        "orders.shiftsAndTime.list.isApproved": false,
        "orders.shiftsAndTime.list.isProduct": false,
        "orders.shiftsAndTime.list.isProcedure": false,
        "orders.shiftsAndTime.list.groupProducts": {
          $not: {
            $elemMatch: { isApproved: false }
          }
        }
      },
      {
        $set: {
          "orders.$[].shiftsAndTime.$[j].list.$[k].isApproved": true
        }
      },
      {
        arrayFilters: [
          { "j.isOrderApproved": true },
          { "k.isApproved": false }
        ]
      }
    );
    
    info.info(`supplyOrder completed`)
    return true;

  } catch (err: any) {
    error.error(`supplyOrder error:${err.message}`)
    return false;
  }

};


export async function getOrderReport(req: Request, res: Response) {
  const { divId } = req.params;
  info.info(`getOrderReport divId:${divId} initialized`);
  info.info(`getOrderReport divId:${divId} req.params: ${JSON.stringify(req.params)}`);
  info.info(`getOrderReport divId:${divId} req.query: ${JSON.stringify(req.query)}`);

  try {
    const { date, dateStart, dateEnd, month } = req.query;

    let pipeline: any[] = [];

    if (date) {
      pipeline = [
        {
          $match: {
            'orders.orderedDate': date,
            'orders.shiftsAndTime.list.isApproved': true,
            isDeleted: false,
            divId
          },
        },
        {
          $unwind: '$orders',
        },
        {
          $match: {
            'orders.orderedDate': date,
          },
        },
      ];
    } else if (dateStart && dateEnd) {
      pipeline = [
        {
          $match: {
            'orders.orderedDate': {
              $gte: dateStart,
              $lte: dateEnd,
            },
            'orders.shiftsAndTime.list.isApproved': true,
            'orders.shiftsAndTime.list.isDeleted': false,
            divId
          },
        },
        {
          $unwind: '$orders',
        },
        {
          $match: {
            'orders.orderedDate': {
              $gte: dateStart,
              $lte: dateEnd,
            },
          },
        },
      ];
    } else if (month) {
      const { firstDayOfMonth, lastDayOfMonth } = monthCal(month as string);
      pipeline = [
        {
          $match: {
            'orders.orderedDate': {
              $gte: firstDayOfMonth,
              $lt: lastDayOfMonth,
            },
            'orders.shiftsAndTime.list.isApproved': true,
            'orders.shiftsAndTime.list.isDeleted': false,
            divId
          },
        },
        {
          $unwind: '$orders',
        },
        {
          $match: {
            'orders.orderedDate': {
              $gte: firstDayOfMonth,
              $lt: lastDayOfMonth,
            },
          },
        },
      ];
    }

    pipeline.push(
      {
        $unwind: {
          path: '$orders.shiftsAndTime',
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $unwind: {
          path: '$orders.shiftsAndTime.list',
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $match: {
          'orders.shiftsAndTime.list.isApproved': true,
        },
      },
      {
        $group: {
          _id: {
            productId: '$orders.shiftsAndTime.list.productId',
            procedureId: '$orders.shiftsAndTime.list.procedureId',
            isProcedure: '$orders.shiftsAndTime.list.isProcedure',
            isProduct: '$orders.shiftsAndTime.list.isProduct',
            shift: '$orders.shiftsAndTime.shift',
            name: '$orders.shiftsAndTime.list.name',
            qty: '$orders.shiftsAndTime.list.qty',
            unit: '$orders.shiftsAndTime.list.unit',
            orderedDate: '$orders.orderedDate',
            divId: '$divId', 
          },
        },
      },
      {
        $project: {
          _id: 0,
          name: '$_id.name',
          qty: '$_id.qty',
          unit: '$_id.unit',
          procedureId: '$_id.procedureId',
          orderedDate: '$_id.orderedDate',
          isProcedure: '$_id.isProcedure',
          isProduct: '$_id.isProduct',
          divId: '$_id.divId',
        },
      },
    );
    info.info(`getOrderReport divId:${divId} pipeline:${JSON.stringify(pipeline)}`);

    const result = await collection.aggregate(pipeline).toArray();
    if(result.length > 0)
    {
      info.info(`getOrderReport completed data: ${JSON.stringify(result)}`);
      res.status(200).json(generateResponse(`Data fetched..`, 200, 'success', result));
    }
    else{
      error.error(`getOrderReport divId:${divId} error: no data found`);
      res.status(404).send(generateResponse("No data found", 404, "failed"));
    }
  } catch (err: any) {
    res.status(500).json(generateResponse(`Internal server error`, 500, 'failed'));
    error.error(`getOrderReport divId:${divId} error: ${err.message}`);
  }
}

export async function getAnOrderByDateWise(req: Request, res: Response) {
  const { divId } = req.params;
  info.info(`getOrderReport divId:${divId} initialized`);
  info.info(`getOrderReport divId:${divId} req.query: ${JSON.stringify(req.query)}`);
  info.info(`getOrderReport divId:${divId} req.params: ${JSON.stringify(req.params)}`);

  try {
    const { procedureId,date, dateStart, dateEnd, month } = req.query;
    if(!date || !procedureId){
      error.error(`getAnOrderByDateWise error: date or procedureId missing`);
      res.status(400).json(generateResponse(`date or procedureId missing`,400,`failed`))
    }
    let pipeline: any[] = [];

    if (date) {
      pipeline = [
        {
          $match: {
            'orders.orderedDate': date,
            'orders.shiftsAndTime.list.isApproved': true,
            $or: [
              {
                'orders.shiftsAndTime.list.procedureId': procedureId,
              },
              {
                'orders.shiftsAndTime.list.groupProducts': {
                  $elemMatch: {
                    procedureId: procedureId,
                  }
                }
              }
            ],
            isDeleted: false,
            divId
          },
        },
        {
          $unwind: '$orders',
        },
        {
          $match: {
            'orders.orderedDate': date,
          },
        },
        {
          $unwind: {
            path: '$orders.shiftsAndTime.list.groupProducts',
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $match: {
            $or: [
              {
                'orders.shiftsAndTime.list.procedureId': procedureId,
              },
              {
                'orders.shiftsAndTime.list.groupProducts.procedureId': procedureId,
              },
            ],
            'orders.shiftsAndTime.list.isApproved': true,
          },
        },
      ];
    } else if (dateStart && dateEnd) {
      pipeline = [
        {
          $match: {
            'orders.orderedDate': {
              $gte: dateStart,
              $lte: dateEnd,
            },
            $or: [
              {
                'orders.shiftsAndTime.list.procedureId': procedureId,
              },
              {
                'orders.shiftsAndTime.list.groupProducts': {
                  $elemMatch: {
                    procedureId: procedureId,
                  }
                }
              }
            ],
            'orders.shiftsAndTime.list.isApproved': true,
            isDeleted: false,
            divId
          },
        },
        {
          $unwind: '$orders',
        },
        {
          $match: {
            'orders.orderedDate': {
              $gte: dateStart,
              $lte: dateEnd,
            },
          },
        },
      ];
    } else if (month) {
      const { firstDayOfMonth, lastDayOfMonth } = monthCal(month as string);
      pipeline = [
        {
          $match: {
            'orders.orderedDate': {
              $gte: firstDayOfMonth,
              $lt: lastDayOfMonth,
            },
            $or: [
              {
                'orders.shiftsAndTime.list.procedureId': procedureId,
              },
              {
                'orders.shiftsAndTime.list.groupProducts': {
                  $elemMatch: {
                    procedureId: procedureId,
                  }
                }
              }
            ],
            'orders.shiftsAndTime.list.isApproved': true,
            isDeleted: false,
            divId
          },
        },
        {
          $unwind: '$orders',
        },
        {
          $match: {
            'orders.orderedDate': {
              $gte: firstDayOfMonth,
              $lt: lastDayOfMonth,
            },
          },
        },
      ];
    }

    pipeline.push(
      {
        $unwind: '$orders',
      },
      {
        $unwind: '$orders.shiftsAndTime',
      },
      {
        $unwind: '$orders.shiftsAndTime.list',
      },
      {
        $match: {
          divId,
          $or: [
            {
              'orders.shiftsAndTime.list.procedureId': procedureId,
            },
            {
              'orders.shiftsAndTime.list.groupProducts': {
                $elemMatch: {
                  procedureId: procedureId,
                },
              },
            },
          ],
        },
      },
      {
        $project: {
          _id: 0,
          "orders.orderedDate": 1,
          matchingItems: {
            $filter: {
              input: {
                $concatArrays: [
                  [
                    {
                      name: '$orders.shiftsAndTime.list.name',
                      qty: '$orders.shiftsAndTime.list.qty',
                      unit: '$orders.shiftsAndTime.list.unit',
                      procedureId: '$orders.shiftsAndTime.list.procedureId',
                    },
                  ],
                  {
                    $map: {
                      input: '$orders.shiftsAndTime.list.groupProducts',
                      as: 'groupProduct',
                      in: {
                        name: '$$groupProduct.name',
                        qty: '$$groupProduct.qty',
                        unit: '$$groupProduct.unit',
                        procedureId: '$$groupProduct.procedureId',
                      },
                    },
                  },
                ],
              },
              as: 'item',
              cond: {
                $eq: ['$$item.procedureId', procedureId],
              },
            },
          },
        },
      },
      {
        $unwind: '$matchingItems',
      },
    )
    info.info(`getOrderReport divId:${divId} pipeline:${JSON.stringify(pipeline)}`);

    const result = await collection.aggregate(pipeline).toArray();
    if(result.length > 0)
    {
      info.info(`getOrderReport divId:${divId} completed`);
      res.status(200).json(generateResponse(`Data fetched..`, 200, 'success', result));
    }
    else{
      error.error(`getOrderReport divId:${divId} error: no data found`);
      res.status(404).send(generateResponse("No data found", 404, "failed"));
    }
  } catch (err: any) {
    res.status(500).json(generateResponse(`Internal server error`, 500, 'failed'));
    error.error(`getOrderReport divId:${divId} error: ${err.message}`);
  }
}


export async function receivedOrderList(orgId: any) {  // procedureId list for procedure controller
  try {
    const aggregationPipeline = [
      {
        $match: {
          'orgId': orgId,
          'orders.shiftsAndTime.list.isReceived': true 
        }
      },
      {
        $unwind: '$orders'
      },
      {
        $unwind: '$orders.shiftsAndTime'
      },
      {
        $match: {
          'orders.shiftsAndTime.list.isReceived': true 
        }
      },
      {
        $unwind: '$orders.shiftsAndTime.list'
      },
      {
        $project: {
          _id: 1, 
          orderProductId: '$orders.shiftsAndTime.list.orderProductId',
          isProduct: '$orders.shiftsAndTime.list.isProduct',
          isProcedure: '$orders.shiftsAndTime.list.isProcedure',
          name: '$orders.shiftsAndTime.list.name',
          procedureId: '$orders.shiftsAndTime.list.procedureId',
          qty: '$orders.shiftsAndTime.list.qty',
          unit: '$orders.shiftsAndTime.list.unit',
          isApproved: '$orders.shiftsAndTime.list.isApproved',
          groupProducts: '$orders.shiftsAndTime.list.groupProducts' 
        }
      },
      {
        $unwind: {
          path: '$groupProducts',
          preserveNullAndEmptyArrays: true 
        }
      },
      {
        $project: {
          _id: 0,
          qty: { $ifNull: ['$groupProducts.qty', '$qty'] },
          name: { $ifNull: ['$groupProducts.name', '$name'] }, 
          unit: { $ifNull: ['$groupProducts.unit', '$unit'] },
          procedureId: { $ifNull: ['$groupProducts.procedureId', '$procedureId'] },
        }
      }
    ];

    const result = await collection.aggregate(aggregationPipeline).toArray();
    return result;
  } catch (err) {
    throw err;
  }
}


export async function orderHistory(req: Request, res: Response) {
  try {
    const procedureId = req.query.id as string;
    if (!procedureId) {
        return res.status(400).json({ error: 'ProcedureId is required.' });
    }
    let {fromDate , toDate , date, month} = req.query 
    info.info(`orderHistory req.query:${JSON.stringify(req.query)}`)
    if(date){
      fromDate = date
      toDate = date
    }
    
    if(month){
      const{ firstDayOfMonth , lastDayOfMonth} = monthCal(month as string)
      fromDate = firstDayOfMonth,
      toDate = lastDayOfMonth
    }

    const result = await collection.find({
      $or: [
          {
              'orders.shiftsAndTime.list': {
                  $elemMatch: { procedureId, isApproved: true }
              },
              'orders.orderedDate' : {
                $gte : fromDate,
                $lte: toDate
              },
              "orders.shiftsAndTime.isDeleted": false
          },
          {
            'orders.shiftsAndTime.list.groupProducts': {
                $elemMatch: { procedureId, isApproved: true }
            },
            'orders.orderedDate' : {
              $gte : fromDate,
              $lte : toDate
            },
            "orders.shiftsAndTime.isDeleted": false
        }
      ]
    }).toArray();

    const productsMap: { [key: string]: any } = {};

    result.forEach((res: any) => {
      res.orders.forEach((order: any) => {
        const key = `${res.divId}_${order.orderedDate}`; 

        order.shiftsAndTime.forEach((st: any) => {
          st.list.forEach((li: any) => {
            
            if (li.procedureId === procedureId) {
              const productKey = `${li.name}_${key}`;
              if (!productsMap[productKey]) {
                productsMap[productKey] = {
                  orgId: res.orgId,
                  divId: res.divId,
                  divName: res.divName,
                  name: li.name,
                  qty: li.qty,
                  unit: li.unit,
                  orderedDate: order.orderedDate
                };
              } else {
                productsMap[productKey].qty += li.qty;
              }
            }
            if (li.groupProducts && li.groupProducts.length > 0) {
              li.groupProducts.forEach((prod: any) => {
                if (prod.procedureId === procedureId) {
                  const productKey = `${prod.name}_${key}`;
                  if (!productsMap[productKey]) {
                    productsMap[productKey] = {
                      orgId: res.orgId,
                      divId: res.divId,
                      divName: res.divName,
                      name: prod.name,
                      qty: prod.qty,
                      unit: prod.unit,
                      orderedDate: order.orderedDate
                    };
                  } else {
                    productsMap[productKey].qty += prod.qty;
                  }
                }
              });
            }
          });
        });
      });
    });

    let totalQty = 0;
    for (const key in productsMap) {
      if (Object.prototype.hasOwnProperty.call(productsMap, key)) {
        totalQty += productsMap[key].qty;
      }
    }

    const products = Object.values(productsMap);
    info.info(`orderHistory data fetched..`)
    res.status(200).json(generateResponse(`Data fetched.`, 200, 'success', {products, totalQty}));
  } catch (err: any) {
    res.status(500).json(generateResponse(`Internal server error`, 500, 'failed'));
    error.error(`orderHistory error message :${err.message}`)
  }
}

