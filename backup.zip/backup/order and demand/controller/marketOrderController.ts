import { Request, Response } from "express";
import { info, error } from "../config/loggerConfig";
import { marketOrder } from "../model/marketOrderModel";
import { generateResponse } from "../utils/responseGenerate";
import { createMOrderId } from "../utils/idGenerate";
import moment from 'moment';
import axios from "axios";
import { itemDeliverySingleDateData } from "./storeDemandController";
let currentDate: moment.Moment = moment();

const baseURL = process.env.BASE_URL;
const productServicePort = process.env.PRODUCT_SERVICE_PORT;

let collection : any;

export async function marketInstance(){
    collection = await marketOrder();
};

export async function createMOrder ( req: Request, res: Response ) {
    info.info(`createMOrder initiated`);
    info.info(`createMOrder reqBody:${JSON.stringify(req.body)}`);
    info.info(`createMOrder req.query:${JSON.stringify(req.query)}`);
    try {
        const { name, qty, supplier, itemId,sectionName,unit, } = req.body;
        const { orgId } = req.query;
        if(!name || !qty || !supplier || !itemId || !sectionName || !unit || name == "" || qty == 0 || supplier == "" || itemId =="" || sectionName == "" || unit == "" )
        {
          error.error(`createMOrder error: Arguments missing`);
          return res.status(400).json(generateResponse("Invalid arguments...", 400, "failed"));
        }
        if(!orgId){
          error.error(`createMOrder error: orgId missing`);
          return res.status(400).json(generateResponse("Company id missing", 400, "failed"));
        }
        const date = new Date();
        const orderedDate: string= currentDate.format('YYYY-MM-DD');
        const productApiEndpoint = `http://${baseURL}:${productServicePort}/api/productServices/itemSupplierValidate?itemId=${itemId}&supplier=${supplier}`;
        const response = await axios.put(productApiEndpoint).then((result) => {
          info.info(`createMOrder supplier verification(S-S) success`);
        }).catch((err: any) => {
          error.error(`createMOrder supplier verification(S-S) error`);
        });
        const id = await createMOrderId();
        const createdData = {
            _id: id,
            orgId,
            name,
            itemId,
            orderedQty: qty,
            suppliedQty: 0,
            supplier,
            sectionName,
            unit,
            isDeleted:false,
            isDelivered: false,
            isStored: false,
            createdAt: date,
            updatedAt: date,
            orderedDate: orderedDate
        };
        await collection.insertOne(createdData);
        info.info(`createMOrder data inserted:${JSON.stringify(createdData)}`);
        res.status(200).json(generateResponse("Market Order created successfully..", 200, "Success"));
    }
    catch(err:  any) {
        error.error(`createMOrder error:${err.message}`);
        res.status(500).json(generateResponse(err.message, err.status, "Failed"));
    }

};

export const allMOrders = async (req: Request, res: Response) => {
    info.info(`allMOrders initiated`);
    info.info(`allMOrders req.query ${JSON.stringify(req.query)}`);

    let page = parseInt(req.query.page as string, 10) || 1;
    let pageSize = parseInt(req.query.pageSize as string, 10) || 10;
    const {orgId, orderedDate} = req.query;
    
    if(!orgId || orgId=="")
    {
      error.error(`allMOrders error: orgId missing`);
      return res.status(400).json(generateResponse("Company id missing", 400, "failed"));
    }
    if(!orderedDate || orderedDate == "")
    {
      error.error(`allMOrders orgId:${orgId} error: orderedDate missing`);
      return res.status(400).json(generateResponse("Ordered date missing", 400, "failed"));
    }
    const skip = (page - 1) * pageSize;

    const project = {
        _id: 1,
        orgId: 1,
        name: 1,
        sectionName: 1,
        orderedQty:1,
        suppliedQty:1,
        unit:1,
        supplier:1,
        isDelivered: 1,
        isStored: 1,
        orderedDate: 1,
        deliveredDate: 1,
    };
    try {
      const pipeLine =[
        { $match: { orgId, isDeleted: false, orderedDate } },
        { $project: project },
        {
            $facet: {
                data: [
                    { $skip: skip },
                    { $limit: Number(pageSize) }
                ],
                total: [
                    { $count: 'count' }
                ]
            }
        }
    ]

      info.info(`allMOrders orgId:${orgId} pipeLine:${JSON.stringify(pipeLine)}`);

      const result = await collection
          .aggregate(pipeLine)
          .toArray();

      const list = result[0]?.data || [];
      const total = result[0]?.total[0]?.count || 0;

      const response = generateResponse("data fetched...", 200, "success", {
          totalCount :total,
          list,
      });
      info.info(`allMOrders data fetched`);
      res.status(200).json(response);
    } catch (err: any) {
        const response = generateResponse("Internal server error", 500, "failed");
        error.error(`allMOrders errMessage: ${err.message}`);
        res.status(500).json(response);
    }
};

export const editMOrder = async(req: Request, res: Response)=>{
    info.info(`editMOrder Intialized`);
    info.info(`editMOrder req.params ${JSON.stringify(req.params)}`);
    info.info(`editMOrder req.body ${JSON.stringify(req.body)}`);
    info.info(`editMOrder req.query: ${JSON.stringify(req.query)}`);

    const {id} = req.params;
    const {orgId} =  req.query;
    const {name, itemId, qty, supplier} = req.body;
    if(!name || name == "" || !itemId || itemId == "" || !qty || qty == 0|| supplier == "" || !supplier)
    {
      error.error(`editMOrder id:${id} error: Invalid arguments`);
      return res.status(400).json(generateResponse("Invalid arguments", 400, "failed"));
    }
    if(!orgId || orgId =="")
    {
      error.error(`editMOrder id:${id} error: orgId missing`);
      return res.status(400).send(generateResponse("Company id missing", 400, "failed"));
    }
    const updatedData ={
        name,
        itemId,
        orderedQty: qty,
        supplier,
        updatedAt : new Date()
    }
    try {
      const marketOrderData = await collection.findOne({_id: id, orgId, isDeleted: false});
      if(!marketOrderData)
      {
        error.error(`editMOrder id:${id} error: id not found`);
        return res.status(400).send(generateResponse("Order not found", 400, "failed"));
      }
        const productApiEndpoint = `http://${baseURL}:${productServicePort}/api/productServices/itemSupplierValidate?itemId=${req.body.itemId}&supplier=${req.body.supplier}`;
        const response = await axios.put(productApiEndpoint).then((result: any) => {
          info.info(`editMOrder id:${id} item supplier verification(S-S) success`);
        }).catch((err: any) => {
        error.error(`editMOrder id:${id} item supplier verification(S-S) error`);
        });
        await collection.findOneAndUpdate(
        {_id:id, orgId },
        {$set : updatedData}
        );
        info.info(`editMOrder id:${id} updatedData:${JSON.stringify(updatedData)}`);
        info.info(`editMOrder id:${id} updation completed`)
        res.status(200).json(generateResponse("Item updated...",200,"success"))
    } catch (err:any) {
        error.error(`editMOrder id:${id} error: ${err.message}`)      
        res.status(500).json(generateResponse("Internal server error",500,"failed"))
    }
};

export async function deleteMOrder ( req: Request, res: Response ) {
    const {id} = req.params;
    info.info(`deleteMOrder req.params: ${JSON.stringify(req.params)}`);
    info.info(`deleteMOrder req.query: ${JSON.stringify(req.query)}`);
    const {orgId} = req.query;
    if(!orgId || orgId == "")
    {
      error.error(`deleteMOrder id:${id} error: orgId missing`);
      return res.status(400).send(generateResponse("Company id missing", 400, "failed"));
    }
    try{
        info.info(`deleteMOrder id:${id} initiated`);
        await collection.findOneAndUpdate({_id: id, orgId},
             { $set: {isDeleted: true, updatedAt: new Date()}});
        info.info(`deleteMOrder id:${id} deleted`);
        res.status(200).json(await generateResponse("Market Order deleted successfully..", 200, "Success"));
    }
    catch(err: any)
    {
        error.error(`deleteMOrder id:${id} error:${err.message}`)      
        res.status(500).json(generateResponse("Internal server error",500,"failed"))
    }
}

export async function mOrderDelivered (req: Request, res: Response) {
  const {id} = req.params;
  info.info(`mOrderDelivered id:${id} initiated`);
  info.info(`mOrderDelivered id:${id} req.body:${JSON.stringify(req.body)}`);
  info.info(`mOrderDelivered id:${id} req.query:${JSON.stringify(req.query)}`);

  const {qty, price, supplier, itemId} = req.body;
  const {orgId} =  req.query;
  if(!qty || qty == 0 || !supplier || supplier == "" || !itemId || itemId == "" || price == undefined)
  {
    error.error(`mOrderDelivered id:${id} error: Arguments missing`);
    return res.status(400).send(generateResponse("Missing argumets", 400, "failed"));
  }
  if(!orgId || orgId == "")
  {
    error.error(`mOrderDelivered id:${id} error: orgId missing`);
    return res.status(400).send(generateResponse("Company id missing", 400, "failed"));
  }
    try {
        try{
          const perUnitPrice = price/qty;
          let deliveredDate: string = currentDate.format('YYYY-MM-DD');
          info.info(`mOrderDelivered id:${id} perUnitPrice:${perUnitPrice}`);

          const updatedData = {isDelivered: true, price: perUnitPrice, supplier, deliveredDate, updatedAt: new Date()}
          info.info(`mOrderDelivered id:${id} updatedData:${JSON.stringify(updatedData)}`);

          const productApiEndpoint = `http://${baseURL}:${productServicePort}/api/productServices/itemSupplierValidate?itemId=${itemId}&supplier=${supplier}`;
          const response = await axios.put(productApiEndpoint).then((result: any) => {
            info.info(`editMOrder id:${id} itemId:${itemId} item supplier verification(S-S) success`);
          }).catch((err: any) => {
            error.error(`editMOrder id:${id} itemId:${itemId} item supplier verification(S-S) error`);
          });
          await collection.findOneAndUpdate(
              { _id: id, orgId, isDeleted: false, isDelivered: false, isStored: false}, 
              { $set: updatedData}, 
              { new: true});
        info.info(`mOrderDelivered id:${id} updated successfully`);
        res.status(200).json(generateResponse("Order delivered..", 200, "Success"));
        }
        catch(err: any){
            error.error(`mOrderDelivered id:${id} notUpdated err:${err.message}`);
            res.status(400).json(await generateResponse("Invalid arguments..", 400, "Failed"));
        }
    }
    catch(err: any)
    {
        error.error(`mOrderDelivered itemId:${itemId} error:${err.message}`)      
        res.status(500).json(generateResponse("Internal server error",500,"failed"))
    }
}

export async function mOrderStored (req: Request, res: Response) {
  const {id} = req.params;
  info.info(`mOrderStored id:${id} initiated`);
  info.info(`mOrderStored id:${id} req.params:${JSON.stringify(req.params)}`)
  info.info(`mOrderStored id:${id} req.body:${JSON.stringify(req.body)}`)
  info.info(`mOrderStored id:${id} req.query:${JSON.stringify(req.query)}`);
  const {qty, itemId} = req.body;
  const {orgId} = req.query;
  if(!qty || qty == 0 || !itemId || itemId == "" )
  {
    error.error(`mOrderStored id:${id} error: invalid arguments`);
    return res.status(400).send(generateResponse("Invalid arguments", 400, "failed"));
  }
  if(!orgId || orgId =="")
  {
    error.error(`mOrderStored id:${id} error: orgId missing`);
    return res.status(400).send(generateResponse("Invalid arguments", 400, "failed"));
  }
  try {
        let sectionName = req.body.sectionName ? req.body.sectionName : null;
        const perUnitPrice = await collection.findOne({_id:id, orgId}, {projection:{ price: 1}});
        if(!perUnitPrice)
        {
          error.error(`mOrderStored id:${id} error: not found`);
          return res.status(404).send(generateResponse("Order not found", 400, "failed"));
        }
        const price = perUnitPrice.price * qty;
        info.info(`mOrderStored id:${id} price: ${price}`);
        const updatedData = {isStored: true, suppliedQty: qty, price , updatedAt: new Date(), ...(sectionName && {sectionName: sectionName})};
        info.info(`mOrderStored id:${id} updatedData:${JSON.stringify(updatedData)}`);
        const productApiEndpoint = `http://${baseURL}:${productServicePort}/api/productServices/addItemQty?qty=${qty}&id=${itemId}`;

        let check = 0;
        const response = await axios.put(productApiEndpoint).then(() => {
          info.info(`mOrderStored id:${id} add item(S-S) success`);
        }).catch((err: any) => {
        error.error(`mOrderStored id:${id} add item(S-S) error`);
        check = 1;
      });
        if(check)
        {
          return res.status(500).send(generateResponse("Internal server error", 500, "failed"));
        }

        await collection.findOneAndUpdate(
            {_id: id, orgId, isDeleted: false, isDelivered: true, isStored: false}, 
            { $set: updatedData}, 
            { new: true});
        info.info(`mOrderStored id:${id} data updated`);
        res.status(200).json(generateResponse("Market order stored successfully..", 200, "Success"));
    }
    catch(err: any)
    {
        error.error(`mOrderStored id:${id} error:${err.message}`)      
        res.status(500).json(generateResponse("Internal server error",500,"failed"))
    }
}

export async function tPMOrderList ( req: Request, res: Response )  {
  info.info(`tPMOrderList initiated`);
  info.info(`tPMOrderList req.query:${JSON.stringify(req.query)}`);
  const {orgId} = req.query;
  if(!orgId || orgId == "")
  {
    error.error(`tPMOrderList error: orgId missing`);
    return res.status(400).send(generateResponse("Company id missing", 400, "failed"));
  }
    try{
        const pipeline = [
            {
              $match: {
                isDeleted: false,
                orgId,
                isDelivered: false
              }
            },
            {
              $group: {
                _id: {
                  itemId: "$itemId",
                  supplier: "$supplier"
                },
                totalQty: { $sum: "$orderedQty" },
              }
            },
            {
              $project: {
                _id: 0,
                itemId: "$_id.itemId",
                supplier: "$_id.supplier",
                totalQty: 1,
              }
            }
          ];
        info.info(`tPMOrderList orgId:${orgId} pipeLine:${JSON.stringify(pipeline)}`);
        const result = await collection.aggregate(pipeline).toArray();
        info.info(`tPMOrderList orgId:${orgId} data fetched`);
        res.status(200).json(generateResponse("Data fetched...", 200, "Success", result));
    }
    catch(err: any)
    {
        error.error(`tPMOrderList orgId:${orgId} error:${err.message}`)      
        res.status(500).json(generateResponse("Internal server error",500,"failed"))
    }
}

export async function tPGetMOrder (req: Request, res: Response) {
  const {id} = req.params;
  info.info(`tPGetMOrder id:${id} initiated`);
  info.info(`tPGetMOrder id:${id} req.query:${JSON.stringify(req.query)}`);
  const {orgId} = req.query;
  if(!orgId)
  {
    error.error(`tPGetMOrder id:${id} error: orgId missing`);
    return res.status(400).send(generateResponse("Company id missing", 400, "failed"));
  }
    try{
        const projection = {
            _id: 1,
            name: 1,
            orderedQty: 1,
            unit: 1,
            supplier: 1,
        }
        const orderData = await collection.find({_id:id, orgId}, {projection}).toArray();
        if(orderData.length > 0)
        {
            info.info(`tPGetMOrder id:${id} data fetched`);
            res.status(200).json(generateResponse("Data fetched...", 200, "Success", orderData));
        }
        else{
            error.error(`tPGetMOrder id:${id} error:data not found`);
            res.status(404).json(generateResponse("No data found", 404, "Failed"));
        }  
    }
    catch(err: any){
        error.error(`tPGetMOrder id:${id} error:${err.message}`)      
        res.status(500).json(generateResponse("Internal server error",500,"failed"))
    }
}

export async function sUMOrderList (req: Request, res: Response) {
    const {orgId} = req.query;
    if(!orgId){
      error.error(`sUMOrderList error: orgId missing`);
      return res.status(400).send(generateResponse("Company id missing", 400, "failed"));
    }
    try{
        info.info(`sUMOrderList orgId:${orgId} initiated`);
        const projection = {
            _id: 1,
            orgId: 1,
            sectionName: 1,
            supplier: 1,
            name: 1,
            suppliedQty: 1,
            unit: 1,
        }
        const orderData = await collection.find({orgId, isDelivered: true, isStored: false, isDeleted: false}, {projection}).toArray();
        if(orderData.length>0)
        {
          info.info(`sUMOrderList orgId:${orgId} data fetched`);
          return res.status(200).json(generateResponse("Data fetched...", 200, "Success", orderData));
        }
        else{
          error.error(`sUMorderList orgId:${orgId} no data found`);
          return res.status(404).json(generateResponse("No data found", 404, "failed"));
        }
    }
    catch(err: any)
    {
        error.error(`sUMOrderList orgId:${orgId} error:${err.message}`)      
        res.status(500).json(generateResponse("Internal server error",500,"failed"))
    }
}

export async function sUGetMOrder (req: Request, res: Response) {
    const {id} = req.params;
    info.info(`sUGetMOrder id:${id} initiated`);
    info.info(`sUGetMOrder id:${id} req.query:${JSON.stringify(req.query)}`);
    const {orgId} = req.query;
    if(!orgId)
    {
      error.error(`sUGetMOrder id:${id} error: orgId missing`);
      return res.status(400).send(generateResponse("Company id missing", 400, "failed"));
    }
    try{
        const projection = {
            _id: 1,
            sectionName: 1,
            supplier: 1,
            name: 1,
            suppliedQty: 1,
            unit: 1,
        }
        const orderData = await collection.find({_id: id, orgId, isDeleted: false, isDelivered: true}, {projection}).toArray();
        if(orderData.length > 0)
        {
          info.info(`sUGetMOrder id:${id} data fetched`);
          res.status(200).json(generateResponse("Data fetched...", 200, "Success", orderData));
        }
        else{
            error.error(`sUGetMOrder id:${id} data not found`);
            res.status(404).json(generateResponse("No data found", 404, "Failed"));
        }
    }
    catch(err: any)
    {
        error.error(`sUGetMOrder id:${id} error:${err.message}`)      
        res.status(500).json(generateResponse("Internal server error",500,"failed"))
    }
}

export async function sUGetMOrderDetail (req: Request, res: Response)  {
    const {id} = req.params;
    info.info(`sUGetMOrderDetail id:${id} initiated`);
    info.info(`sUGetMOrderDetail id:${id} req.query:${JSON.stringify(req.query)}`);
    const {orgId} = req.query;
    if(!orgId)
    {
      error.error(`sUGetMOrderDetail id:${id} error: orgId missing`);
      return res.status(400).send(generateResponse("Company id missing", 400, "failed"));
    }
    try{
        const projection = {
            _id: 1,
            name: 1,
            orderedQty: 1,
            suppliedQty: 1,
            unit: 1,
            orderedDate: 1,
            deliveredDate: 1,
            isDelivered: 1,
            isStored: 1,
            supplier: 1,
            sectionName: 1
        }
        const orderData = await collection.find({_id: id, orgId, isDeleted: false}, {projection}).toArray();
        if(orderData.length > 0)
        {
            info.info(`sUGetMOrderDetail id:${id} data fetched`);
            res.status(200).json(generateResponse("Data fetched...", 200, "Success", orderData));
        }
        else{
            error.error(`sUGetMOrderDetail id:${id} data not found`);
            res.status(404).json(generateResponse("No data found", 404, "Failed"));
        }
    }
    catch(err: any)
    {
        error.error(`sUGetMOrderDetail id:${id} error:${err.message}`)      
        res.status(500).json(generateResponse("Internal server error",500,"failed"))
    }
}

export async function tPCreateMOrder (req: Request, res: Response) {
    info.info(`tPCreateMOrder initiated`);
    info.info(`tPCreateMOrder reqBody:${JSON.stringify(req.body)}`);
    info.info(`tPCreateMOrder req.query:${JSON.stringify(req.query)}`);
    const { name, qty, supplier, itemId, unit, } = req.body;
    const { orgId } = req.query;

    if(!name || name=="" || !qty || qty==0 || !supplier || supplier=="" || !itemId || itemId=="" || !unit || unit=="")
    {
      error.error(`tPCreateMOrder error: Arguments missing`);
      return res.status(400).send(generateResponse("Invalid arguments", 400, "failed"));
    }
    if(!orgId)
    {
      error.error(`tPCreateMOrder error: orgId missing`);
      return res.status(400).send(generateResponse("Company id missing", 400, "failed"));
    }
    try {

        const date = new Date();
        const orderDate: string= currentDate.format('YYYY-MM-DD');
        const productApiEndpoint = `http://${baseURL}:${productServicePort}/api/productServices/itemSupplierValidate?itemId=${itemId}&supplier=${supplier}`;
        const response = await axios.put(productApiEndpoint).then((result: any) => {
          info.info(`tPCreateMOrder itemId:${itemId} item supplier verification(S-S) success`);
        }).catch((err: any) => {
          error.error(`tPCreateMOrder itemId:${itemId} item supplier verification(S-S) error`);
      });
      const id = await createMOrderId();
        const createdData = {
            _id: id,
            orgId,
            name,
            itemId,
            orderedQty: qty,
            suppliedQty: qty,
            supplier,
            unit,
            isDeleted:false,
            isDelivered: true,
            isStored: false,
            createdAt: date,
            updatedAt: date,
            orderedDate: orderDate,
            deliveredDate: orderDate
        };
        await collection.insertOne(createdData);
        info.info(`tPCreateMOrder id:${id} data inserted:${JSON.stringify(createdData)}`);
        res.status(200).json(generateResponse("Market Order created...", 200, "Success"));
    }
    catch(err:  any) {
        error.error(`tPCreateMOrder orgId:${orgId} itemId:${itemId} error:${err.message}`);
        res.status(500).json(generateResponse(err.message, err.status, "Failed"));
    }
}

export async function sUserCreateMOrder (req: Request, res: Response)  {
    info.info(`sUserCreateMOrder initiated`);
    info.info(`sUserCreateMOrder req.body:${JSON.stringify(req.body)}`);
    info.info(`sUserCreateMOrder req.query:${JSON.stringify(req.query)}`);

    const { name, qty, supplier, itemId,sectionName,unit, } = req.body;
    const { orgId } = req.query;
    if(!name || !qty || !supplier || !itemId || !sectionName || !unit || name == "" || qty == 0 || supplier == "" || itemId =="" || sectionName == "" || unit == "" )
    {
      error.error(`sUserCreateMOrder error: Arguments missing`);
      return res.status(400).json(generateResponse("Invalid arguments...", 400, "failed"));
    }
    if(!orgId){
      error.error(`sUserCreateMOrder error: orgId missing`);
      return res.status(400).json(generateResponse("Company id missing", 400, "failed"));
    }
    try {
        const date = new Date();
        const orderDate: string= currentDate.format('YYYY-MM-DD');
        const productApiEndpoint = `http://${baseURL}:${productServicePort}/api/productServices/itemSupplierValidate?itemId=${itemId}&supplier=${supplier}`;
        const response = await axios.put(productApiEndpoint).then((result: any) => {
          info.info(`sUserCreateMOrder itemId:${itemId} item supplier verification(S-S) success`);
        }).catch((err: any) => {
          error.error(`sUserCreateMOrder itemId:${itemId} item supplier verification(S-S) error`);
        });
        const id = await createMOrderId();
        const createdData = {
            _id: id,
            orgId,
            name,
            itemId,
            orderedQty: qty,
            suppliedQty: qty,
            supplier,
            sectionName,
            unit,
            isDeleted:false,
            isDelivered: true,
            isStored: true,
            createdAt: date,
            updatedAt: date,
            orderedDate: orderDate,
            deliveredDate: orderDate
        };
        await collection.insertOne(createdData);
        info.info(`sUserCreateMOrder id:${id} data inserted:${JSON.stringify(createdData)}`);
        res.status(200).json(generateResponse("Market Order created successfully...", 200, "Success"));
    }
    catch(err:  any) {
        error.error(`sUserCreateMOrder orgId:${orgId} itemId:${itemId} error:${err.message}`);
        res.status(500).json(generateResponse(err.message, err.status, "Failed"));
    }
}

export async function entryReport(req: Request, res: Response) {
  info.info(`entryReport initiated`);
  info.info(`entryReport req.query:${JSON.stringify(req.query)}`);
  info.info(`entryReport req.body:${JSON.stringify(req.body)}`);

  const { date, monthAndYear, dateRange } = req.body;
  const {orgId} = req.query;
  let page = parseInt(req.query.page as string, 10) || 1;
  const pageSize = parseInt(req.query.pageSize as string, 10) || 10;
  let skip = (page - 1) * pageSize;

  const sortField = req.query.sortField
    ? req.query.sortField.toString()
    : "orderedDate";

  const sortOrder = req.query.sortOrder === "desc" ? -1 : 1;
  if (!orgId || orgId === "") {
    error.error(`entryReport error: orgId missing`)
    return res
      .status(404)
      .json(generateResponse("Organisation Id is missing", 404, "failure"));
  }

  try {

    const queryCondition: any = [
      { $eq: ["$orgId", orgId] },
      { $eq: ["$isStored", true] },
      { $eq: ["$isDeleted", false] },
    ];

    const dateRegex = /^\d{4}-\d{2}-\d{2}$/;

    const validateDate = (
      res: Response<any, Record<string, any>>,
      date: string,
      errorMessage: string
    ) => {
      if (!dateRegex.test(date)) {
        error.error(`entryReport orgId:${orgId} validateDate error:${errorMessage}`);
        return res
          .status(400)
          .json(generateResponse(errorMessage, 400, "failure"));
      }
      return true;
    };

    const validateNumeric = (
      res: Response<any, Record<string, any>>,
      date: string,
      errorMessage: string,
      length: number
    ) => {
      const numericRegex = new RegExp(`^\\d{${length}}$`);
      if (!numericRegex.test(date)) {
        error.error(`entryReport orgId:${orgId} validateNumeric error:${errorMessage}`);
        return res
          .status(400)
          .json(generateResponse(errorMessage, 400, "failure"));
      }
      return true;
    };

    if (date) {
      if (validateDate(res, date, "Invalid date value")) {
        queryCondition.push({ $eq: ["$orderedDate", date] });
      }
    } else if (monthAndYear) {
      const { month, year } = monthAndYear;
      if (
        validateNumeric(res, month, "Invalid Month value", 2) &&
        validateNumeric(res, year, "Invalid Year value", 4)
      ) {
        queryCondition.push(
          {
            $eq: [{ $year: { $toDate: "$orderedDate" } }, parseInt(year)],
          },
          {
            $eq: [{ $month: { $toDate: "$orderedDate" } }, parseInt(month)],
          }
        );
      }
    } else if (dateRange) {
      const { fromDate, toDate } = dateRange;
      if (
        validateDate(res, fromDate, "Invalid From date value") &&
        validateDate(res, toDate, "Invalid To date value")
      ) {
        queryCondition.push(
          {
            $gte: ["$orderedDate", fromDate],
          },
          {
            $lte: ["$orderedDate", toDate],
          }
        );
      }
    } else {
      error.error(`entryReport orgId:${orgId} error: data value missing`)
      return res
        .status(404)
        .json(generateResponse("Date value is missing", 404, "failure"));
    }
    info.info(
      `entryReportList orgId:${orgId} queryCondition data: ${JSON.stringify(queryCondition)}`
    );

    const pipeLine =[
      {
        $match: {
          $expr: {
            $and: queryCondition,
          },
        },
      },
      {
        $project: {
          _id: 0,
          name: 1,
          suppliedQty: 1,
          unit: 1,
          price: 1,
          orderedDate: 1,
        },
      },
      {
        $facet: {
          data: [
            {
              $sort: { [sortField]: sortOrder },
            },
            { $skip: skip },
            { $limit: Number(pageSize) },
          ],
          total: [{ $count: "count" }],
        },
      },
    ]
    info.info(`entryReport orgId:${orgId} pipeLine:${JSON.stringify(pipeLine)}`)

    const entryReportResult = await collection
      .aggregate(pipeLine)
      .toArray();

    let listData = entryReportResult[0]?.data || [];
    let totalCount = entryReportResult[0]?.total[0]?.count || 0;
    let totalPriceAmount = 0;

    listData.map((item: any) => {
      totalPriceAmount += parseFloat(item.price);
    });

    let roundTotalPrice = (Math.round(totalPriceAmount * 100) / 100).toFixed(2);
    info.info(`entryReport orgId:${orgId} roundTotalPrice: ${roundTotalPrice} pipeLine:${JSON.stringify(pipeLine)}`)
    const result = {
      totalCount,
      totalPriceAmount: roundTotalPrice,
      list: listData,
    };
    info.info(`entryReportList orgId:${orgId} fetched successfully`);
    const response = generateResponse(
      "Entry report list fetched",
      200,
      "success",
      result
    );
    res.status(200).json(response);
  } catch (err: any) {
    error.error(`entryReportList orgId:${orgId} error:${err.message}`);
    res.status(500).send(generateResponse("Internal server error", 500, "failed"));
  }
}

export async function itemEntryReport(req: Request, res: Response) {
  info.info(`itemEntryReport initiated`);
  info.info(`itemEntryReport req.query:${JSON.stringify(req.query)}`);
  info.info(`itemEntryReport req.body:${JSON.stringify(req.body)}`);

  const { itemId, monthAndYear, dateRange } = req.body;
  const {orgId} = req.query;
  let page = parseInt(req.query.page as string, 10) || 1;
  const pageSize = parseInt(req.query.pageSize as string, 10) || 10;
  let skip = (page - 1) * pageSize;

  const sortField = req.query.sortField
    ? req.query.sortField.toString()
    : "orderedDate";

  const sortOrder = req.query.sortOrder === "desc" ? -1 : 1;
  if (!orgId || orgId === "") {
    error.error(`itemEntryReport error: orgId missing`)
    return res
      .status(404)
      .json(generateResponse("Organisation Id is missing", 404, "failure"));
  }

  if (!itemId || itemId === "") {
    error.error(`itemEntryReport error: itemId missing`)
    return res
      .status(404)
      .json(generateResponse("Item Id is missing", 404, "failure"));
  }

  try {

    const queryCondition: any = [
      { $eq: ["$orgId", orgId] },
      { $eq: ["$itemId", itemId] },
      { $eq: ["$isStored", true] },
      { $eq: ["$isDeleted", false] },
    ];

    const dateRegex = /^\d{4}-\d{2}-\d{2}$/;

    const validateDate = (
      res: Response<any, Record<string, any>>,
      date: string,
      errorMessage: string
    ) => {
      if (!dateRegex.test(date)) {
        error.error(`itemEntryReport orgId:${orgId} validateDate error:${errorMessage}`);
        return res
          .status(400)
          .json(generateResponse(errorMessage, 400, "failure"));
      }
      return true;
    };

    const validateNumeric = (
      res: Response<any, Record<string, any>>,
      date: string,
      errorMessage: string,
      length: number
    ) => {
      const numericRegex = new RegExp(`^\\d{${length}}$`);
      if (!numericRegex.test(date)) {
        error.error(`itemEntryReport orgId:${orgId} validateNumeric error:${errorMessage}`);
        return res
          .status(400)
          .json(generateResponse(errorMessage, 400, "failure"));
      }
      return true;
    };

    if (monthAndYear) {
      const { month, year } = monthAndYear;
      if (
        validateNumeric(res, month, "Invalid Month value", 2) &&
        validateNumeric(res, year, "Invalid Year value", 4)
      ) {
        queryCondition.push(
          {
            $eq: [{ $year: { $toDate: "$orderedDate" } }, parseInt(year)],
          },
          {
            $eq: [{ $month: { $toDate: "$orderedDate" } }, parseInt(month)],
          }
        );
      }
    } else if (dateRange) {
      const { fromDate, toDate } = dateRange;
      if (
        validateDate(res, fromDate, "Invalid From date value") &&
        validateDate(res, toDate, "Invalid To date value")
      ) {
        queryCondition.push(
          {
            $gte: ["$orderedDate", fromDate],
          },
          {
            $lte: ["$orderedDate", toDate],
          }
        );
      }
    } else {
      error.error(`itemEntryReport orgId:${orgId} error: data value missing`)
      return res
        .status(404)
        .json(generateResponse("Date value is missing", 404, "failure"));
    }
    info.info(
      `itemEntryReport orgId:${orgId} queryCondition data: ${JSON.stringify(
        queryCondition
      )}`
    );

    const pipeLine = [
      {
        $match: {
          $expr: {
            $and: queryCondition,
          },
        },
      },
      {
        $project: {
          _id: 0,
          supplier: 1,
          suppliedQty: 1,
          unit: 1,
          price: 1,
          orderedDate: 1,
        },
      },
      {
        $facet: {
          data: [
            {
              $sort: { [sortField]: sortOrder },
            },
            { $skip: skip },
            { $limit: Number(pageSize) },
          ],
          total: [{ $count: "count" }],
        },
      },
    ];
    info.info(`itemEntryReport orgId:${orgId} pipeline:${JSON.stringify(pipeLine)}`)

    const entryReportResult = await collection
      .aggregate(pipeLine)
      .toArray();

    let listData = entryReportResult[0]?.data || [];
    let totalCount = entryReportResult[0]?.total[0]?.count || 0;
    let totalPriceAmount = 0;

    listData.map((item: any) => {
      totalPriceAmount += parseFloat(item.price);
    });

    const axiosItemQtyResponse = await axios.get(
      `http://${baseURL}:${productServicePort}/api/productServices/item/getCurrentQty/${itemId}`
    );
    info.info(
      `itemEntryReport orgId:${orgId} axiosItemQtyResponse data: ${JSON.stringify(
        axiosItemQtyResponse
      )}`
    );
    const availableQty = axiosItemQtyResponse.data.currentQty || 0;

    let roundTotalPrice = (Math.round(totalPriceAmount * 100) / 100).toFixed(2);
    const result = {
      totalCount,
      totalPriceAmount: roundTotalPrice,
      availableQty,
      list: listData,
    };
    info.info(`itemEntryReport orgId:${orgId} fetched successfully`);
    const response = generateResponse(
      "Item entry report list fetched",
      200,
      "success",
      result
    );
    res.status(200).json(response);
  } catch (err: any) {
    error.error(`itemEntryReport orgId:${orgId} error:${err.message}`);
    res.status(500).send({ err: err.message });
  }
}

export async function itemEntryAndDelivery(req: Request, res: Response) {
  info.info(`itemEntryAndDelivery initiated`);
  info.info(`itemEntryAndDelivery req.body:${JSON.stringify(req.body)}`);
  const { itemId, date } = req.body;
  const {orgId} = req.query;

  if (!orgId || orgId === "") {
    return res
      .status(404)
      .json(generateResponse("Organisation Id is missing", 404, "failure"));
  }

  if (!itemId || itemId === "") {
    return res
      .status(404)
      .json(generateResponse("Item Id is missing", 404, "failure"));
  }

  try {

    let entryQueryCondition: any = [
      { $eq: ["$orgId", orgId] },
      { $eq: ["$itemId", itemId] },
      { $eq: ["$isStored", true] },
      { $eq: ["$isDeleted", false] },
    ];
    info.info(`itemEntryAndDelivery orgId:${orgId} entryQueryCondition: ${entryQueryCondition}`)

    let deliveryQueryCondition: any = [
      { $eq: ["$orgId", orgId] },
      { $eq: ["$itemId", itemId] },
      { $eq: ["$isReceived", true] },
      { $eq: ["$isDeleted", false] },
    ];
    info.info(`itemEntryAndDelivery orgId:${orgId} deliveryQueryCondition: ${deliveryQueryCondition}`)

    const dateRegex = /^\d{4}-\d{2}-\d{2}$/;

    const validateDate = (
      res: Response<any, Record<string, any>>,
      date: string,
      errorMessage: string
    ) => {
      if (!dateRegex.test(date)) {
        error.error(`itemEntryAndDelivery orgId:${orgId} validateDate error:${errorMessage}`);
        return res
          .status(400)
          .json(generateResponse(errorMessage, 400, "failure"));
      }
      return true;
    };

    if (date) {
      if (validateDate(res, date, "Invalid date value")) {
        entryQueryCondition.push({ $eq: ["$orderedDate", date] });
        deliveryQueryCondition.push({ $eq: ["$orderedDate", date] });
      }
    } else {
      error.error(`itemEntryAndDelivery orgId:${orgId} error: Date value missing`)
      return res
        .status(404)
        .json(generateResponse("Date value is missing", 404, "failure"));
    }

    const pipeLine = [
      {
        $match: {
          $expr: {
            $and: entryQueryCondition,
          },
        },
      },
      {
        $group: {
          _id: "$supplier",
          orderedQty: { $sum: "$orderedQty" },
          price: { $sum: "$price" },
          unit: { $first: "$unit" },
        },
      },
      {
        $group: {
          _id: null,
          totalPrice: { $sum: "$price" },
          list: {
            $push: {
              orderedQty: "$orderedQty",
              price: "$price",
              supplier: "$_id",
              unit: "$unit",
            },
          },
        },
      },
      {
        $project: {
          _id: 0,
          totalPrice: 1,
          list: 1,
        },
      },
    ]
    info.info(`itemEntryAndDelivery orgId:${orgId} pipeLine: ${JSON.stringify(pipeLine)}`);
    const entryResult = await collection
      .aggregate(pipeLine)
      .toArray();

    const deliveryResult = await itemDeliverySingleDateData(
      deliveryQueryCondition
    );

    if (!deliveryResult) {
      error.error(`itemEntryAndDelivery orgId:${orgId} error: itemDeliverySingleDateData error`)
      return res
        .status(500)
        .json(generateResponse("Something went wrong", 500, "failure"));
    }
    let entryDataList =
      entryResult[0]?.list.length > 0 ? entryResult[0]?.list : [];
    let totalPrice =
      entryResult[0]?.totalPrice > 0 ? entryResult[0]?.totalPrice : 0;
    let deliveryDataList =
      deliveryResult[0]?.list.length > 0 ? deliveryResult[0]?.list : 0;

    const result = {
      totalPrice: totalPrice,
      entryData: entryDataList,
      deliveryData: deliveryDataList,
    };
    info.info(`itemEntryAndDelivery orgId:${orgId} list fetched`);
    const response = generateResponse(
      "Entry and delivery report list fetched",
      200,
      "success",
      result
    );
    res.status(200).json(response);
  } catch (err: any) {
    error.error(`itemEntryAndDeliveryList orgId:${orgId} error:${err.message}`);
    res.status(500).send(generateResponse("Internal server error", 500, "failed"));
  }
}

export async function itemPrice(req: Request, res: Response) {
  info.info(`itemPrice initiated`);
  info.info(`itemPrice req.body:${JSON.stringify(req.body)}`);

  const { itemId, monthAndYear, dateRange } = req.body;
  const {orgId} = req.query;

  if (!orgId || orgId === "") {
    error.error(`itemPrice error: orgId missing`)
    return res
      .status(404)
      .json(generateResponse("Organisation Id is missing", 404, "failure"));
  }

  if (!itemId || itemId === "") {
    error.error(`itemPrice error: itemId missing`)
    return res
      .status(404)
      .json(generateResponse("Item Id is missing", 404, "failure"));
  }

  try {

    const queryCondition: any = [
      { $eq: ["$orgId", orgId] },
      { $eq: ["$itemId", itemId] },
      { $eq: ["$isStored", true] },
      { $eq: ["$isDeleted", false] },
    ];

    const dateRegex = /^\d{4}-\d{2}-\d{2}$/;

    const validateDate = (
      res: Response<any, Record<string, any>>,
      date: string,
      errorMessage: string
    ) => {
      if (!dateRegex.test(date)) {
        error.error(`itemPrice orgId:${orgId} validateDate error:${errorMessage}`);
        return res
          .status(400)
          .json(generateResponse(errorMessage, 400, "failure"));
      }
      return true;
    };

    const validateNumeric = (
      res: Response<any, Record<string, any>>,
      date: string,
      errorMessage: string,
      length: number
    ) => {
      const numericRegex = new RegExp(`^\\d{${length}}$`);
      if (!numericRegex.test(date)) {
        error.error(`itemPrice orgId:${orgId} validateNumeric error:${errorMessage}`);
        return res
          .status(400)
          .json(generateResponse(errorMessage, 400, "failure"));
      }
      return true;
    };

    if (monthAndYear) {
      const { month, year } = monthAndYear;
      if (
        validateNumeric(res, month, "Invalid Month value", 2) &&
        validateNumeric(res, year, "Invalid Year value", 4)
      ) {
        queryCondition.push(
          {
            $eq: [{ $year: { $toDate: "$orderedDate" } }, parseInt(year)],
          },
          {
            $eq: [{ $month: { $toDate: "$orderedDate" } }, parseInt(month)],
          }
        );
      }
    } else if (dateRange) {
      const { fromDate, toDate } = dateRange;
      if (
        validateDate(res, fromDate, "Invalid From date value") &&
        validateDate(res, toDate, "Invalid To date value")
      ) {
        queryCondition.push(
          {
            $gte: ["$orderedDate", fromDate],
          },
          {
            $lte: ["$orderedDate", toDate],
          }
        );
      }
    } else {
      error.error(`itemPrice orgId:${orgId} error: Date value missing`)
      return res
        .status(404)
        .json(generateResponse("Date value is missing", 404, "failure"));
    }
    info.info(
      `itemPriceList orgId:${orgId} queryCondition data: ${JSON.stringify(
        queryCondition
      )}`
    );
    const pipeLine =[
      {
        $match: {
          $expr: {
            $and: queryCondition,
          },
        },
      },
      {
        $group: {
          _id: null,
          totalPrice: { $sum: "$price" },
          list: {
            $push: {
              orderedDate: "$orderedDate",
              price: "$price",
            },
          },
        },
      },
      {
        $sort: { ["orderedDate"]: 1 },
      },
      {
        $project: {
          _id: 0,
          totalPrice: 1,
          list: 1,
        },
      },
    ]

    info.info(`itemPriceList orgId:${orgId} pipeLine:${JSON.stringify(pipeLine)}`);

    const itemPriceResult = await collection
      .aggregate(pipeLine)
      .toArray();

    let listData = itemPriceResult[0]?.list || [];
    let totalPrice = itemPriceResult[0]?.totalPrice || 0;
    let roundTotalPrice = (Math.round(totalPrice * 100) / 100).toFixed(2);
    const axiosItemQtyResponse = await axios.get(
      `http://${baseURL}:${productServicePort}/api/productServices/item/getCurrentQty/${itemId}`
    );
    info.info(
      `itemPriceList orgId:${orgId} axiosItemQtyResponse data: ${JSON.stringify(
        axiosItemQtyResponse
      )}`
    );
    const availableQty = axiosItemQtyResponse.data.currentQty || 0;

    let result = {
      totalPriceAmount: roundTotalPrice,
      availableQty,
      list: listData,
    };
    info.info(`itemPrice orgId:${orgId} data fetched`);
    const response = generateResponse(
      "Item price list fetched",
      200,
      "success",
      result
    );
    res.status(200).json(response);
  } catch (err: any) {
    error.error(`itemPriceList orgId:${orgId} error:${err.message}`);
    res.status(500).send({ err: err.message });
  }
}

export async function sectionEntryReport(req: Request, res: Response) {
  info.info(`sectionEntryReport initiated`);
  info.info(`sectionEntryReport req.query:${JSON.stringify(req.query)}`);
  info.info(`sectionEntryReport req.body:${JSON.stringify(req.body)}`);

  const { sectionName, date, monthAndYear, dateRange } = req.body;
  const {orgId} = req.query;
  let page = parseInt(req.query.page as string, 10) || 1;
  const pageSize = parseInt(req.query.pageSize as string, 10) || 10;
  let skip = (page - 1) * pageSize;

  const sortField = req.query.sortField
    ? req.query.sortField.toString()
    : "orderedDate";

  const sortOrder = req.query.sortOrder === "desc" ? -1 : 1;
  if (!orgId || orgId === "") {
    error.error(`sectionEntryReport error: orgId missing`)
    return res
      .status(404)
      .json(generateResponse("Organisation Id is missing", 404, "failure"));
  }

  if (!sectionName || sectionName === "") {
    error.error(`sectionEntryReport error: sectionName missing`)
    return res
      .status(404)
      .json(generateResponse("Section Name is missing", 404, "failure"));
  }

  try {

    const queryCondition: any = [
      { $eq: ["$orgId", orgId] },
      { $eq: ["$sectionName", sectionName] },
      { $eq: ["$isStored", true] },
      { $eq: ["$isDeleted", false] },
    ];

    const dateRegex = /^\d{4}-\d{2}-\d{2}$/;

    const validateDate = (
      res: Response<any, Record<string, any>>,
      date: string,
      errorMessage: string
    ) => {
      if (!dateRegex.test(date)) {
        error.error(`sectionEntryReport orgId:${orgId} validateDate error:${errorMessage}`);
        return res
          .status(400)
          .json(generateResponse(errorMessage, 400, "failure"));
      }
      return true;
    };

    const validateNumeric = (
      res: Response<any, Record<string, any>>,
      date: string,
      errorMessage: string,
      length: number
    ) => {
      const numericRegex = new RegExp(`^\\d{${length}}$`);
      if (!numericRegex.test(date)) {
        error.error(`sectionEntryReport orgId:${orgId} validateNumeric error:${errorMessage}`);
        return res
          .status(400)
          .json(generateResponse(errorMessage, 400, "failure"));
      }
      return true;
    };

    if (date) {
      if (validateDate(res, date, "Invalid date value")) {
        queryCondition.push({ $eq: ["$orderedDate", date] });
      }
    } else if (monthAndYear) {
      const { month, year } = monthAndYear;
      if (
        validateNumeric(res, month, "Invalid Month value", 2) &&
        validateNumeric(res, year, "Invalid Year value", 4)
      ) {
        queryCondition.push(
          {
            $eq: [{ $year: { $toDate: "$orderedDate" } }, parseInt(year)],
          },
          {
            $eq: [{ $month: { $toDate: "$orderedDate" } }, parseInt(month)],
          }
        );
      }
    } else if (dateRange) {
      const { fromDate, toDate } = dateRange;
      if (
        validateDate(res, fromDate, "Invalid From date value") &&
        validateDate(res, toDate, "Invalid To date value")
      ) {
        queryCondition.push(
          {
            $gte: ["$orderedDate", fromDate],
          },
          {
            $lte: ["$orderedDate", toDate],
          }
        );
      }
    } else {
      error.error(`sectionEntryReport orgId:${orgId} error: no data found`);
      return res
        .status(404)
        .json(generateResponse("Date value is missing", 404, "failure"));
    }
    info.info(
      `sectionEntryReport orgId:${orgId} queryCondition data: ${JSON.stringify(
        queryCondition
      )}`
    );

    const pipeLine= [
      {
        $match: {
          $expr: {
            $and: queryCondition,
          },
        },
      },
      {
        $project: {
          _id: 0,
          name: 1,
          suppliedQty: 1,
          unit: 1,
          price: 1,
          orderedDate: 1,
        },
      },
      {
        $facet: {
          data: [
            {
              $sort: { [sortField]: sortOrder },
            },
            { $skip: skip },
            { $limit: Number(pageSize) },
          ],
          total: [{ $count: "count" }],
        },
      },
    ]
    const entryReportResult = await collection
      .aggregate(pipeLine)
      .toArray();

    let listData = entryReportResult[0]?.data || [];
    let totalCount = entryReportResult[0]?.total[0]?.count || 0;
    let totalPriceAmount = 0;

    listData.map((item: any) => {
      totalPriceAmount += parseFloat(item.price);
    });

    let roundTotalPrice = (Math.round(totalPriceAmount * 100) / 100).toFixed(2);
    const result = {
      totalCount,
      totalPriceAmount: roundTotalPrice,
      list: listData,
    };
    info.info(`sectionEntryReport orgId:${orgId} fetched. pipeLine: ${JSON.stringify(pipeLine)}`);
    const response = generateResponse(
      "Section entry report list fetched",
      200,
      "success",
      result
    );
    res.status(200).json(response);
  } catch (err: any) {
    error.error(`sectionEntryReport orgId:${orgId} error:${err.message}`);
    res.status(500).send({ err: err.message });
  }
}

export async function itemPriceDetail(itemId: string) {
 info.info(`itemPriceDetail initiated for itemId:${itemId}`)
  try {
    const itemPriceResult = await collection.findOne(
      {
        itemId: itemId,
        isDelivered: true,
        isDeleted: false,
      },
      {
        projection: { _id: 0, price: 1, orderedQty: 1 },
        sort: { createdAt: -1 },
      }
    );
    info.info(`itemPriceDetail completed`)
    return {
      price: itemPriceResult?.price || 0,
      orderedQty: itemPriceResult?.orderedQty || 0,
    };
  } catch (err:any) {
    error.error(`itemPriceDetail errorMessage:${err.message}`);
    return false;
  }
}

export async function MOAny(req: Request, res: Response) {
  try {
    
    const orgId = req.query.orgId as string;
    const id = req.query.id as string;

    const projection = {
        name: 1,
        orderedQty: 1,
        unit: 1,
        orderedDate: 1,
        deliveredDate: 1,
        supplier: 1,
        isDelivered:1,
        isStored : 1
    };
    const query: any = {_id:id, orgId , isDeleted:false};
      
    const marketOrders = await collection.find(query, projection).toArray();

    
    res.json(marketOrders);

  } catch (error) {
    
  }


}

export async function MOHistory(req: Request, res: Response) {
 
  info.info(`MOHistory initiated`);
  info.info(`MOHistory req.query:${JSON.stringify(req.query)}`);
  info.info(`MOHistory req.body:${JSON.stringify(req.body)}`);
  const { date, monthAndYear, dateRange } = req.body;
  const {orgId} = req.query;
  let page = parseInt(req.query.page as string, 10) || 1;
  const pageSize = parseInt(req.query.pageSize as string, 10) || 10;
  let skip = (page - 1) * pageSize;
 
  if (!orgId || orgId === "") {
    error.error(`MOHistory error: orgId missing`)
    return res
    .status(404)
    .json(generateResponse("Organisation Id is missing", 404, "failure"));
  }
 
  try {
    const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
 
    const queryCondition: any = [
      { $eq: ["$orgId", orgId] },
      { $eq: ["$isDeleted", false] },
    ];
 
    const validateDate = (
      res: Response<any, Record<string, any>>,
      date: string,
      errorMessage: string
    ) => {
      if (!dateRegex.test(date)) {
        error.error(`MOHistory orgId:${orgId} validateDate error:${errorMessage}`);
        return res
          .status(400)
          .json(generateResponse(errorMessage, 400, "failure"));
      }
      return true;
    };
 
    const validateNumeric = (
      res: Response<any, Record<string, any>>,
      date: string,
      errorMessage: string,
      length: number
    ) => {
      const numericRegex = new RegExp(`^\\d{${length}}$`);
      if (!numericRegex.test(date)) {
        error.error(`MOHistory orgId:${orgId} validateNumeric error:${errorMessage}`);
        return res
          .status(400)
          .json(generateResponse(errorMessage, 400, "failure"));
      }
      return true;
    };
 
    if (date) {
      if (validateDate(res, date, "Invalid date value")) {
        queryCondition.push({ $eq: ["$orderedDate", date] });
      }
    } else if (monthAndYear) {
      const { month, year } = monthAndYear;
      if (
        validateNumeric(res, month, "Invalid Month value", 2) &&
        validateNumeric(res, year, "Invalid Year value", 4)
      ) {
        queryCondition.push(
          {
            $eq: [{ $year: { $toDate: "$orderedDate" } }, parseInt(year)],
          },
          {
            $eq: [{ $month: { $toDate: "$orderedDate" } }, parseInt(month)],
          }
        );
      }
    } else if (dateRange) {
      const { fromDate, toDate } = dateRange;
      if (
        validateDate(res, fromDate, "Invalid From date value") &&
        validateDate(res, toDate, "Invalid To date value")
      ) {
        queryCondition.push(
          {
            $gte: ["$orderedDate", fromDate],
          },
          {
            $lte: ["$orderedDate", toDate],
          }
        );
      }
    } else {
      error.error(`MOHistory orgId:${orgId} error: no data found`);
      return res
        .status(404)
        .json(generateResponse("Date value is missing", 404, "failure"));
    }
    info.info(
      `MOHistory orgId:${orgId} queryCondition data: ${JSON.stringify(
        queryCondition
      )}`
    );
 
    const projection = {
        name: 1,
        orderedQty: 1,
        unit: 1,
        orderedDate: 1,
        deliveredDate: 1,
        supplier: 1,
        isDelivered:1,
        isStored : 1
    };
   
    const marketOrders = await collection.find(queryCondition, projection).toArray();
    info.info(`MOHistory data fetched:${JSON.stringify(marketOrders)}`);
 
    if(marketOrders.length > 0)
    {
      return res.status(200).send(generateResponse("Data fetched", 200, "success", marketOrders));
    }
    else{
      return res.status(404).send(generateResponse("No data found", 404, "failed"))
    }
 
  } catch (err) {
    error.error(`MOHistory error:${JSON.stringify(err)}`);
    return res.status(500).send(generateResponse("Internal server error", 500, "failed"));
  }
 
 
}