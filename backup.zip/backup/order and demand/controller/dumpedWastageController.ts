import { Request, Response } from "express";
import { info, error } from "../config/loggerConfig";
import { dumpedWastage } from "../model/dumpedWastageModel";
import { generateResponse } from "../utils/responseGenerate";
import axios from "axios";
import moment from "moment";
import { createDWasteId } from "../utils/idGenerate";

const baseURL = process.env.BASE_URL;
const productServicePort = process.env.PRODUCT_SERVICE_PORT;
const orgServicePort = process.env.PRODUCT_ORG_PORT;
const bucketName = process.env.S3_BUCKET_NAME;
const bucketRegion = process.env.S3_BUCKET_REGION;

const aws = require("aws-sdk");
const currentDate: moment.Moment = moment();

let collection: any;
export const dumpWastageInstance = async () => {
  collection = await dumpedWastage();
};
const s3ImageUpload = async (fileName: string) => {
  let s3bucket = await new aws.S3({
    accessKeyId: process.env.S3_ACCESS_KEY_ID,
    secretAccessKey: process.env.S3_SECRET_ACCESS_KEY,
    region: process.env.S3_BUCKET_REGION,
  });
  const expires = 300;

  const signedUrl = await s3bucket.getSignedUrl("putObject", {
    Bucket: bucketName,
    Key: fileName,
    Expires: expires,
    ContentType: "image/*",
  });
  return signedUrl;
};

const s3ImageDelete = async (accessUrl: any) => {
  return new Promise((resolve, reject) => {
    let s3bucket = new aws.S3({
      accessKeyId: process.env.S3_ACCESS_KEY_ID,
      secretAccessKey: process.env.S3_SECRET_ACCESS_KEY,
      region: process.env.S3_BUCKET_REGION,
    });

    const params = {
      Bucket: bucketName,
      Key: accessUrl,
    };

    s3bucket.deleteObject(params, (err: any, data: any) => {
      if (err) {
        error.error(`s3ImageDelete error:${JSON.stringify(err)}`);
        reject(true);
      } else {
        info.info(
          `s3ImageDelete deleted successfully data:${JSON.stringify(data)}`
        );
        resolve(true);
      }
    });
  });
};

export async function createDumpWastage(req: Request, res: Response) {
  info.info(`createDumpWastage initiated`);
  info.info(`createDumpWastage req.body:${JSON.stringify(req.body)}`);

  try {
    var { orgId, divId, procedureId, productName, isProduct, qty, unit } =
      req.body;

      
      if (!procedureId || procedureId === "") {
        error.error(`createDumpWastage error: procedureId missing`)
        return res
        .status(400)
        .json(generateResponse("Product Id is missing", 400, "failure"));
    }

    if (!orgId || orgId === "") {
      error.error(`createDumpWastage error: orgId missing`)
      return res
        .status(400)
        .json(generateResponse("Organisation Id is missing", 400, "failure"));
    }

    if (!divId || divId === "") {
      error.error(`createDumpWastage error: divId missing`)
      return res
        .status(400)
        .json(generateResponse("Division Id is missing", 400, "failure"));
    }

    if (!productName || productName === "") {
      error.error(`createDumpWastage error: productName missing`)
      return res
      .status(400)
        .json(generateResponse("Product Name is missing", 400, "failure"));
    }

    if (isProduct == null || isProduct === "") {
      error.error(`createDumpWastage error: isProduct missing`)
      return res
      .status(400)
      .json(generateResponse("isProduct value is missing", 400, "failure"));
    }
    const axiosProductPriceResponse = await axios.get(
      `http://${baseURL}:${productServicePort}/api/product/getPrice/${procedureId}`
      );
      
      const productQty = axiosProductPriceResponse.data.qty;
      const productPrice = axiosProductPriceResponse.data.price;
      
      qty = qty > 0 ? qty : 0;
      const Price = (productPrice / productQty) * qty;
      
      const totalPrice = (Math.round(Price * 100) / 100).toFixed(2);
      info.info(`createDumpWastage totalPrice: ${totalPrice}`)
      const id = await createDWasteId();
      
      const fileName = `dumped-wastage-pic-${id}.jpg`;
      
      const signedUrl = await s3ImageUpload(fileName);
      const accessUrl = `https://s3.${bucketRegion}.amazonaws.com/${bucketName}/${fileName}`;
      
      const dumpedDate: string = currentDate.format("YYYY-MM-DD");
      info.info(`createDumpWastage dumpedDate: ${dumpedDate}`)
      
      const insertedData = {
        _id: id,
        orgId,
      divId,
      dumpedDate,
      procedureId,
      productName,
      isProduct,
      price: Number(totalPrice),
      qty: Number(qty),
      unit,
      dumpedImage: accessUrl,
      isDeleted: false,
      createdAt: new Date(),
      updatedAt: new Date(),
    }
    await collection.insertOne(insertedData);
    info.info(`Created dumped wastage insertedData: ${JSON.stringify(insertedData)}`);
    const response = generateResponse(
      "Created dumped wastage successfully",
      200,
      "success",
      { signedUrl }
    );
    res.status(200).json(response);
  } catch (err: any) {
    console.log("err", err);
    error.error(`Create dump wastage errorMessage:${err.message}`);
    res.status(500).json(generateResponse(`Internal server error`,500,`failed`));
  }
}

export async function editDumpedWastage(req: Request, res: Response) {
  const { id } = req.params;
  info.info(`editDumpedWastage id:${id} initiated`);
  info.info(`editDumpedWastage id:${id} reqParams:${JSON.stringify(req.params)}`);
  info.info(`editDumpedWastage id:${id} reqBody:${JSON.stringify(req.body)}`);

  try {
    var {
      procedureId,
      productName,
      isProduct,
      qty,
      unit,
      isImageEdited,
      isImageDeleted,
    } = req.body;
    var signedUrl = undefined;

    if (!id || id === "") {
      error.error(`editDumpedWastage id:${id} error: DumpedWastage Id missing `)
      return res
        .status(400)
        .json(generateResponse("Dumped wastage Id is missing", 400, "failure"));
    }

    if (!procedureId || procedureId === "") {
      error.error(`editDumpedWastage id:${id} error: Product Id missing `)
      return res
        .status(400)
        .json(generateResponse("Product Id is missing", 400, "failure"));
    }

    if (!productName || productName === "") {
      error.error(`editDumpedWastage id:${id} error: Product Name is missing`)
      return res
        .status(400)
        .json(generateResponse("Product Name is missing", 400, "failure"));
    }

    if (isProduct === "") {
      error.error(`editDumpedWastage id:${id} error: product value missing`)
      return res
        .status(400)
        .json(generateResponse("isProduct value is missing", 400, "failure"));
    }
    const axiosProductPriceResponse = await axios.get(
      `http://${baseURL}:${productServicePort}/api/product/getPrice/${procedureId}`
    );

    const productQty = axiosProductPriceResponse.data.qty;
    const productPrice = axiosProductPriceResponse.data.price;
    qty = qty > 0 ? qty : 0;
    const Price = (productPrice / productQty) * qty;
    
    const totalPrice = (Math.round(Price * 100) / 100).toFixed(2);
    info.info(`editDumpedWastage id:${id} totalPrice: ${totalPrice}`)

    var updatedData: any = {
      productName,
      isProduct,
      qty: Number(qty),
      unit,
      price: Number(totalPrice),
      updatedAt: new Date(),
    };

    if (isImageEdited === true) {
      const fileName = `dumped-wastage-pic-${id}.jpg`;
      signedUrl = await s3ImageUpload(fileName);
      const accessUrl = `https://s3.${bucketRegion}.amazonaws.com/${bucketName}/${fileName}`;
      updatedData.dumpedImage = accessUrl;
    } else if (isImageDeleted === true) {
      const fileName = `dumped-wastage-pic-${id}.jpg`;
      const isDelete = await s3ImageDelete(fileName);

      if (!isDelete) {
        const response = generateResponse(
          "Dumped wastage image is not deleted",
          500,
          "error"
        );
        return res.status(500).json(response);
      }
      updatedData.dumpedImage = null;
    }

    info.info(`editDumpedWastage id:${id} updated data: ${JSON.stringify(updatedData)}`);

    const result = await collection.findOneAndUpdate(
      { _id: id },
      {
        $set: updatedData,
      },
      {
        new: true,
      }
    );

    if (result) {
      info.info(`editDumpedWastage id:${id} updated`);

      const response = generateResponse(
        "Dumped wastage updated successfully",
        200,
        "success",
        { signedUrl }
      );
      res.status(200).json(response);
    } else {
      const response = generateResponse(
        "Dumped wastage not found",
        404,
        "error"
      );
      res.status(404).json(response);
      error.error(`editDumpedWastage id:${id} error: Dumped wastage not found`)
    }
  } catch (err: any) {
    error.error(`editDumpedWastage id:${id} errorMessage:${err.message}`);
    res.status(500).json(generateResponse("Internal server error", 500, "failed"));
  }
}

export const deleteDumpedWastage = async (req: Request, res: Response) => {
  const { id } = req.params;
  info.info(`deleteDumpedWastage id:${id} initiated`);
  info.info(`deleteDumpedWastage id:${id} req.params ${JSON.stringify(req.params)}`);

  try {

    if (!id || id === "") {
      error.error(`deleteDumpedWastage error: Dumped wastage id is missing `)
      return res
        .status(400)
        .json(generateResponse("Dumped wastage id is missing", 400, "failure"));
    }

    const updatedData = {
      isDeleted: true,
      updatedAt: new Date(),
    };
    info.info(
      `deleteDumpedWastage id:${id} updated data: ${JSON.stringify(updatedData)}`
    );

    const result = await collection.findOneAndUpdate(
      { _id: id },
      {
        $set: updatedData,
      },
      {
        new: true,
      }
    );

    if (result) {
      info.info(`deleteDumpedWastage id:${id} deleted`);

      const response = generateResponse(
        "Dumped wastage deleted successfully",
        200,
        "success"
      );
      res.status(200).json(response);
    } else {
      error.error(`deleteDumpedWastage id:${id} error: wastage not found`);
      const response = generateResponse(
        "Dumped wastage not found",
        404,
        "error"
      );
      res.status(404).json(response);
    }
  } catch (err: any) {
    const response = generateResponse("Internal server error", 500, "failure");
    error.error(`deleteDumpedWastage id:${id} errMessage: ${err.message}`);
    res.status(500).json(response);
  }
};

export async function getDumpedWastage(req: Request, res: Response) {
  const { divId } = req.params;
  info.info(`getDumpedWastage divId:${divId} initiated`);
  info.info(`getDumpedWastage divId:${divId} reqBody:${JSON.stringify(req.body)}`);
  info.info(`getDumpedWastage divId:${divId} reqParams:${JSON.stringify(req.params)}`);
  info.info(`getDumpedWastage divId:${divId} reqQuery:${JSON.stringify(req.query)}`);
  try {
    const { query } = req.query;
    const { date } = req.body;

    if (!date || date === "") {
      error.error(`getDumpedWastage divId:${divId} error: date missing`)
      return res
        .status(400)
        .json(generateResponse("Date value is empty", 400, "failure"));
    }

    const isValidDateFormat = (dateString: string) => {
      const dateFormatRegex = /^\d{4}-\d{2}-\d{2}$/;
      return dateFormatRegex.test(dateString);
    };

    const currentDate = moment().format("YYYY-MM-DD");

    if (!isValidDateFormat(date)) {
      error.error(`getDumpedWastage divId:${divId} error: invalid date format`)
      return res
        .status(400)
        .json(generateResponse("Invalid date format", 400, "failure"));
    }

    if (date > currentDate) {
      error.error(`getDumpedWastage divId:${divId} error: Invalid dumped date`)
      return res
        .status(400)
        .json(
          generateResponse(
            "Invalid dumped date, it should be today or a previous day's date",
            400,
            "failure"
          )
        );
    }
    const searchQuery = {
      divId,
      dumpedDate: date,
      ...( query && {productName: { $regex: query, $options: "i" }}),
      isDeleted: false,
    };
    info.info(`getDumpedWastage divId:${divId} searchQuery:${JSON.stringify(searchQuery)}`);

    const projection = {
      _id: 1,
      procedureId: 1,
      productName: 1,
      isProduct: 1,
      price: 1,
      qty: 1,
      unit: 1,
      dumpedImage: 1,
    };
    const result = await collection
      .find(searchQuery, { projection })
      .sort({ createdAt: 1 })
      .toArray();

    const response = generateResponse(
      "Dumped wastage fetched successfully",
      200,
      "success",
      result
    );
    info.info(`getDumpedWastage divId:${divId} completed successfully}`);
    res.status(200).json(response);
  } catch (err: any) {
    error.error(`getDumpedWastage divId:${divId} errorMessage:${err.message}`);
    res.status(500).json(generateResponse("Internal server error", 500, "failed"));
  }
}

export async function dumpedWastageReport(req: Request, res: Response) {
  info.info(`dumpedWastageReport initiated`);
  info.info(`dumpedWastageReport req.query:${JSON.stringify(req.query)}`);
  info.info(`dumpedWastageReport reqBody:${JSON.stringify(req.body)}`);
  const {orgId} = req.query;
  const {  divId, date, monthAndYear, dateRange } = req.body;

  if (!orgId || orgId === "") {
    error.error(`dumpedWastageReport error: orgId missing`)
    return res
      .status(400)
      .json(generateResponse("Organisation Id is missing", 400, "failure"));
  }

  if (!divId || divId === "") {
    error.error(`dumpedWastageReport error: divId missing`)
    return res
      .status(400)
      .json(generateResponse("Division Id is missing", 400, "failure"));
  }

  try {
    let page = parseInt(req.query.page as string, 10) || 1;
    const pageSize = parseInt(req.query.pageSize as string, 10) || 10;
    let skip = (page - 1) * pageSize;
    const sortField = req.query.sortField
      ? req.query.sortField.toString()
      : "dumpedDate";
    const sortOrder = req.query.sortOrder === "desc" ? -1 : 1;

    const dateRegex = /^\d{4}-\d{2}-\d{2}$/;

    const validateDate = (
      res: Response<any, Record<string, any>>,
      date: string,
      errorMessage: string
    ) => {
      if (!dateRegex.test(date)) {
        error.error(`dumpedWastageReport divId:${divId} validateDate error:${errorMessage}`);
        return res
          .status(400)
          .json(generateResponse(errorMessage, 400, "failure"));
      }
      return true;
    };

    const validateNumeric = (
      res: Response<any, Record<string, any>>,
      date: string,
      errorMessage: string,
      length: number
    ) => {
      const numericRegex = new RegExp(`^\\d{${length}}$`);
      if (!numericRegex.test(date)) {
        error.error(`dumpedWastageReport divId:${divId} validateNumeric error:${errorMessage}`);
        return res
          .status(400)
          .json(generateResponse(errorMessage, 400, "failure"));
      }
      return true;
    };

    const queryCondition: any = [
      { $eq: ["$orgId", orgId] },
      { $eq: ["$divId", divId] },
      { $eq: ["$isDeleted", false] },
    ];

    if (date) {
      if (validateDate(res, date, "Invalid date value")) {
        queryCondition.push({ $eq: ["$dumpedDate", date] });
      }
    } else if (monthAndYear) {
      const { month, year } = monthAndYear;
      if (
        validateNumeric(res, month, "Invalid Month value", 2) &&
        validateNumeric(res, year, "Invalid Year value", 4)
      ) {
        queryCondition.push(
          { $eq: [{ $year: { $toDate: "$dumpedDate" } }, parseInt(year)] },
          { $eq: [{ $month: { $toDate: "$dumpedDate" } }, parseInt(month)] }
        );
      }
    } else if (dateRange) {
      const { fromDate, toDate } = dateRange;
      if (
        validateDate(res, fromDate, "Invalid From date value") &&
        validateDate(res, toDate, "Invalid To date value")
      ) {
        queryCondition.push(
          { $gte: ["$dumpedDate", fromDate] },
          { $lte: ["$dumpedDate", toDate] }
        );
      }
    } else {
      error.error(`dumpedWastageReport divId:${divId} error: date value missing`)
      return res
        .status(400)
        .json(generateResponse("Date value is missing", 400, "failure"));
    }

    info.info(
      `dumpedWastageReport divId:${divId} queryCondition data: ${JSON.stringify(
        queryCondition
      )}`
    );
    const pipeline = [
      {
        $match: {
          $expr: {
            $and: queryCondition,
          },
        },
      },
      {
        $project: {
          _id: 0,
          procedureId: 1,
          productName: 1,
          dumpedDate: 1,
          dumpedImage: 1,
          unit: 1,
          price: 1,
          qty: 1,
        },
      },
      {
        $facet: {
          data: [
            {
              $sort: { [sortField]: sortOrder },
            },
            { $skip: skip },
            { $limit: Number(pageSize) },
          ],
          total: [{ $count: "count" }],
        },
      },
    ]
    const dumpedWastageReport = await collection
      .aggregate(pipeline)
      .sort({ dumpedDate: 1 })
      .toArray();
    let totalPriceAmount = 0;

    let listData = dumpedWastageReport[0]?.data || [];
    let totalCount = dumpedWastageReport[0]?.total[0]?.count || 0;
    await listData.map((procedure: any) => {
      totalPriceAmount += parseFloat(procedure.price);
    });
    let roundTotalPrice = (Math.round(totalPriceAmount * 100) / 100).toFixed(2);
    info.info(`dumpedWastageReport divId:${divId} roundTotalPrice: ${roundTotalPrice}`);
    const result = {
      totalPriceAmount: roundTotalPrice,
      totalCount,
      list: listData,
    };
    const response = generateResponse(
      "Dumped wastage report fetched successfully",
      200,
      "success",
      result
    );
    info.info(`dumpedWastageReport divId:${divId} completed pipeLineL ${JSON.stringify(pipeline)}}`);
    res.status(200).json(response);
  } catch (err: any) {
    error.error(`dumpedWastageReport divId:${divId} errorMessage:${err.message}`);
    res.status(500).json(generateResponse("Internal server error", 500, "failed"));
  }
}

export async function productWastageList(req: Request, res: Response) {
  info.info(`productWastageList initiated`);
  info.info(`productWastageList req.Body:${JSON.stringify(req.body)}`);
  const {orgId} = req.query;
  const { procedureId, date, monthAndYear, dateRange } = req.body;

  if (!orgId || orgId === "") {
    error.error(`productWastageList error: orgId missing`)
    return res
      .status(400)
      .json(generateResponse("Organisation Id is missing", 400, "failure"));
  }

  if (!procedureId || procedureId === "") {
    error.error(`productWastageList error: procedureId missing`)
    return res
      .status(400)
      .json(generateResponse("Procedure Id is missing", 400, "failure"));
  }

  try {
    let page = parseInt(req.query.page as string, 10) || 1;
    const pageSize = parseInt(req.query.pageSize as string, 10) || 10;
    let skip = (page - 1) * pageSize;
    const sortField = req.query.sortField
      ? req.query.sortField.toString()
      : "createdAt";
    const sortOrder = req.query.sortOrder === "desc" ? -1 : 1;

    const dateRegex = /^\d{4}-\d{2}-\d{2}$/;

    const validateDate = (
      res: Response<any, Record<string, any>>,
      date: string,
      errorMessage: string
    ) => {
      if (!dateRegex.test(date)) {
        error.error(`productWastageList orgId:${orgId} validateDate error:${errorMessage}`);
        return res
          .status(400)
          .json(generateResponse(errorMessage, 400, "failure"));
      }
      return true;
    };

    const validateNumeric = (
      res: Response<any, Record<string, any>>,
      date: string,
      errorMessage: string,
      length: number
    ) => {
      const numericRegex = new RegExp(`^\\d{${length}}$`);
      if (!numericRegex.test(date)) {
        error.error(`productWastageList orgId:${orgId} validateNumeric error:${errorMessage}`);
        return res
          .status(400)
          .json(generateResponse(errorMessage, 400, "failure"));
      }
      return true;
    };

    const dumpedQueryCondition: any = [
      { $eq: ["$orgId", orgId] },
      { $eq: ["$procedureId", procedureId] },
      { $eq: ["$isDeleted", false] },
    ];

    const reusableQueryCondition: any = [
      { $eq: ["$orgId", orgId] },
      { $eq: ["$procedureId", procedureId] },
      { $eq: ["$isDeleted", false] },
    ];

    if (date) {
      if (validateDate(res, date, "Invalid date value")) {
        dumpedQueryCondition.push({ $eq: ["$dumpedDate", date] });
        reusableQueryCondition.push({ $eq: ["$reusableDate", date] });
      }
    } else if (monthAndYear) {
      const { month, year } = monthAndYear;
      if (
        validateNumeric(res, month, "Invalid Month value", 2) &&
        validateNumeric(res, year, "Invalid Year value", 4)
      ) {
        dumpedQueryCondition.push(
          {
            $eq: [{ $year: { $toDate: "$dumpedDate" } }, parseInt(year)],
          },
          {
            $eq: [{ $month: { $toDate: "$dumpedDate" } }, parseInt(month)],
          }
        );
        reusableQueryCondition.push(
          {
            $eq: [{ $year: { $toDate: "$reusableDate" } }, parseInt(year)],
          },
          {
            $eq: [{ $month: { $toDate: "$reusableDate" } }, parseInt(month)],
          }
        );
      }
    } else if (dateRange) {
      const { fromDate, toDate } = dateRange;
      if (
        validateDate(res, fromDate, "Invalid From date value") &&
        validateDate(res, toDate, "Invalid To date value")
      ) {
        dumpedQueryCondition.push(
          {
            $gte: ["$dumpedDate", fromDate],
          },
          {
            $lte: ["$dumpedDate", toDate],
          }
        );
        reusableQueryCondition.push(
          {
            $gte: ["$reusableDate", fromDate],
          },
          {
            $lte: ["$reusableDate", toDate],
          }
        );
      }
    } else {
      error.error(`productWastageList orgId:${orgId} error: date value missing`)
      return res
        .status(400)
        .json(generateResponse("Date value is missing", 400, "failure"));
    }

    info.info(
      `dumpedWastage orgId:${orgId} queryCondition data: ${JSON.stringify(
        dumpedQueryCondition
      )}`
    );
    info.info(
      `reusableWastage orgId:${orgId} queryCondition data: ${JSON.stringify(
        reusableQueryCondition
      )}`
    );
        const pipeline =[
          {
            $match: {
              $expr: {
                $and: dumpedQueryCondition,
              },
            },
          },
          {
            $addFields: {
              date: "$dumpedDate",
              wastageType: "dumped",
            },
          },
          {
            $unionWith: {
              coll: "reusableWastage",
              pipeline: [
                {
                  $match: {
                    $expr: {
                      $and: reusableQueryCondition,
                    },
                  },
                },
                {
                  $addFields: {
                    date: "$reusableDate",
                    wastageType: "reusable",
                  },
                },
              ],
            },
          },
          {
            $group: {
              _id: null,
              totalQty: { $sum: "$qty" },
              totalPrice: { $sum: "$price" },
              count: { $sum: 1 },
              result: {
                $push: {
                  _id: "$_id",
                  divId: "$divId",
                  date: "$date",
                  qty: "$qty",
                  unit: "$unit",
                  wastageType: "$wastageType",
                },
              },
            },
          },
          {
            $sort: { [sortField]: sortOrder },
          },
          {
            $project: {
              _id: 0,
              data: {
                $slice: ["$result", skip, pageSize],
              },
              totalQty: 1,
              totalPrice: 1,
              totalCount: "$count",
            },
          },
        ]
        info.info(
          `ProductWastageList orgId:${orgId} productQty pipeLine:${JSON.stringify(pipeline)}`
        );
    const result = await collection
      .aggregate(pipeline)
      .toArray();

    const resultData = result[0]?.data || [];
    const totalCount = result[0]?.totalCount || 0;
    const totalQty = result[0]?.totalQty || 0;
    const totalPrice = result[0]?.totalPrice || 0;

    let divIds = Array.from(
      new Set(resultData.map((item: { divId: String }) => item.divId))
    );

    const apiEndpoint = `http://${baseURL}:${orgServicePort}/api/div/nameList`;

    const axiosDivIdResponse = await axios.post(apiEndpoint, {divIds});

    const productQty = axiosDivIdResponse.data || [];

    const resultArray = await resultData.map((item: { divId: string }) => {
      const matchingDiv = productQty.find(
        (div: { divId: string }) => div.divId === item.divId
      );
      return matchingDiv ? { ...item, divName: matchingDiv.divName } : item;
    });

    const data = {
      totalCount,
      totalQty,
      totalPrice,
      list: resultArray,
    };
    info.info(`productWastageList orgId:${orgId} data fetched`);
    const response = generateResponse(
      "Wastage list fetched",
      200,
      "success",
      data
    );
    res.status(200).json(response);
  } catch (err: any) {
    error.error(`productWastageList orgId:${orgId} errorMessage:${err.message}`);
    res.status(500).json(generateResponse("Internal server error", 500, "failed"));
  }
}
