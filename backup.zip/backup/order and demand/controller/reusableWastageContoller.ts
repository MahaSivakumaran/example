import { Request, Response } from "express";
import { info, error } from "../config/loggerConfig";
import { reusableWastage } from "../model/reusableWastageModel";
import { generateResponse } from "../utils/responseGenerate";
import axios from "axios";
import moment from 'moment';
import { createRWasteId } from "../utils/idGenerate";

const baseURL = process.env.BASE_URL;
const productServicePort = process.env.PRODUCT_SERVICE_PORT;

const currentDate: moment.Moment = moment();
let collection: any;
export const reusableWastageInstance = async () => {
  collection = await reusableWastage();
};

export async function createReusableWastage(req: Request, res: Response) {
    info.info(`createReusableWastage initiated`);
    info.info(`createReusableWastage req.body:${JSON.stringify(req.body)}`);
  
    try {
      var { orgId, divId, procedureId, productName, isProduct, qty, unit } = req.body;
  
      
      if (!procedureId || procedureId === "") {
        error.error(`createReusableWastage error: procedureId missing`)
        return res
        .status(400)
        .json(generateResponse("Product Id is missing", 400, "failure"));
      }
  
      if (!orgId || orgId === "") {
        error.error(`createReusableWastage error: orgId missing`)
        return res
          .status(400)
          .json(generateResponse("Organisation Id is missing", 400, "failure"));
      }
      
      if (!divId || divId === "") {
        error.error(`createReusableWastage error: divId missing`)
        return res
        .status(400)
        .json(generateResponse("Division Id is missing", 400, "failure"));
      }
      
      if (!productName || productName === "") {
        error.error(`createReusableWastage error: productName missing`);
        return res
        .status(400)
        .json(generateResponse("Product Name is missing", 400, "failure"));
      }
      
      if (isProduct == null || isProduct === "") {
        error.error(`createReusableWastage error: isProduct missing`)
        return res
        .status(400)
        .json(generateResponse("isProduct value is missing", 400, "failure"));
      }
      const axiosProductPriceResponse = await axios.get(
        `http://${baseURL}:${productServicePort}/api/product/getPrice/${procedureId}`
        );
        
        const productQty = axiosProductPriceResponse.data.qty;
        const productPrice = axiosProductPriceResponse.data.price;
        
      qty = qty > 0 ? qty : 0;
      const Price = (productPrice / productQty) * qty;
      
      const totalPrice = (Math.round(Price * 100) / 100).toFixed(2);
      info.info(`createReusableWastage totalPrice: ${totalPrice}`)

  
      
      const reusableDate: string = currentDate.format('YYYY-MM-DD');
      info.info(`createReusableWastage reusableDate: ${reusableDate}`)
      const id = await createRWasteId();
      const insertedData = {
        _id: id,
        orgId,
        divId,
        reusableDate,
        procedureId,
        productName,
        isProduct,
        price: Number(totalPrice),
        qty: Number(qty),
        unit,
        isDeleted: false,
        createdAt: new Date(),
        updatedAt: new Date(),
      }
      await collection.insertOne(insertedData);
      info.info(`createReusableWastage id:${id} successfully insertedData: ${JSON.stringify(insertedData)}`);
      const response = generateResponse(
        "Created reusable wastage successfully",
        201,
        "success",
      );
      res.status(200).json(response);
    } catch (err: any) {
      error.error(`createReusableWastage errorMessage:${err.message}`);
      res.status(500).json(generateResponse("Internal server error", 500, "failed"));
    }
}


export async function editReusableWastage (req: Request, res: Response){
  const { id } = req.params;
  info.info(`editReusableWastage id:${id} initiated`);
  info.info(`editReusableWastage id:${id} reqParams:${JSON.stringify(req.params)}`);
  info.info(`editReusableWastage id:${id} reqBody:${JSON.stringify(req.body)}`);
  
  try {
    
      var { procedureId, productName, isProduct, qty, unit } = req.body;
  
  
      if (!procedureId || procedureId === "") {
        error.error(`editReusableWastage id:${id} error: procedureId missing`)
        return res
          .status(400)
          .json(generateResponse("Product Id is missing", 400, "failure"));
      }
      
      if (!productName || productName === "") {
        error.error(`editReusableWastage id:${id} error: productName missing`)
        return res
          .status(400)
          .json(generateResponse("Product Name is missing", 400, "failure"));
      }
  
      if (isProduct === "") {
        error.error(`editReusableWastage id:${id} error: isProduct missing`)
        return res
          .status(400)
          .json(generateResponse("isProduct value is missing", 400, "failure"));
      }
      const axiosProductPriceResponse = await axios.get(
        `http://${baseURL}:${productServicePort}/api/product/getPrice/${procedureId}`
      );
          
      const productQty = axiosProductPriceResponse.data.qty;
      const productPrice = axiosProductPriceResponse.data.price;
      qty = qty > 0 ? qty : 0;
      const Price = (productPrice / productQty) * qty;
  
      const totalPrice = (Math.round(Price * 100) / 100).toFixed(2);
      info.info(`editReusableWastage id:${id} totalPrice: ${totalPrice}`)
  
      var updatedData: any = {
        productName,
        isProduct,
        qty: Number(qty),
        unit,
        price: Number(totalPrice),
        updatedAt: new Date(),
      };
      
  
      info.info(`editReusableWastage id"${id} updateddata:${JSON.stringify(updatedData)}`);
  
      const result = await collection.findOneAndUpdate(
        { _id: id },
        {
          $set: updatedData,
        },
        {
          new: true,
        }
      );
  
      if (result) {
        info.info(`editReusableWastage id:${id} updated successfully`);
        const response = generateResponse(
          "Reusable wastage updated successfully",
          200,
          "success"
        );
        res.status(200).json(response);
      } else {
        error.error(`editReusableWastage id:${id} error: wastage not found`);
        const response = generateResponse(
          "Reusable wastage not found",
          404,
          "error"
        );
        res.status(404).json(response);
      }
    } catch (err: any) {
      error.error(`editReusableWastage id:${id} errorMessage:${err.message}`);
      res.status(500).json(generateResponse("Internal server error", 500, "failed"));
    }
  
  }


  export const deleteReusableWastage = async (req: Request, res: Response) => {
    info.info(`deleteReusableWastage initiated`);
    info.info(`deleteReusableWastage req.params ${JSON.stringify(req.params)}`);
  
    try{
    const { id } = req.params;
  
    if (!id || id === "") {
        return res.status(400).json(generateResponse("Reusable wastage is missing", 400, "failure"));
    }
  
    const updatedData = {
      isDeleted: true,
      updatedAt: new Date(),
    };
    info.info(`Delete reusable wastage updated data: ${JSON.stringify(updatedData)}`);
  
    const result = await collection.findOneAndUpdate(
      { _id: id },
      {
        $set: updatedData,
      },
      {
        new: true,
      }
    );
  
  
    if (result) {
      info.info(`Reusable wastage deleted successfully for id: ${id}`);
  
      const response = generateResponse(
        "Reusable wastage deleted successfully",
        200,
        "success"
      );
      res.status(200).json(response);
      info.info(`deleteReusableWastage completed`)
    } else {
      error.error(`deleteReusableWastage error: data not found`)
      const response = generateResponse(
        "Reusable wastage not found",
        404,
        "error"
      );
      res.status(404).json(response);
      error.error(`deleteReusableWastage error: data not found`)
    }
  
    } catch (err: any) {
        const response = generateResponse("Internal server error", 500, "failure");
        error.error(`deleteReusableWastage errMessage: ${err.message}`);
        res.status(500).json(response);
    }
  };



  export async function getReusableWastage(req: Request, res: Response) {
    const { divId } = req.params;
    info.info(`getReusableWastage divId:${divId} initiated`);
    info.info(`getReusableWastage divId:${divId} reqBody:${JSON.stringify(req.body)}`);
    info.info(`getReusableWastage divId:${divId} reqParams:${JSON.stringify(req.params)}`);
    info.info(`getReusableWastage divId:${divId} reqQuery:${JSON.stringify(req.query)}`);
    try {
  
      const { query } = req.query;
      const { date } = req.body;
  
  
  
      if(!date || date === ""){
        error.error(`getReusableWastage divId:${divId} error: date value missing`)
        return res
        .status(400)
        .json(generateResponse("Date value is empty", 400, "failure"));
      }
  
      const isValidDateFormat = (dateString: string) => {
        const dateFormatRegex = /^\d{4}-\d{2}-\d{2}$/;
        return dateFormatRegex.test(dateString);
      }
  
      const currentDate = moment().format('YYYY-MM-DD');
  
      if (!isValidDateFormat(date)) {
        error.error(`getReusableWastage divId:${divId} error: date format missmatched`)
        return res
        .status(400)
        .json(generateResponse("Invalid date format", 400, "failure"));
      }
  
      if (date > currentDate) {
        error.error(`getReusableWastage divId:${divId} error: Invalid date`)
        return res
        .status(400)
        .json(generateResponse("Invalid Reusable date, it should be today or a previous day's date", 400, "failure"));
      }
        const searchQuery = { 
          divId,
          reusableDate: date,
          ...( query && {productName: { $regex: query, $options: 'i' }}),
          isDeleted: false
      };
      info.info(`getReusableWastage divId:${divId} searchQuery:${JSON.stringify(searchQuery)}`);
  
      const projection = {
        _id: 1,
        procedureId: 1,
        productName: 1,
        isProduct: 1,
        price: 1,
        qty: 1,
        unit: 1,
      };
      const result = await collection.find(searchQuery, {projection}).sort({ createdAt: 1 }).toArray();
      
      const response = generateResponse(
        "Reusable wastage fetched successfully",
        200,
        "success",
        result
      );
      info.info(`getReusableWastage divId:${divId} completed successfully}`);
      res.status(200).json(response);
    } catch (err: any) {
      error.error(`getReusableWastage divId:${divId} errorMessage:${err.message}`);
      res.status(500).json(generateResponse("Internal server error", 500, "failed"));
    }
  
  }


  export async function reusableWastageReport(req: Request, res: Response) {
    info.info(`reusableWastageReport initiated`);
    info.info(`reusableWastageReport req.query:${JSON.stringify(req.query)}`);
    info.info(`reusableWastageReport reqBody:${JSON.stringify(req.body)}`);
    const { orgId, divId, date, monthAndYear, dateRange } = req.body;

    if (!orgId || orgId === "") {
      error.error(`reusableWastageReport error: orgId is missing`)
      return res
        .status(400)
        .json(generateResponse("Organisation Id is missing", 400, "failure"));
    }

    if (!divId || divId === "") {
      error.error(`reusableWastageReport error: divId is missing`)
      return res
        .status(400)
        .json(generateResponse("Division Id is missing", 400, "failure"));
    }

    try {
      let page = parseInt(req.query.page as string, 10) || 1;
      const pageSize = parseInt(req.query.pageSize as string, 10) || 10;
      let skip = (page - 1) * pageSize;
      const sortField = req.query.sortField
        ? req.query.sortField.toString()
        : "reusableDate";

      const sortOrder = req.query.sortOrder === "desc" ? -1 : 1;

      const dateRegex = /^\d{4}-\d{2}-\d{2}$/;

      const validateDate = (
        res: Response<any, Record<string, any>>,
        date: string,
        errorMessage: string
      ) => {
        if (!dateRegex.test(date)) {
          return res
            .status(400)
            .json(generateResponse(errorMessage, 400, "failure"));
        }
        return true;
      };

      const validateNumeric = (
        res: Response<any, Record<string, any>>,
        date: string,
        errorMessage: string,
        length: number
      ) => {
        const numericRegex = new RegExp(`^\\d{${length}}$`);
        if (!numericRegex.test(date)) {
          return res
            .status(400)
            .json(generateResponse(errorMessage, 400, "failure"));
        }
        return true;
      };

      const queryCondition: any = [
        { $eq: ["$orgId", orgId] },
        { $eq: ["$divId", divId] },
        { $eq: ["$isDeleted", false] },
      ];

      if (date) {
        if (validateDate(res, date, "Invalid date value")) {
          queryCondition.push({ $eq: ["$reusableDate", date] });
        }
      } else if (monthAndYear) {
        const { month, year } = monthAndYear;
        if (
          validateNumeric(res, month, "Invalid Month value", 2) &&
          validateNumeric(res, year, "Invalid Year value", 4)
        ) {
          queryCondition.push(
            { $eq: [{ $year: { $toDate: "$reusableDate" } }, parseInt(year)] },
            { $eq: [{ $month: { $toDate: "$reusableDate" } }, parseInt(month)] }
          );
        }
      } else if (dateRange) {
        const { fromDate, toDate } = dateRange;
        if (
          validateDate(res, fromDate, "Invalid From date value") &&
          validateDate(res, toDate, "Invalid To date value")
        ) {
          queryCondition.push(
            { $gte: ["$reusableDate", fromDate] },
            { $lte: ["$reusableDate", toDate] }
          );
        }
      } else {
        error.error(`reusableWastageReport divId:${divId} error: Date value is missing`)
        return res
          .status(400)
          .json(generateResponse("Date value is missing", 400, "failure"));
      }

      info.info(
        `reusableWastageReport divId:${divId} queryCondition data: ${JSON.stringify(
          queryCondition
        )}`
      );
      const pipeLine =[
        {
          $match: {
            $expr: {
              $and: queryCondition,
            },
          },
        },
        {
          $project: {
            _id: 0,
            procedureId: 1,
            productName: 1,
            reusableDate: 1,
            unit: 1,
            price: 1,
            qty: 1,
          },
        },
        {
          $facet: {
            data: [
              {
                $sort: { [sortField]: sortOrder },
              },
              { $skip: skip },
              { $limit: Number(pageSize) },
            ],
            total: [{ $count: "count" }],
          },
        },
      ]
      info.info(`reusableWastageReport divId:${divId} pipeLine: ${JSON.stringify(pipeLine)}}`);
      const reusableWastageReport = await collection
        .aggregate(pipeLine)
        .sort({ reusableDate: 1 })
        .toArray();
      let totalPriceAmount = 0;
      let listData = reusableWastageReport[0]?.data || [];
      let totalCount = reusableWastageReport[0]?.total[0]?.count || 0;
      await listData.map((procedure: any) => {
        totalPriceAmount += parseFloat(procedure.price);
      });
      let roundTotalPrice = (Math.round(totalPriceAmount * 100) / 100).toFixed(
        2
      );
      info.info(`reusableWastageReport divId:${divId} roundTotalPrice: ${roundTotalPrice}`)
      const result = {
        totalPriceAmount: roundTotalPrice,
        totalCount,
        list: listData,
      };
      const response = generateResponse(
        "Reusable wastage report fetched successfully",
        200,
        "success",
        result
      );
      info.info(`reusableWastageReport divId:${divId} data fetched`);
      res.status(200).json(response);
    } catch (err: any) {
      error.error(`reusableWastageReport divId:${divId} errorMessage:${err.message}`);
      res.status(500).json(generateResponse("Internal server error", 500, "failed"));
    }
  }