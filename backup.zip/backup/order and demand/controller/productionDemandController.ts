import { Request, Response } from "express";
import { info, error } from "../config/loggerConfig";
import { generateResponse } from "../utils/responseGenerate";
import { productDemand } from "../model/productDemandModel";
import { isWithiInCurrentDay } from "../utils/timeCheckingForApproval";
import { createProductionDemandId } from "../utils/idGenerate";
import { getOrderDetails, orderData, receivedOrderList, supplyOrder } from "./orderController";
import { monthCal } from "../utils/monthCalculator";
import axios from "axios";

const baseURL = process.env.BASE_URL;
const orgServicePort = process.env.PRODUCT_ORG_PORT;
const productServicePort = process.env.PRODUCT_SERVICE_PORT;

let collection: any;
export const productionDemandInstance = async () => {
    collection = await productDemand();
}

export async function createProductionDemand(req: Request, res: Response,) {

    info.info(`createProductionDemand initiated`);
    info.info(`createProductionDemand reqBody:${JSON.stringify(req.body)}`);

    try {
        let { orgId, divId, id, orderedDateStr, name, qty, unit, procedureId, shift, divName, groupProducts } = req.body;

        const demandData = await collection.findOne({ divId, procedureId, isApproved: false, isDeleted: false, orderedDate: orderedDateStr });
        if (demandData) {
            info.info(`createProductionDemand divId:${divId} procedureId:${procedureId} demandData true`);
            let newQty = demandData.qty + qty;
            if (demandData.groupProducts && demandData.groupProducts.length > 0) {
                let oldQty = demandData.qty;
                let updatedGroupProducts: any[] = [];
                demandData.groupProducts.forEach((product: any) => {
                    let productQty = product.qty / oldQty;
                    product.qty = parseInt((productQty * newQty).toString());
                    updatedGroupProducts.push(product);
                });
                const updatedData = {
                    qty: newQty,
                    groupProducts: updatedGroupProducts,
                    updatedAt: new Date()
                };
                info.info(`createProductionDemand divId:${divId} procedureId:${procedureId} updatedData:${JSON.stringify(updatedData)}`);
                await collection.findOneAndUpdate({ _id: demandData._id }, {
                    $set: updatedData
                });
            }
            else {
                const updatedData = {
                    qty: newQty,
                    updatedAt: new Date()
                };
                info.info(`createProductionDemand divId:${divId} procedureId:${procedureId} updatedData:${JSON.stringify(updatedData)}`);
                await collection.findOneAndUpdate({ _id: demandData._id }, {
                    $set: updatedData
                });
            }
            info.info(`createProductionDemand divId:${divId} procedureId:${procedureId} data updated`);
            return res.status(200).send(generateResponse("Demand added to the existing demand", 200, "success"));
        }

        if (groupProducts && groupProducts.length > 0) {
            for (let product of groupProducts) {
                product.qty = product.qty * qty;
                product.isApproved = false;
            }
        }
        else {
            groupProducts = [];
        }

        const insertedData = {
            _id: await createProductionDemandId(),
            orgId,
            divId,
            divName,
            orderedDate: orderedDateStr,
            id,
            name,
            qty,
            sentQty: 0,
            receivedQty: 0,
            unit,
            procedureId,
            shift,
            groupProducts,
            isReceived: false,
            isSentFromTP: false,
            isApproved: false,
            isDeleted: false,
            createdAt: new Date(),
            updatedAt: new Date()

        };

        await collection.insertOne(insertedData);
        const response = generateResponse('Production Demand created successfully', 200, 'success');
        info.info(`createProductionDemand created insertedData: ${JSON.stringify(insertedData)}`);
        res.status(200).json(response);

    } catch (err: any) {
        error.error(`createProductionDemand errorMessage : ${err.message}`);
        res.status(500).json(generateResponse(`Internal server error`, 500, `failed`));
    }
}



export async function editProductionDemand(req: Request, res: Response) {

    info.info(`editProductionDemand initiated`);
    const { orgId } = req.query;
    if (!orgId) {
        error.error(`editProductionDemand error: orgId missing`);
        return res.status(400).send(generateResponse("Company id is missing", 400, "failed"));
    }
    info.info(`editProductionDemand orgId:${orgId} reqParams:${JSON.stringify(req.params)}`);
    info.info(`editProductionDemand orgId:${orgId} req.body:${JSON.stringify(req.body)}`);

    const { itemId } = req.params;
    if (!itemId) {
        error.error(`editProductionDemand orgId:${orgId} error: itemId missing`)
        return res.status(400).json(generateResponse("Id is missing", 400, "failure"));
    }

    let { orderedDate, qty, unit, shift } = req.body;

    try {
        const currentDocument = await collection.findOne({ _id: itemId });

        if (!currentDocument) {
            error.error(`editProductionDemand orgId:${orgId} error: item not found`)
            return res.status(404).json(generateResponse("Item not found", 404, "failure"));
        }
        if (currentDocument.isApproved) {
            error.error(`editProductionDemand orgId:${orgId} error: Item already approved`)
            return res.status(400).json(generateResponse("Edit not allowed: Item already approved", 400, "failure"));
        }
        if (!isWithiInCurrentDay(currentDocument.createdAt)) {
            error.error(`editProductionDemand orgId:${orgId} error: Document created after 11:59 PM`)
            return res.status(400).json(generateResponse("Edit not allowed: Document created after 11:59 PM", 400, "failure"));
        }
        let gProducts: any = [];
        if (currentDocument.groupProducts && currentDocument.groupProducts.length > 0) {
            let newQty = currentDocument.qty + qty;
            qty = newQty;
            let oldQty = currentDocument.qty;
            currentDocument.groupProducts.map((product: any) => {
                let productQty: any = product.qty / oldQty;
                product.qty = parseInt(productQty);
                productQty = parseInt(productQty);
                product.qty = parseInt((productQty * newQty).toString());
                gProducts.push(product);
            });
        }
        const updatedData = { orderedDate, qty, unit, shift, groupProducts: gProducts };

        await collection.findOneAndUpdate(
            { _id: itemId },
            { $set: updatedData }
        );

        info.info(`editProductionDemand orgId:${orgId} completed id:${itemId} updatedData:${JSON.stringify(updatedData)}`);
        const response = generateResponse('Item updated successfully', 200, 'success');
        return res.status(200).json(response);

    } catch (error: any) {
        error.error(`editProductionDemand orgId:${orgId} errorMessage:${error.message}`);
        return res.status(500).json(generateResponse(`Internal server error`, 500, `failed`));
    }
}


export async function deletetProductionDemand(req: Request, res: Response) {
    const { id } = req.params;

    info.info(`deletetProductionDemand initiated for Id:${id}`);
    info.info(`deletetProductionDemand reqParams:${JSON.stringify(req.params)} Id:${id}`);
    const updatedData = {
        isDeleted: true,
        updatedAt: new Date()
    };
    try {
        const data = await collection.findOne({ _id: id });
        if (!data) {
            error.error(`deletetProductionDemand error: no data found for id:${id}`);
            return res.status(404).json(generateResponse(`No data found..`, 404, `failed`));
        }
        await collection.findOneAndUpdate(
            { _id: id },
            { $set: updatedData },
            { new: true },
        );

        info.info(`deletetProductionDemand work completed for id : ${id}`);
        const response = generateResponse(`Document deleted successfully `, 200, 'success')
        res.status(200).json(response);

    } catch (err: any) {
        error.error(`deletetProductionDemand errorMessage:${err.message} for Id:${id}`);
        res.status(500).json({ success: false, error: 'Internal Server Error' });

    }
}

export async function allProductionDemands(req: Request, res: Response) {
    info.info(`allProductionDemands initiated`);
    info.info(`allProductionDemands req.query:${JSON.stringify(req.query)}`);

    const project = {
        _id: 1,
        orgId: 1,
        divId: 1,
        orderedDate: 1,
        id: 1,
        name: 1,
        qty: 1,
        unit: 1,
        procedureId: 1,
        shift: 1,
        isApproved: 1,
        isProcedure: 1,
        isProduct: 1,

    }

    try {
        const { orderedDate, name } = req.query;
        const page = req.query.page ? parseInt(req.query.page as string, 10) : 1;
        const pageSize = req.query.pageSize ? parseInt(req.query.pageSize as string, 10) : 10;
        const searchFilter: any = {
            isDeleted: false,
        };

        if (orderedDate) {
            searchFilter.orderedDate = { $regex: orderedDate, $options: 'i' };
        }

        if (name) {
            searchFilter.name = { $regex: name, $options: 'i' };
        }

        const aggregationPipeline = [
            { $match: searchFilter },
            { $project: project },
            {
                $facet: {
                    result: [{ $skip: (page - 1) * pageSize }, { $limit: pageSize }],
                    totalCount: [{ $count: "value" }]
                }
            },
            { $unwind: { path: "$totalCount", preserveNullAndEmptyArrays: true } }
        ];

        info.info(`allproductionDemands data fetched, pipeLine:${JSON.stringify(aggregationPipeline)}`)
        const result = await collection.aggregate(aggregationPipeline).toArray();

        if (result.length > 0) {
            const { result: paginatedResult, totalCount } = result[0];
            const data = {
                totalCount,
                list: paginatedResult,
            }
            info.info(`allproductionDemands data fetched`)
            res.status(200).json(generateResponse("Data fetched...!", 200, "success", data));
        } else {
            res.status(404).json({ success: false, error: 'No Data Found' });
        }

    } catch (err: any) {
        error.error(`allProductionDemands errorMessage:${err.message}`);
        res.status(500).json({ success: false, error: 'Internal Server Error' });
    }
}



export async function searchByDate(req: Request, res: Response) {

    info.info(`searchByDate initiated`);
    info.info(`searchByDate req.query:${JSON.stringify(req.query)}`);
    const { startDateStr, endDateStr } = req.query
    const projection = {
        _id: 1,
        isDeleted: 0,
        createdAt: 0,
        updatedAt: 0
    }
    try {
        const startDate = new Date(startDateStr as string).toISOString();
        const endDate = new Date(endDateStr as string).toISOString();
        const result = await collection.find({
            orderedDate: {
                $gte: startDate,
                $lte: endDate
            }
        }).project(projection).toArray();

        if (result.length > 0) {
            info.info(`searchByDate fetched`)
            const response = generateResponse("Items fetched..!", 200, "success", result)
            res.status(200).json(response);
        } else {
            error.error(`sarchByDate error: no data found`);
            return res.status(404).json(generateResponse(`Data not found`, 404, `failed`))
        }
    } catch (err: any) {
        error.error(`Error fetching searchByDate: ${err.message}`);
        res.status(500).json({ error: 'Internal Server Error' });
    }

}

// approval api's

export const shiftList = async (req: Request, res: Response) => {
    info.info(`shiftList initiated`);
    info.info(`shiftList req.query: ${JSON.stringify(req.query)}`);
    const project = {
        _id: 0,
        shift: 1,
        orderedDate: 1
    }
    const { orderedDate, orgId } = req.query
    if (!orgId || !orderedDate) {
        error.error(`shiftList error: orgId or ordered Date missing`)
        res.status(400).json(generateResponse(`orgId or ordered Date missing`, 400, `failed`))
    }
    try {
        const filter: any = {
            orgId,
            isDeleted: false
        };

        if (orderedDate) {
            filter.orderedDate = { $regex: orderedDate, $options: 'i' };
        }
        const results = await collection.find(filter).project(project).toArray()


        if (results.length === 0) {
            error.error(`shiftList error: Item not found`)
            return res.status(404).json(generateResponse("Item not found..", 404, "failure"))
        }
        const formattedResults = results.map((result: any) => ({
            shift: result.shift,
            orderedDate: new Date(result.orderedDate).toISOString().split('T')[0]
        }));

        const response = generateResponse("Items fetched..!", 200, "success", formattedResults)
        res.status(200).json(response);
        info.info(`shiftList completed`)
    } catch (err: any) {
        const response = generateResponse(`Internal server error`, 500, "failure")
        res.status(500).json(response);
        error.error(`shiftList err : ${err.message}`)
    }
}

export const getDemandsFromAllDivs = async (req: Request, res: Response) => {
    try {
        info.info(`getDemandsFromAllDivs initialized`);
        info.info(`getDemandsFromAllDivs req.query ${JSON.stringify(req.query)}`);
        const { id } = req.params

        const { shift, orderedDate, orgId } = req.query
        if (!shift || !orderedDate || !orgId) {
            error.error(`getDemandsFromAllDivs error: orgId or orderedDate missing`)
            return res.status(400).json(generateResponse("Missing required parameters", 400, "failed"));
        }

        const filter: any = {
            isDeleted: false,
            isApproved: false,
            orgId: { $regex: orgId, $options: 'i' },
            orderedDate: { $regex: orderedDate, $options: 'i' },
            shift: { $regex: shift, $options: 'i' },
            id: { $regex: id, $options: 'i' },
        };

        const projection = {
            _id: 1,
            id: 1,
            divId: 1,
            divName: 1,
            name: 1,
            qty: 1,
            unit: 1,
            shift: 1,
            orderedDate: 1
        }

        const data = await collection.find(filter).project(projection).toArray();
        let totalQuantity = 0;

        data.forEach((item: any) => {
            totalQuantity += parseInt(item.qty)
        })
        info.info(`getDemandsFromAllDivs totalQuantity: ${totalQuantity}`)
        const responseData = {
            totalQuantity,
            list: data,
        };

        res.status(200).json(generateResponse("Document Fetched...", 200, "success", responseData));
        info.info(`getDemandsFromDivs completed`);

    } catch (err: any) {
        res.status(500).json(generateResponse("Internal server error", 500, "failed"));
        error.error(`getDemandsFromDivs error message : ${err.message}`);
    }
};

export const editDemand = async (req: Request, res: Response) => {
    info.info(`editDemand initialized`)
    info.info(`editDemand req.params ${JSON.stringify(req.params)}`)
    info.info(`editDemand req.query ${JSON.stringify(req.query)}`)
    const updates = req.body.updates;
    const { shift, orgId } = req.query
    if (!shift || !orgId) {
        error.error(`editDemand error: shift or orgId missing`)
        res.status(400).json(generateResponse(`shift or orgId missing`, 400, `failed`))
    }
    if (!updates || !Array.isArray(updates)) {
        return res.status(400).json({ error: 'Invalid request format' });
    }
    try {
        let bulkOperations: any = updates.map(({ id, divId, qty }) => ({
            updateOne: {
                filter: { divId, procedureId: id, orgId, isDeleted: false, isApproved: false, shift },
                update: {
                    $set: {
                        qty: parseInt(qty),
                        updatedAt: new Date()
                    }
                }
            }
        }));
        updates.map(({ id, divId, quantity }) => {
            bulkOperations.push({
                updateOne: {
                    filter: {
                        "groupProducts.procedureId": id,
                        divId,
                        orgId,
                        isDeleted: false,
                        "groupProducts.isApproved": false,
                        shift
                    },
                    update: {
                        $set: {
                            "groupProducts.$[group].quantity": parseInt(quantity),
                            updatedAt: new Date()
                        }
                    },
                    arrayFilters: [
                        { "group.procedureId": id }
                    ]
                }
            })
        })
        const result = await collection.bulkWrite(bulkOperations);
        res.status(200).json(generateResponse("Document Edited...", 200, "success"))
        info.info(`editDemand completed`)

    } catch (err: any) {
        res.status(500).json(generateResponse("Internal server error", 500, "failed"))
        error.error(`editDemand error message : ${err.message}`)

    }
}

export const demandApprove = async (req: Request, res: Response) => {
    info.info(`demandApprove initialized`)
    info.info(`demandApprove req.params ${JSON.stringify(req.params)}`)
    info.info(`demandApprove req.body ${JSON.stringify(req.body)}`)
    const _id = req.params.id

    try {
        const data = await collection.findOne(_id)
        if (!data) {
            error.error(`demandApprove error: data not found`);
            res.status(404).json(generateResponse(`data not found`, 404, `failed`));
        }
        await collection.findOneAndUpdate(
            { _id },
            { $set: { qty: req.body.qty } }
        )

        res.status(200).json(generateResponse("Document Edited...", 200, "success"))
        info.info(`demandApprove completed for Id: ${_id}`)

    } catch (err: any) {
        res.status(500).json(generateResponse("Internal server error", 500, "failed"))
        error.error(`demandApprove error message : ${err.message}`)
    }
};

export const getDemandsByShift = async (req: Request, res: Response) => {
    try {
        info.info(`getDemandsByShift initialized`);
        info.info(`getDemandsByShift req.query ${JSON.stringify(req.query)}`);
        const { shift, orderedDate, orgId } = req.query;
        if (!shift || !orderedDate || !orgId) {
            error.error(`getDemandsByShift error: shift or orderedDate or orgId missing`)
            return res.status(400).json(generateResponse("Missing required parameters", 400, "failed"));
        }
        const filter: any = {
            isDeleted: false,
            isApproved: false,
            orgId: { $regex: orgId, $options: 'i' },
            orderedDate: { $regex: orderedDate, $options: 'i' },
            shift: { $regex: shift, $options: 'i' }
        };
        const aggregationPipeline = [
            { $match: filter },
            {
                $group: {
                    _id: '$procedureId',
                    name: { $first: '$name' },
                    totalQuantity: { $sum: { $toInt: '$qty' } },
                    unit: { $first: '$unit' },
                    shift: { $first: '$shift' },
                    orderedDate: { $first: '$orderedDate' },
                    groupProducts: { $first: '$groupProducts' },

                }
            },
            {
                $project: {
                    _id: 1,
                    procedureId: '$_id',
                    name: 1,
                    qty: '$totalQuantity',
                    unit: 1,
                    shift: 1,
                    orderedDate: 1,
                    groupProducts: 1
                }
            }
        ];
        const demandData = await collection.aggregate(aggregationPipeline).toArray();
        let tempData: any = [];
        demandData.map((demand: any) => {
            if (demand.groupProducts && demand.groupProducts.length > 0) {
                demand.groupProducts.map((products: any) => {
                    tempData.push(products);
                })
            }
            else {
                tempData.push(demand);
            }
        });


        const ordersData = await orderData(orgId, shift, orderedDate);

        ordersData.map((orders: any) => {
            tempData.push(orders)
        })
        const result = tempData.reduce((accumulator: any, current: any) => {
            const { procedureId, qty } = current;

            if (!accumulator[procedureId]) {
                accumulator[procedureId] = { ...current };
            } else {
                accumulator[procedureId].qty += qty;
            }

            return accumulator;
        }, {});

        const resultList = Object.values(result);
        res.status(200).json(generateResponse("Document Fetched...", 200, "success", resultList));
        info.info(`getDemandsByShift completed. pipeLine: ${JSON.stringify(aggregationPipeline)}`);
    } catch (err: any) {
        res.status(500).json(generateResponse("Internal server error", 500, "failed"));
        error.error(`getDemandsByShift error message : ${err.message}`);
    }
};


//364

export const demandsFrmEachDiv = async (req: Request, res: Response) => {
    info.info(`demandsFrmEachDiv initialized`);
    info.info(`demandsFrmEachDiv req.query ${req.query}`);
    const { procedureId, orgId, shift, orderedDate } = req.query;
    if (!procedureId || !orgId || !shift || !orderedDate) {
        error.error(`demandsFrmEachDiv error: procedureId, orgId, shift, orderedDate missing`);
        return res.status(400).json(generateResponse(`procedureId or orgId or shift or orderedDate missing`, 400, `failed`))
    }

    try {
        const filter = {
            orgId,
            shift,
            orderedDate,
            isApproved: false,
            isDeleted: false,
            $or: [
                { procedureId },
                { "groupProducts.procedureId": procedureId }
            ]
        };
        const project = {
            _id: 0,
            divId: 1,
            orgId: 1,
            name: 1,
            qty: 1,
            unit: 1,
            divName: 1,
            procedureId: 1,
            groupProducts: 1
        };
        const data = await collection.find(filter).project(project).toArray();


        let tempData: any = [];
        data.map((demand: any) => {
            if (demand.groupProducts && demand.groupProducts.length > 0) {
                demand.groupProducts.map((product: any) => {
                    const divDetails = { ...product, divName: demand.divName, divId: demand.divId, orgId: demand.orgId }
                    if (product.procedureId === procedureId) {
                        tempData.push(divDetails);
                    }
                });
            } else {
                tempData.push(demand);
            }
        });
        const order = await getOrderDetails(procedureId, orgId, shift, orderedDate);
        tempData.forEach((item: any) => {
            const matchingOrder = order.find(
                (orderItem: any) =>
                    String(orderItem.matchingItems.divId) === String(item.divId) &&
                    String(orderItem.matchingItems.procedureId) === String(item.procedureId)
            );

            if (matchingOrder) {
                item.productionDemand = parseInt(item.qty);
                item.qty = parseInt(item.qty, 10) + matchingOrder.qty;
            } else {
                item.productionDemand = parseInt(item.qty);
                item.qty = parseInt(item.qty, 10);
            }
        });
        const ordersWithNoMatchingDemand = order.filter((orderItem: any) =>
            !tempData.some((item: any) =>
                String(orderItem.matchingItems.divId) === String(item.matchingItems.divId) &&
                String(orderItem.matchingItems.procedureId) === String(item.procedureId)
            )
        );
        tempData.push(
            ...ordersWithNoMatchingDemand.map((orderItem: any) => ({
                divId: orderItem.divId,
                orgId: orderItem.orgId,
                name: orderItem.matchingItems.name,
                quantity: orderItem.matchingItems.qty,
                unit: orderItem.matchingItems.unit,
                divName: orderItem.divName,
                procedureId: orderItem.matchingItems.procedureId,
                productionDemand: 0,
            }))
        );
        res.status(200).json(generateResponse(`Data fetched ..`, 200, 'success', tempData));
        info.info(`demandsFrmEachDiv completed`);
    } catch (err: any) {
        error.error(`demandsFrmEachDiv err message : ${err.message}`);
        res.status(500).json(generateResponse(`Internal server error`, 500, 'failed'));
    }
};


export const supplyProduction = async (procedureId: any, orderedDate: any, orgId: any, shift: any, oldProcedureId?: any) => {
    info.info(`supplyProduction initialized`)
    info.info(`supplyProduction procedureId:${procedureId} orderedDate:${orderedDate} orgId:${orgId} shift:${shift} oldProcedureId:${oldProcedureId}`);
    try {
        const result = await collection.updateMany(
            {
                procedureId: oldProcedureId || procedureId,
                orgId,
                orderedDate,
                shift,
                isDeleted: false,
                isApproved: false
            },
            {
                $set:
                {
                    procedureId: procedureId,
                    isApproved: true
                }
            });
        const result2 = await collection.updateMany(
            {
                "groupProducts": {
                    $elemMatch: { procedureId: oldProcedureId || procedureId, isApproved: false }
                },
                orgId,
                orderedDate,
                shift,
                isDeleted: false,
                isApproved: false
            },
            {
                $set: {
                    "groupProducts.$[product].procedureId": procedureId,
                    "groupProducts.$[product].isApproved": true
                }
            },
            {
                arrayFilters: [{
                    "product.procedureId": oldProcedureId || procedureId
                }]
            })

        const result3 = await collection.updateMany({
            orgId,
            isDeleted: false,
            isApproved: false,
            "groupProducts": {
                $not: {
                    $elemMatch: { isApproved: false }
                }
            }
        },
            {
                $set: {
                    isApproved: true
                }
            }
        );

        info.info(`supplyProduction completed`)
        return true;
    } catch (err: any) {
        error.error(`supplyProduction error: ${err.message}`);
        return false;
    }
}

export const approvedList = async (req: Request, res: Response) => {
    info.info(`approvedList req.params: ${JSON.stringify(req.params)}`)
    const { orgId } = req.query;
    if (!orgId) {
        error.error(`approvedList error: orgId missing`)
        return res.status(400).json(generateResponse(`orgId missing`, 400, `failed`))
    }

    const filter = {
        orgId,
        isDeleted: false,
        isReceived: false,
        isApproved: true,
        isSentFromTP: false
    }
    const projection = {
        orgId: 1,
        divName: 1,
        orderedDate: 1,
        name: 1,
        quantity: 1,
        unit: 1,
        shift: 1

    }
    try {
        info.info(` approvedList initialized`);
        const list = await collection.find(filter).project(projection).toArray();
        if (list && list.length > 0) {
            res.status(200).json(generateResponse(`Data fetched..`, 200, "success", list))
            info.info(` approvedList completed for orgId: ${orgId}`);
        } else {
            res.status(404).json(generateResponse(`No data found..`, 404, "failed", list))
            error.error(` approvedList error: no data found for orgId: ${orgId}`);
        }

    } catch (err: any) {
        res.status(500).json(generateResponse(`Internal server error`, 500, "failed"))
        error.error(`approvedList error message: ${err.message}`)
    }
}


export const supplyProductionFromPc = async (req: Request, res: Response) => {
    info.info(`supplyProductionFromPc initialized`)
    info.info(`supplyProductionFromPc req.query ${JSON.stringify(req.query)}`)
    info.info(`supplyProductionFromPc req.body ${JSON.stringify(req.body)}`)
    try {
        const { id } = req.params
        const { orgId } = req.query
        if (!orgId) {
            error.error(`supplyproductionFromPc error: orgId missing`)
            return res.status(400).json(generateResponse(`orgId missing`, 400, `failed`))
        }
        const { sentQty } = req.body
        const updatedData = {
            sentQty,
            isSentFromTp: true,
            updatedAt: new Date()
        }
        const condition = { _id: id, orgId, isDeleted: false, isApproved: true, isReceived: false };

        const existingDocument = await collection.findOne(condition);

        if (existingDocument) {
            await collection.updateOne(
                condition,
                { $set: updatedData }
            );

            res.status(200).json(generateResponse(`Productions supplied`, 200, "success"))
            info.info(`supplyProductionFromPc completed updatedData: ${JSON.stringify(updatedData)}`)
        } else {
            res.status(404).json(generateResponse(`Data not found`, 404, "failed"))
            error.error(`supplyProductionFromPc error: data not found`)
        }


    } catch (err: any) {
        res.status(500).json(generateResponse(`Internal server error`, 500, "failed"));
        error.error(`supplyProductionFromPc error message : ${err.message}`)

    }

}

export const updateReceivedItem = async (req: Request, res: Response) => {
    info.info(`updateReceivedItem initialized`)
    info.info(`updateReceivedItem req.query ${JSON.stringify(req.query)}`);
    info.info(`updateReceivedItem req.body ${JSON.stringify(req.body)}`);
    try {
        const { id } = req.params
        const { orgId } = req.query
        if (!orgId) {
            error.error(`updateReceivedItem error: orgId missing`)
            return res.status(400).json(generateResponse(`orgId missing`, 400, `failed`))
        }
        const { receivedQty } = req.body
        const updatedData = {
            receivedQty,
            isReceived: true,
            updatedAt: new Date()
        }

        const data = await collection.findOne({ _id: id, orgId, isDeleted: false, isApproved: true, isReceived: false, isSentFromTp: true })
        if (data) {

            await collection.updateOne(
                { _id: id, orgId, isDeleted: false, isApproved: true, isReceived: false, isSentFromTp: true },
                { $set: updatedData }
            )

            res.status(200).json(generateResponse(`Productions supplied`, 200, "success"))
            info.info(`updateReceivedItem completed updatedData: ${updatedData}`)
        } else {
            return res.status(404).json(generateResponse(`Data not found..`, 404, `failed`))
        }


    } catch (err: any) {
        res.status(500).json(generateResponse(`Internal server error`, 500, "failed"));
        error.error(`updateReceivedItem error message : ${err.message}`)
    }
}

export const demandReport = async (req: Request, res: Response) => {
    const { id } = req.params;
    const { startDate, endDate, month, date } = req.query;
    info.info(`demandReport initiated for divId ${id}`);
    info.info(`demandReport req.query: ${JSON.stringify(req.query)}`);

    const filter: any = {
        divId: id,
        isReceived: true,
        isDeleted: false
    };
    if (date) {
        filter.orderedDate = date;
    } else if (month) {
        const { firstDayOfMonth, lastDayOfMonth } = monthCal(month as string);

        filter.orderedDate = {
            $gte: firstDayOfMonth,
            $lt: lastDayOfMonth
        };
    } else if (startDate && endDate) {
        filter.orderedDate = {
            $gte: startDate.toString(),
            $lte: endDate.toString()
        };
    }

    const projection = {
        divName: 1,
        orderedDate: 1,
        divId: 1,
        name: 1,
        qty: 1,
        unit: 1,
        procedureId: 1,
    };

    try {
        const list = await collection.find(filter).project(projection).toArray();

        if (list.length === 0) {
            error.error(`demandReport error: Data not found for divId: ${id}`)
            return res.status(404).json(generateResponse(`No data found`, 404, `failed`));
        }
        info.info(`demandReport data fetched completed`)
        res.status(200).json(generateResponse(`Data fetched successfully.`, 200, `success`, list));
    } catch (err: any) {
        error.error(`demandReport error message: ${err.message}`);
        res.status(500).json(generateResponse(`Internal server error`, 500, `failed`));
    }
};

export const reportDemandDetail = async (req: Request, res: Response) => {
    try {
        info.info(`reportDemandDetail initialized`);
        info.info(`reportDemandDetail req.query ${JSON.stringify(req.query)}`);
        info.info(`reportDemandDetail req.body ${JSON.stringify(req.body)}`);
        const { orgId } = req.query;
        const { procedureId, date, monthAndYear, dateRange } = req.body;
        let page = parseInt(req.query.page as string, 10) || 1;
        const pageSize = parseInt(req.query.pageSize as string, 10) || 10;
        let skip = (page - 1) * pageSize;

        const sortField = req.query.sortField
            ? req.query.sortField.toString()
            : "orderedDate";

        const sortOrder = req.query.sortOrder === "desc" ? -1 : 1;

        if (!orgId || orgId === "") {
            error.error(`reportDemandDetail error: orgId missing`)
            return res
                .status(404)
                .json(generateResponse("Organisation Id is missing", 404, "failure"));
        }

        const dateRegex = /^\d{4}-\d{2}-\d{2}$/;

        const validateDate = (
            res: Response<any, Record<string, any>>,
            date: string,
            errorMessage: string
        ) => {
            if (!dateRegex.test(date)) {
                error.error(`reportDemandDetail orgId:${orgId} validateDate error:${errorMessage}`);
                return res
                    .status(400)
                    .json(generateResponse(errorMessage, 400, "failure"));
            }
            return true;
        };

        const validateNumeric = (
            res: Response<any, Record<string, any>>,
            date: string,
            errorMessage: string,
            length: number
        ) => {
            const numericRegex = new RegExp(`^\\d{${length}}$`);
            if (!numericRegex.test(date)) {
                error.error(`reportDemandDetail orgId:${orgId} validateNumeric error:${errorMessage}`);
                return res
                    .status(400)
                    .json(generateResponse(errorMessage, 400, "failure"));
            }
            return true;
        };
        const queryCondition: any = [
            { $eq: ["$orgId", orgId] },
            { $eq: ["$isReceived", true] },
            { $eq: ["$isDeleted", false] },
            {
                $or: [
                    { $eq: ["$procedureId", procedureId] },
                    { $eq: [{ $ifNull: ["$procedureId", ""] }, procedureId] },
                    { $ne: [{ $size: "$groupProducts" }, 0] },
                    {
                        $gt: [
                            {
                                $size: {
                                    $filter: {
                                        input: "$groupProducts",
                                        as: "groupProduct",
                                        cond: { $eq: ["$$groupProduct.procedureId", procedureId] }
                                    }
                                }
                            },
                            0
                        ]
                    }
                ]
            }

        ];

        if (date) {
            if (validateDate(res, date, "Invalid date value")) {
                queryCondition.push({ $eq: ["$orderedDate", date] });
            }
        } else if (monthAndYear) {
            const { month, year } = monthAndYear;
            if (
                validateNumeric(res, month, "Invalid Month value", 2) &&
                validateNumeric(res, year, "Invalid Year value", 4)
            ) {
                queryCondition.push(
                    {
                        $eq: [{ $year: { $toDate: "$orderedDate" } }, parseInt(year)],
                    },
                    {
                        $eq: [{ $month: { $toDate: "$orderedDate" } }, parseInt(month)],
                    }
                );
            }
        } else if (dateRange) {
            const { fromDate, toDate } = dateRange;
            if (
                validateDate(res, fromDate, "Invalid From date value") &&
                validateDate(res, toDate, "Invalid To date value")
            ) {
                queryCondition.push(
                    {
                        $gte: ["$orderedDate", fromDate],
                    },
                    {
                        $lte: ["$orderedDate", toDate],
                    }
                );
            }
        } else {
            return res
                .status(404)
                .json(generateResponse("Date value is missing", 404, "failure"));
        }

        info.info(
            `reportDemandDetail queryCondition data: ${JSON.stringify(
                queryCondition
            )}`
        );

        const productDemandResult = await collection
            .aggregate([
                {
                    $match: {
                        $expr: {
                            $and: queryCondition,
                        },
                    },
                },
                {
                    $project: {
                        name: 1,
                        divId: 1,
                        divName: 1,
                        qty: {
                            $cond: {
                                if: { $eq: ['$procedureId', procedureId] },
                                then: '$qty',
                                else: {
                                    $cond: {
                                        if: {
                                            $gt: [
                                                {
                                                    $size: {
                                                        $filter: {
                                                            input: '$groupProducts',
                                                            as: 'groupProduct',
                                                            cond: { $eq: ['$$groupProduct.procedureId', procedureId] }
                                                        }
                                                    }
                                                },
                                                0
                                            ]
                                        },
                                        then: {
                                            $arrayElemAt: [
                                                {
                                                    $map: {
                                                        input: {
                                                            $filter: {
                                                                input: '$groupProducts',
                                                                as: 'groupProduct',
                                                                cond: { $eq: ['$$groupProduct.procedureId', procedureId] }
                                                            }
                                                        },
                                                        as: 'groupProduct',
                                                        in: '$$groupProduct.qty'
                                                    }
                                                },
                                                0
                                            ]
                                        },
                                        else: null
                                    }
                                }
                            }
                        },
                        unit: {
                            $cond: {
                                if: { $eq: ['$procedureId', procedureId] },
                                then: '$unit',
                                else: {
                                    $cond: {
                                        if: {
                                            $gt: [
                                                {
                                                    $size: {
                                                        $filter: {
                                                            input: '$groupProducts',
                                                            as: 'groupProduct',
                                                            cond: { $eq: ['$$groupProduct.procedureId', procedureId] }
                                                        }
                                                    }
                                                },
                                                0
                                            ]
                                        },
                                        then: {
                                            $arrayElemAt: [
                                                {
                                                    $map: {
                                                        input: {
                                                            $filter: {
                                                                input: '$groupProducts',
                                                                as: 'groupProduct',
                                                                cond: { $eq: ['$$groupProduct.procedureId', procedureId] }
                                                            }
                                                        },
                                                        as: 'groupProduct',
                                                        in: '$$groupProduct.unit'
                                                    }
                                                },
                                                0
                                            ]
                                        },
                                        else: null
                                    }
                                }
                            }
                        },
                    }
                }

                ,
                {
                    $group: {
                        _id: null,
                        totalCount: { $sum: 1 },
                        totalQuantity: { $sum: '$qty' },
                        data: {
                            $push: {
                                name: '$name',
                                divId: '$divId',
                                divName: '$divName',
                                qty: '$qty',
                                unit: '$unit'
                            }
                        }
                    }
                },
                {
                    $project: {
                        _id: 0,
                        totalCount: 1,
                        totalQuantity: 1,
                        data: {
                            $slice: ['$data', skip, pageSize]
                        }
                    }
                }
            ])
            .toArray();




        const resultData = productDemandResult[0].data;
        const totalCount = productDemandResult[0]?.totalCount || 0;
        const totalQuantity = productDemandResult[0]?.totalQuantity || 0;

        const prodIdDetails = [{ procedureId, qty: totalQuantity }];

        const prodPriceApiEndpoint = `http://${baseURL}:${productServicePort}/api/product/proc/price`;

        const axiosprodPriceResponse = await axios.post(prodPriceApiEndpoint, {
            prodIdDetails,
        });

        const productPrice = axiosprodPriceResponse.data.data || [];

        let totalPrice = 0;
        await productPrice.forEach((prdPrice: { newPrice: any }) => {
            const price = prdPrice.newPrice;

            totalPrice += parseFloat(price);
        });
        info.info(`reportDemandDetail totalPrice:${totalPrice}`)

        const result = {
            totalCount,
            totalQuantity,
            totalPrice: Math.round(totalPrice * 10) / 10,
            list: resultData,
        };

        const response = generateResponse(
            "Report demand list fetched",
            200,
            "success",
            result
        );
        res.status(200).json(response);
    } catch (err: any) {
        error.error(`reportDemandDetail error message : ${err.message}`);
        res
            .status(500)
            .json(generateResponse("Internal server error", 500, "failed"));
    }
};

export const receivedDemandList = async (req: Request, res: Response) => {
    const { orgId } = req.query;

    info.info(`receivedDemandList req.query: ${JSON.stringify(req.query)}`);
    info.info(`receivedDemandList intiated for orgId:${orgId}`);
    try {
        const filter: any = {
            isDeleted: false,
            isReceived: true,
            orgId: { $regex: orgId, $options: 'i' }
        };

        const project = {
            name: 1,
            qty: 1,
            procedureId: 1,
            groupProducts: 1
        };

        const list = await collection.find(filter).project(project).toArray();
        const result: any = [];
        list.forEach((item: any) => {
            if (item.groupProducts && item.groupProducts.length > 0) {
                item.groupProducts.forEach((product: any) => {
                    const matchedProduct = result.find((p: any) => p.procedureId === product.procedureId);
                    if (matchedProduct) {
                        matchedProduct.qty += product.qty;
                    } else {
                        result.push(product);
                    }
                });
            } else {
                const matchedProduct = result.find((p: any) => p.procedureId === item.procedureId);
                if (matchedProduct) {
                    matchedProduct.qty += item.qty;
                } else {
                    result.push(item);
                }
            }
        });

        const orderData = await receivedOrderList(orgId);

        orderData.forEach((orderItem: any) => {
            const matchedResultItem = result.find((item: any) => item.procedureId === orderItem.procedureId);
            if (matchedResultItem) {
                matchedResultItem.qty += orderItem.qty;
            } else {
                result.push(orderItem);
            }
        });
        let prodIdDetails = result.map(
            (product: any) => {
                return { procedureId: product.procedureId, qty: product.qty };
            }
        );

        const prodPriceApiEndpoint = `http://${baseURL}:${productServicePort}/api/product/proc/price`;

        const axiosprodPriceResponse = await axios.post(prodPriceApiEndpoint, {
            prodIdDetails,
        });

        const productPrices = axiosprodPriceResponse.data.data || [];
        await productPrices.map((productPrice: any) => {
            const matchedProcedure = result.find((procedure: any) => procedure.procedureId === productPrice.procedureId)
            if (matchedProcedure) {
                matchedProcedure.price = productPrice.newPrice;
            }
        })

        info.info(`receivedDemandList data fetched`)
        res.status(200).json(generateResponse(`Data fetched..`, 200, `success`, result));
    } catch (err: any) {
        error.error(`receivedDemandList error:${err.message}`)
        res.status(500).json(generateResponse(`Internal server error`, 500, `failed`));
    }
}



export async function productDemandHistory(req: Request, res: Response) {
    const procedureId = req.query.id;
    if (!procedureId) {
        return res.status(400).json({ error: 'ProcedureId is required.' });
    }
    info.info(`productDemandHistory initiated`);
    info.info(`productDemandHistory req.query: ${JSON.stringify(req.query)}`);
    let { fromDate, toDate, date, month } = req.query

    if (date) {
        fromDate = date
        toDate = date
    }
    
    if (month) {
        const { firstDayOfMonth, lastDayOfMonth } = monthCal(month as string)
        fromDate = firstDayOfMonth,
            toDate = lastDayOfMonth
    }
    try {
        const result = await collection.find({
            $or: [
                {
                    procedureId, isApproved: true, isDeleted: false,
                    orderedDate: {
                        $gte: fromDate,
                        $lte: toDate
                    }
                },
                {
                    groupProducts: {
                        $elemMatch: { procedureId, isApproved: true, }

                    },
                    isDeleted: false,
                    orderedDate: {
                        $gte: fromDate,
                        $lte: toDate
                    }
                }
            ]
        }).toArray();

        const formattedData = result.map((item: any) => {
            if (item.groupProducts && item.groupProducts.length > 0) {
                const matchedProduct = item.groupProducts.find((product: any) => product.procedureId === procedureId);
                if (matchedProduct) {
                    return {
                        orderedDate: matchedProduct.orderedDate || item.orderedDate,
                        divId: matchedProduct.divId || item.divId,
                        divName: matchedProduct.divName || item.divName,
                        orgId: item.orgId,
                        name: matchedProduct.name,
                        qty: matchedProduct.qty,
                        unit: matchedProduct.unit,
                    };
                }
            }
            return {
                orderedDate: item.orderedDate,
                divId: item.divId,
                divName: item.divName,
                orgId: item.orgId,
                name: item.name,
                qty: item.qty,
                unit: item.unit,
            };
        });

        interface AggregatedDataType {
            [key: string]: {
                orderedDate: string;
                divId: string;
                divName: string;
                orgId: string;
                name: string;
                qty: number;
                unit: string;
            };
        }

        const aggregatedData: AggregatedDataType = {};
        formattedData.forEach((item: any) => {
            const key = `${item.orderedDate}-${item.divId}`;
            if (aggregatedData[key]) {
                aggregatedData[key].qty += item.qty;
            } else {
                aggregatedData[key] = { ...item };
            }
        });

        let totalQty = 0;
        for (const key in aggregatedData) {
          if (Object.prototype.hasOwnProperty.call(aggregatedData, key)) {
            totalQty += aggregatedData[key].qty;
          }
        }
        res.status(200).json(generateResponse(`Data fetched.`, 200, 'success',{ products: Object.values(aggregatedData), totalQty }));
        info.info(`productDemandHistory data fetched`)
         } catch (err:any) {
        error.error(`productDemandHistory error:${err.message}`)
        res.status(500).json(generateResponse(`Internal server error`, 500, 'failed'));
        
    }
}

