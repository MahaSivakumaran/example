import { Request, Response } from "express";
import { info, error } from "../config/loggerConfig";
import { approvedProduct } from "../model/approvedProductModel";
import { generateResponse } from "../utils/responseGenerate";
import { createApprovedProductId } from "../utils/idGenerate";
import axios from "axios";
import { supplyOrder } from "./orderController";
import { supplyProduction } from "./productionDemandController";

let collection: any;
const baseURL = process.env.BASE_URL;
const productServicePort = process.env.PRODUCT_SERVICE_PORT;

export const approvedProductInstance = async () => {
  collection = await approvedProduct();
}

export async function createApprovedProduct( req: Request, res: Response) {

  info.info(`createApprovedProduct initiated`);
  info.info(`createApprovedProduct queryParams: ${JSON.stringify(req.query)}`);
  info.info(`createApprovedProduct req.body: ${JSON.stringify(req.body)}`);
  let { orgId } = req.query;

  if(!orgId)
  {
    error.error(`createApprovedProduct error: orgId missing`);
    return res.status(400).send(generateResponse("Company id missing", 400, "failed"));
  }

    try
    {
        let { procedureId, name, qty, unit, rawMaterials, processingList, date, shift, oldProcedureId} = req.body;
        if(!procedureId || !name || qty < 1 || !unit || !rawMaterials || !processingList || !date || !shift)
        {
          error.error(`createApprovedProduct orgId:${orgId} error: Invalid arguments`);
          return res.status(400).send(generateResponse("Invalid arguments", 400, "failed"));
        }

        const orderSupplyResponse = await supplyOrder(procedureId, date, orgId, shift, oldProcedureId);
        if(!orderSupplyResponse)
        {
          error.error(`createApprovedProduct OrderSupplyResponse error`);
          return res.status(500).json(generateResponse("Internal server error", 500, "failed"));
        }

        const productionSupplyResponse = await supplyProduction(procedureId, date, orgId, shift, oldProcedureId);
        if(!productionSupplyResponse)
        {
          error.error(`createApprovedProduct productionSupplyResponse error`);
          return res.status(500).json(generateResponse("Internal server error", 500, "failed"));
        }

        let createdData = {
          _id: await createApprovedProductId(),
          orgId,
          procedureId,
          name,
          qty,
          updatedQty: 0,
          date,
          unit,
          rawMaterials,
          processingList,
          isSupplied: false,
          createdAt : new Date(),
          updatedAt: new Date()
        };
        info.info(`createApprovedProduct orgId:${orgId} createdData:${JSON.stringify(createdData)}`);
        await collection.insertOne(createdData);

        info.info(`createApprovedProduct orgId:${orgId} data inserted successfully`);
        const resp = generateResponse('Data inserted successfully',200,"success");
        res.status(200).json(resp);
    }
    catch(err: any)
    {
      error.error(`createApprovedProduct orgId:${orgId} error:${err.message}`);
      const resp = generateResponse('Internal Server Error...',500,"failed");
      res.status(500).json(resp);
    }
}

export async function approvedProductList (req: Request, res: Response) {
  info.info(`approvedProductList initiated`);
  info.info(`approvedProductList queryParams: ${JSON.stringify(req.query)}`)
  const {orgId, date} = req.query;
  if(!orgId || !date)
  {
    error.error(`approvedProductList error: Invalid arguments`);
    return res.status(400).send(generateResponse("Invalid arguments", 400, "failed"));
  }
  try
  {
    const productData = await collection.find({orgId, date}, {projection: {_id: 1, procedureId: 1, qty: 1, unit: 1}}).toArray();
    if(productData.length > 0)
    {
      info.info(`approvedProductList orgId:${orgId} fetched`);
      const resp = generateResponse("Data fetched...", 200, "Success", productData);
      res.status(200).json(resp);
    }
    else{
      error.error(`approvedProductList orgId:${orgId} error: no data found`);
      return res.status(404).send(generateResponse("No data found", 404, "failed"));
    }
    
  }
  catch(err: any)
  {
    error.error(`approvedProductList orgId:${orgId} error:${err.message}`);
    const resp = generateResponse('Internal Server Error...',500,"failed");
    res.status(500).json(resp);
  }
}

export async function approvedProductDetail (req: Request, res: Response) {
  const {id} = req.params;
  info.info(`approvedProductDetail initiated`);
  info.info(`approvedProductDetail req.params:${JSON.stringify(req.params)} `);
  const {orgId} =  req.query;
  if(!orgId)
  {
    error.error(`approvedProductDetail id:${id} error: orgId missing`);
    return res.status(400).send(generateResponse("Company id missing", 404, "failed"));
  }
  try {
    const productData = await collection.find({_id: id, orgId} , {projection: {
      _id: 1, 
      procedureId: 1,
      qty: 1,
      rawMaterials: 1
    }}).toArray();
    if(productData.length > 0)
    {
      info.info(`approvedProductDetail id:${id} data fetched`);
      res.status(200).json(generateResponse("Data fetched..", 200, "Success", productData));
    }
    else{
      error.error(`approvedProductDetail id:${id} error: no data found`);
      return res.status(404).send(generateResponse("No data found", 404, "failed"));
    }
  }
  catch(err: any)
  {
    error.error(`approvedProductDetail id:${id} error:${err.message}`);
    const resp = generateResponse('Internal Server Error...',500,"failed");
    res.status(500).json(resp);
  }
}

export async function productSupplied (req: Request, res: Response ) {
  const {id} = req.params;
  info.info(`productSupplied initiated id:${id}`);
  info.info(`productSupplied id:${id} req.query: ${JSON.stringify(req.query)}`);
  info.info(`productSupplied id:${id} req.params: ${JSON.stringify(req.params)}`);
  info.info(`productSupplied id:${id} req.body: ${JSON.stringify(req.body)}`);
  const {orgId} = req.query;
  const {rawMaterials} = req.body;
  if(!orgId || !rawMaterials)
  {
    error.error(`productSupplied id:${id} error: Invalid arguments`);
    return res.status(400).send(generateResponse("Invalid arguments", 400, "failed"));
  }
  try{
    const approvedData = await collection.findOne({_id: id, orgId, isSupplied: false});
    if(!approvedData)
    {
      error.error(`productSupplied id:${id} error: no data found`);
      return res.status(404).send(generateResponse("Order not found", 404, "failed"));
    }
    
    const productApiEndpoint = `http://${baseURL}:${productServicePort}/api/productServices/removeItemQty?orgId=${orgId}`;
    await axios.put(productApiEndpoint, {ids:rawMaterials} ).then(() => {
      info.info(`productSupplied id:${id} item removeQty(S-S) success`);
    }).catch((err: any) => {
      error.error(` productSupplied id:${id} item removeQty(S-S) error:${err.message}`);
    });
    
    const udpatedData = { isSupplied: true, rawMaterials, updatedAt: new Date()};
    info.info(`productSupplied id:${id} updatedData:${JSON.stringify(udpatedData)}`);

    await collection.findOneAndUpdate({_id: id, orgId},{
      $set: udpatedData
    },
    {
      new: true
    }
    );
    info.info(`productSupplied id:${id} updated successfully`);
    const resp = generateResponse('Product supplied successfully',200,"success");
    res.status(200).json(resp);
  }
  catch(err: any)
  {
    error.error(`productSupplied id:${id} error:${err.message}`);
    const resp = generateResponse('Internal Server Error...',500,"failed");
    res.status(500).json(resp); 
  }
}

export async function approvedProductHistory (req: Request, res: Response) {
  info.info(`approvedProductHistory initiated`);
  info.info(`approvedProductHistory req.query: ${JSON.stringify(req.query)}`)
  const {date, orgId} = req.query;
  if(!orgId){
    error.error(`approvedProductHistory error: orgId missing`)
    return res.status(400).json(generateResponse(`Company id is missing`,400,"failed"))
  }
  if(!date)
  {
    error.error(`approvedProductHistory orgId:${orgId} error: date missing`);
    return res.status(400).send(generateResponse("Date is missing", 400, "failed"));
  }
  try{

    const pipeline = [
      {
        $match: {
          date: date,
          orgId: orgId
        }
      },
      {
        $unwind: "$rawMaterials"
      },
      {
        $group: {
          _id: "$rawMaterials.itemId",
          totalQty: { $sum: "$rawMaterials.qty" },
          name: { $first: "$rawMaterials.name" },
          unit: { $first: "$rawMaterials.unit" }
        }
      },
      {
        $project: {
          itemId: "$_id",
          name: 1,
          totalQty: 1,
          unit: 1
        }
      }
    ];
    info.info(`approveProductHistory orgId:${orgId} pipeLine:${JSON.stringify(pipeline)}`);
    const productList = await collection.aggregate(pipeline).toArray();
    info.info(`approvedProductHistory orgId:${orgId} data fetched`);
    res.status(200).json(generateResponse("Data fetched...", 200, "Success", productList));
   }
   catch(err: any)
  {
    error.error(`approveProductHistory orgId:${orgId} error:${err.message}`);
    const resp = generateResponse('Internal Server Error...',500,"failed");
    res.status(500).json(resp); 
  }
}