import { Request, Response } from "express";
import { info, error } from "../config/loggerConfig";
import { generateResponse } from "../utils/responseGenerate";
import { storeDemand } from "../model/storeDemandModel";
import { isWithiInCurrentDay } from "../utils/timeCheckingForApproval";
import { createStoreDemandId } from "../utils/idGenerate";
import moment from "moment";
import axios from "axios";
import { itemPriceDetail } from "./marketOrderController";

const currentDate: moment.Moment = moment();

const baseURL = process.env.BASE_URL;
const productServicePort = process.env.PRODUCT_SERVICE_PORT;
let collection: any;
export const storeDemandInstance = async () => {
    collection = await storeDemand();
}

export async function createStoreDemand(req: Request, res: Response,) {

    info.info(`createStoreDemand initiated`);
    info.info(`createStoreDemand reqBody:${JSON.stringify(req.body)}`);

    try {
        const { orgId, itemId, section, orderedQuantity, unit, divId, itemName, divisionName } = req.body

        const date: string = currentDate.format('YYYY-MM-DD');
        const insertedData={
          _id: await createStoreDemandId(),
          orgId,
          isSentToPickupCounter: false,
          isSentFromPickupCounter: false,
          isReceived: false,
          orderedDate: date,
          itemId,
          section,
          itemName,
          orderedQuantity,
          unit,
          receivedQuantity : 0,
          sentQuantity : 0,
          divId,
          divisionName,
          isDeleted: false,
          createdAt: new Date(),
          updatedAt: new Date()

      }
        await collection.insertOne(insertedData);
        const response = generateResponse('createStoreDemand created successfully', 200, 'success')
        info.info(` createStoreDemand created successfully insertedData: ${JSON.stringify(insertedData)}`);
        res.status(200).json(response);

    } catch (err: any) {
        error.error(`createStoreDemand errorMessage : ${err.message}`)
        res.status(500).json({ success: false, error: 'Internal Server Error' });
    }
};



export async function editStoreDemand(req: Request, res: Response) {
    info.info(`editStoreDemand initiated`);
    info.info(`editStoreDemand reqParams:${JSON.stringify(req.params)}`);
    info.info(`editStoreDemand req.body:${JSON.stringify(req.body)}`);

    const { id } = req.params;

    const orderedDate: string = currentDate.format('YYYY-MM-DD');
    const { itemId, section, orderedQuantity, unit, divId, itemName, isReceived } = req.body;
    const updatedData = {
        orderedDate, itemId, section, orderedQuantity, unit, divId, itemName, isReceived,updatedAt: new Date()
    };
    
    try {
        const currentDocument = await collection.findOne({ _id: id });

        if (!currentDocument) {
          error.error(`editStoreDemand error: Data not found`)
            return res.status(404).json(generateResponse("Document not found", 404, "failure"));
        }

        if (!currentDocument.isSentToPickupCounter) {
          error.error(`editStoreDemand error: isSentToPickupCounter is false`)
            return res.status(400).json(generateResponse("Edit not allowed: isSentToPickupCounter is false", 400, "failure"));
        }

        if (!isWithiInCurrentDay(currentDocument.createdAt)) {
          error.error(`editStoreDemand error: Document created after 11:59 PM`)
            return res.status(400).json(generateResponse("Edit not allowed: Document created after 11:59 PM", 400, "failure"));
        }

        await collection.findOneAndUpdate(
            { _id: id, isSentToPickupCounter: true },
            { $set: updatedData }
        );

        info.info(`editStoreDemand work completed for id : ${id} updatedData:${JSON.stringify(updatedData)} `);
        const response = generateResponse('Item updated successfully', 200, 'success');
        return res.status(200).json(response);

    } catch (error: any) {
        error.error(`editStoreDemand errorMessage:${error.message}`);
        return res.status(500).json(generateResponse(`Internal server error`, 500,`failed`));
    }
}

export async function deletetStoreDemand(req: Request, res: Response) {
    info.info(`deletetStoreDemand initiated`);
    info.info(`deletetStoreDemand reqParams:${JSON.stringify(req.params)}`);

    const { id } = req.params;

    const updatedData = {
        isDeleted: true,
        updatedAt: new Date()
    };
    try {
        await collection.findOneAndUpdate({ _id: id }, {
            $set: updatedData
        },
            {
                new: true
            })
        info.info(`deletetStoreDemand work completed for id : ${id}`);
        const response = generateResponse('Document deleted successfully', 200, 'success')
        res.status(200).json(response);

    } catch (err: any) {
        error.error(`editOrgAdmin errorMessage:${err.message}`);
        res.status(500).json({ success: false, error: 'Internal Server Error' });
    }
}

export async function allStoreDemands(req: Request, res: Response) {

    info.info(`allStoreDemands initiated`);
    info.info(`allStoreDemands req.query:${JSON.stringify(req.query)}`);
    const {date} = req.query;
    const {divId} = req.params ;   
    const projection = {
        orgId:1,
        divId:1,
        divisionName:1,
        itemName:1,
        orderedQuantity:1,
        unit:1,
        orderedDate:1,
        section:1
    }

    try {
        const data = await collection.find({orderedDate : date , divId, isDeleted: false}).project(projection).toArray()
        res.status(200).json(generateResponse(`Date fetched..`,200,`success`,data))
    } catch (err: any) {
        error.error(`allStoreDemands errorMessage:${err.message}`);
        res.status(500).json({ success: false, error: 'Internal Server Error' });
    }
}

export async function searchByDate(req: Request, res: Response) {

    info.info(`allStoreDemands initiated`);
    info.info(`allStoreDemands req.query:${JSON.stringify(req.query)}`);
    const { startDateStr, endDateStr } = req.query
    const projection = {
        _id: 1,
        isDeleted: 0,
        createdAt: 0,
        updatedAt: 0,
        divId: 0,
        itemId: 0,
        orgId: 0,
        isSentToPickupCounter: 0,
        isSentFromPickupCounter: 0
    }
    try {
        const startDate = new Date(startDateStr as string).toISOString();
        const endDate = new Date(endDateStr as string).toISOString();
        const result = await collection.find({
            orderedDate: {
                $gte: startDate,
                $lte: endDate
            }
        }).project(projection).toArray();
        res.status(200).json(result);
        info.info(`searchByDate completed`)
    } catch (err) {
        console.error(`Error fetching store demands: ${err}`);
        res.status(500).json({ error: 'Internal Server Error' });
    }

}


// store user APIs

export const branchList = async (req: Request, res: Response) => {

    try {
        info.info(`branchList initiated`);
        info.info(`branchList req.params: ${JSON.stringify(req.params)}`);

        const { id } = req.params
        const projection = {
            _id: 0,
            orgId: 1,
            divId: 1,
            divisionName: 1,
        }
        const data = await collection.find({ orgId: id, isDeleted: false }).project(projection).toArray();
        res.status(200).json(generateResponse(`Documents fetched..`, 200, "Success", data))
        info.info(`branchList completed`)
    } catch (err: any) {
        res.status(200).json(generateResponse(`Internal server error`, 500, "failed"))
        error.error(`branchList error : ${err.message}`)
    }
}

export const storeDemandSupplyList = async (req: Request, res: Response) => {
    try {
        info.info(`storeDemandSupplyList initiated`);
        info.info(`storeDemandSupplyList req.params: ${JSON.stringify(req.params)}`);

        const { id } = req.params
        const projection = {
            _id: 1,
            itemName: 1,
            orderedQuantity: 1,
            unit: 1
        }
        const data = await collection.find({ divId: id, isDeleted: false, isSentToPickupCounter: false }).project(projection).toArray();
        res.status(200).json(generateResponse(`Documents fetched..`, 200, "Success", data))
        info.info(`storeDemandSupplyList completed`)
    } catch (err: any) {
        res.status(200).json(generateResponse(`Internal server error`, 500, "failed"))
        error.error(`storeDemandSupplyList error : ${err.message}`)
    }
}

export const storeDemandSupplyEdit = async (req: Request, res: Response) => {
    try {
        info.info(`storeDemandSupplyEdit initiated`);
        info.info(`storeDemandSupplyEdit req.params: ${JSON.stringify(req.params)}`);
        info.info(`storeDemandSupplyEdit req.body: ${JSON.stringify(req.body)}`);

        const { id } = req.params

        const existingData = await collection.findOne({ _id: id });
        if (existingData.isDeleted || existingData.isSentToPickupCounter) {
            return res.status(400).json(generateResponse(`Item cannot be edited. Already sent to pickup counter.`, 400, "Failed"));
        }
        await collection.findOneAndUpdate(
            { _id: id, isDeleted: false, isSentToPickupCounter: false },
            { $set: { sentQuantity: req.body.sentQty } }
        );
        res.status(200).json(generateResponse(`Item edited..`, 200, "Success"))
        info.info(`storeDemandSupplyEdit completed`)
    } catch (err: any) {
        res.status(200).json(generateResponse(`Internal server error`, 500, "failed"))
        error.error(`storeDemandSupplyEdit error : ${err.message}`)
    }
}

export const supplyTheDemands = async (req: Request, res: Response) => {
    try {
        info.info(`storeDemandSupply initiated`);
        info.info(`storeDemandSupplyEdit req.body: ${JSON.stringify(req.body)}`);

        const {orgId} = req.query;
        const { ids } = req.body;

        if (!ids || !Array.isArray(ids)) {
          error.error(`storeDemandSupply error: ids missing `)
            return res.status(400).json(generateResponse(`Invalid or missing IDs.`, 400, "Failed"));
        }
        const updateQuery = ids.map((item:any) => ({
            updateOne: {
              filter: { itemId: item.itemId },
              update: { $set: { sentQuantity: item.qty, isSentToPickupCounter: true } }
            }
          }));

        await collection.bulkWrite(updateQuery);

        const productApiEndpoint = `http://${baseURL}:${productServicePort}/api/productServices/removeItemQty?orgId=${orgId}`;
        const response = await axios.put(productApiEndpoint, {ids} ).then(() => {
        }).catch((err: any) => {
        error.error(`supplier verification error${err.message}`);
        });
        info.info(`supplyTheDemands completed`)
        res.status(200).json(generateResponse(`Items supplied..`, 200, "Success"))
    } catch (err: any) {
        res.status(200).json(generateResponse(`Internal server error`, 500, "failed"))
        error.error(`storeDemandSupply error : ${err.message}`)
    }
}


export const editAfterSupply = async (req: Request, res: Response) => {
    try {
        info.info(`editAfterSupply initiated`);
        info.info(`editAfterSupply req.body: ${JSON.stringify(req.body)}`);

        const {orgId} = req.query;
        const { id } = req.params
        const existingData = await collection.findOne({ _id: id });
        if (existingData.isDeleted || existingData.isSentFromPickupCounter) {
            error.error(`edtAfterSupply error: isSentFromPickupCounter is true`)
            return res.status(400).json(generateResponse(`Item cannot be edited. Already sent from pickup counter.`, 400, "Failed"));
        }
        const storeData = await collection.findOne({_id: id}, {projection:{isSentToPickupCounter: 1, isDeleted: 1}});
        if(storeData){
            res.status(400).json(generateResponse("Edit not allowed for this order...", 400, "Failed"));
        }
        await collection.findOneAndUpdate(
            { _id: id },
            { $set: { sentQuantity: req.body.qty } }
        );
        const productApiEndpoint = `http://${baseURL}:${productServicePort}/api/productServices/removeOneItemQty?oldQty=${existingData.orderedQty}&newQty=${req.body.qty}&id=${existingData.itemId}&orgId=${orgId}`;
        const response = await axios.put(productApiEndpoint).then(() => {
        }).catch((err: any) => {
            console.log(err.message)
            error.error(`supplier verification error${err.message}`);
        });
        res.status(200).json(generateResponse(`Item edited..`, 200, "Success"))
        info.info(`editAfterSupply completed`)
    } catch (err: any) {
        res.status(200).json(generateResponse(`Internal server error`, 500, "failed"))
        error.error(`editAfterSupply error : ${err.message}`)
    }
}


//pc user APIs

export const storeDemandListForPC = async (req: Request, res: Response) => {

    try {
        info.info(`storeDemandListForPC initiated`);
        info.info(`storeDemandListForPC req.params: ${JSON.stringify(req.params)}`);

        const { id } = req.params
        const projection = {
            _id: 1,
            itemName: 1,
            orderedQuantity: 1,
            sentQuantity:1,
            unit: 1,
            divisionName: 1
        }
        const data = await collection.find(
            {
                divId: id,
                isDeleted: false,
                isSentToPickupCounter: true
            }
        ).project(projection).toArray();
        res.status(200).json(generateResponse(`Documents fetched..`, 200, "Success", data))
        info.info(`storeDemandListForPC completed`)
    } catch (err: any) {
        res.status(200).json(generateResponse(`Internal server error`, 500, "failed"))
        error.error(`storeDemandListForPC error : ${err.message}`)
    }
}

export const editForPC = async (req: Request, res: Response) => {
  try {
    info.info(`editForPC initiated`);
    info.info(`editForPC req.body: ${JSON.stringify(req.body)}`);
    info.info(`editForPC req.params: ${JSON.stringify(req.params)}`);

    const { id } = req.params;
    const existingData = await collection.findOne({ _id: id });
    if (existingData.isDeleted || existingData.isSentFromPickupCounter) {
      error.error(`editForPC error: isSentFromPickupCounter is true`)
      return res
        .status(400)
        .json(
          generateResponse(
            `Item cannot be edited. Already sent from pickup counter.`,
            400,
            "Failed"
          )
        );
    }
    await collection.findOneAndUpdate(
      { _id: id, isDeleted: false, isSentFromPickupCounter: false },
      { $set: { sentQuantity: req.body.sentQty } }
    );
    res.status(200).json(generateResponse(`Item edited..`, 200, "Success"));
    info.info(`editForPC completed`)
  } catch (err: any) {
    res
      .status(200)
      .json(generateResponse(`Internal server error`, 500, "failed"));
    error.error(`editForPC error : ${err.message}`);
  }
};

export const pcVerify = async (req: Request, res: Response) => {
  try {
    info.info(`pcVerify initiated`);
    info.info(`pcVerify req.body: ${JSON.stringify(req.body)}`);

    const { ids } = req.body;

    if (!ids || !Array.isArray(ids)) {
      error.error(`pcVerify error: ids missing`)
      return res
        .status(400)
        .json(generateResponse(`Invalid or missing IDs.`, 400, "Failed"));
    }
    await collection.updateMany(
      { _id: { $in: ids }, isDeleted: false, isSentToPickupCounter: true },
      { $set: { isSentFromPickupCounter: true, updatedAt: new Date() } }
    );
    res.status(200).json(generateResponse(`Items edited..`, 200, "Success"));
    info.info(`pcVerify completed`)
  } catch (err: any) {
    res
      .status(200)
      .json(generateResponse(`Internal server error`, 500, "failed"));
    error.error(`pcVerify error : ${err.message}`);
  }
};

export const getItemsInDiv = async (req: Request, res: Response) => {
  try {
    info.info(`getItemsInDiv initiated`);
    info.info(`getItemsInDiv req.params: ${JSON.stringify(req.params)}`);

    const { id } = req.params;
    const projection = {
      itemName: 1,
      unit: 1,
      sentQuantity: 1,
      divId: 1,
      divisionName: 1,
    };
    const data = await collection
      .find({
        divId: id,
        isDeleted: false,
        isSentFromPickupCounter: true,
      })
      .project(projection)
      .toArray();
    res
      .status(200)
      .json(generateResponse(`Items edited..`, 200, "Success", data));
  } catch (err: any) {
    res
      .status(200)
      .json(generateResponse(`getItemsInDiv server error`, 500, "failed"));
    error.error(`getItemsInDiv error : ${err.message}`);
  }
};

export const editForDivPC = async (req: Request, res: Response) => {
  try {
    info.info(`editForDivPC initiated`);
    info.info(`editForDivPC req.body: ${JSON.stringify(req.body)}`);

    const { id } = req.params;
    const existingData = await collection.findOne({ _id: id });
    
    await collection.findOneAndUpdate(
      { _id: id, isDeleted: false, isReceived: false },
      { $set: { receivedQuantity: req.body.receivedQty , updatedAt: new Date()} }
    );
    res.status(200).json(generateResponse(`Item updated..`, 200, "Success"));
  } catch (err: any) {
    res
      .status(200)
      .json(generateResponse(`Internal server error`, 500, "failed"));
    error.error(`editForDivPC error : ${err.message}`);
  }
};

export const pcVerifyForDiv = async (req: Request, res: Response) => {
  try {
    info.info(`pcVerifyForDiv initiated`);
    info.info(`pcVerifyForDiv req.body: ${JSON.stringify(req.body)}`);
    const { ids } = req.body;
    const updatedData = {
      isReceived: true,
      deliveredDate: new Date(),
      updatedAt: new Date()
    };

    if (!ids || !Array.isArray(ids)) {
      error.error(`pcVerifyForDiv error: ids missing`)
      return res
        .status(400)
        .json(generateResponse(`Invalid or missing IDs.`, 400, "failed"));
    }
    await collection.updateMany(
      { _id: { $in: ids }, isDeleted: false, isSentFromPickupCounter: true },
      { $set: updatedData }
    );
    res
      .status(200)
      .json(generateResponse(`Items verified successfully..`, 200, "Success"));
      info.info(`pcVerifyForDiv completed updatedAt:${JSON.stringify(updatedData)}`)
  } catch (err: any) {
    res
      .status(200)
      .json(generateResponse(`Internal server error`, 500, "failed"));
      error.error(`pcVerify error : ${err.message}`);
  }
};

export async function deliveryReport(req: Request, res: Response) {
  try {
    info.info(`deliveryReportList initiated`);
    info.info(`deliveryReportList req.query:${req.query}`);
    info.info(`deliveryReportList req.body:${req.body}`);

    const { orgId, divId, date, monthAndYear, dateRange } = req.body;
    let page = parseInt(req.query.page as string, 10) || 1;
    const pageSize = parseInt(req.query.pageSize as string, 10) || 10;
    let skip = (page - 1) * pageSize;

    const sortField = req.query.sortField
      ? req.query.sortField.toString()
      : "orderedDate";

    const sortOrder = req.query.sortOrder === "desc" ? -1 : 1;
    if (!orgId || orgId === "") {
      error.error(`deliveryReport error: orgId missing`)
      return res
        .status(400)
        .json(generateResponse("Organisation Id is missing", 400, "failure"));
    }
    if (!divId || divId === "") {
      error.error(`deliveryReport error: divId missing`);
      return res
        .status(400)
        .json(generateResponse("Division Id is missing", 400, "failure"));
    }

    const queryCondition: any = [
      { $eq: ["$orgId", orgId] },
      { $eq: ["$divId", divId] },
      { $eq: ["$isReceived", true] },
      { $eq: ["$isDeleted", false] },
    ];

    const dateRegex = /^\d{4}-\d{2}-\d{2}$/;

    const validateDate = (
      res: Response<any, Record<string, any>>,
      date: string,
      errorMessage: string
    ) => {
      if (!dateRegex.test(date)) {
        return res
          .status(400)
          .json(generateResponse(errorMessage, 400, "failure"));
      }
      return true;
    };

    const validateNumeric = (
      res: Response<any, Record<string, any>>,
      date: string,
      errorMessage: string,
      length: number
    ) => {
      const numericRegex = new RegExp(`^\\d{${length}}$`);
      if (!numericRegex.test(date)) {
        return res
          .status(400)
          .json(generateResponse(errorMessage, 400, "failure"));
      }
      return true;
    };

    if (date) {
      if (validateDate(res, date, "Invalid date value")) {
        queryCondition.push({ $eq: ["$orderedDate", date] });
      }
    } else if (monthAndYear) {
      const { month, year } = monthAndYear;
      if (
        validateNumeric(res, month, "Invalid Month value", 2) &&
        validateNumeric(res, year, "Invalid Year value", 4)
      ) {
        queryCondition.push(
          {
            $eq: [{ $year: { $toDate: "$orderedDate" } }, parseInt(year)],
          },
          {
            $eq: [{ $month: { $toDate: "$orderedDate" } }, parseInt(month)],
          }
        );
      }
    } else if (dateRange) {
      const { fromDate, toDate } = dateRange;
      if (
        validateDate(res, fromDate, "Invalid From date value") &&
        validateDate(res, toDate, "Invalid To date value")
      ) {
        queryCondition.push(
          {
            $gte: ["$orderedDate", fromDate],
          },
          {
            $lte: ["$orderedDate", toDate],
          }
        );
      }
    } else {
      return res
        .status(404)
        .json(generateResponse("Date value is missing", 404, "failure"));
    }
    info.info(
      `deliveryReportList queryCondition data: ${JSON.stringify(
        queryCondition
      )}`
    );
    const pipeLine =[
      {
        $match: {
          $expr: {
            $and: queryCondition,
          },
        },
      },
      {
        $lookup: {
          from: "marketOrder",
          localField: "itemId", // storeDemand itemId
          foreignField: "itemId", // marketOrder itemId
          as: "productDetails",
        },
      },
      {
        $unwind: "$productDetails",
      },
      {
        $sort: { "productDetails.createdAt": -1 },
      },
      {
        $project: {
          _id: 1,
          itemName: 1,
          orderedQuantity: 1,
          unit: 1,
          orderedDate: 1,
          price: "$productDetails.price",
        },
      },
      {
        $sort: { [sortField]: sortOrder },
      },
      {
        $skip: skip,
      },
      {
        $limit: Number(pageSize),
      },
      {
        $facet: {
          data: [],
          total: [{ $count: "count" }],
        },
      },
    ]
    const deliveryReportResult = await collection
      .aggregate(pipeLine)
      .toArray();

    let deliveryData = deliveryReportResult[0]?.data || [];
    let totalCount = deliveryReportResult[0]?.total[0]?.count || 0;
    let totalPriceAmount = 0;

    deliveryData.map((item: any) => {
      totalPriceAmount += parseFloat(item.price);
    });
    let roundTotalPrice = (Math.round(totalPriceAmount * 100) / 100).toFixed(2);
    info.info(`deliveryReport roundTotalPrice: ${roundTotalPrice}`)
    const result = {
      totalCount,
      totalPriceAmount: roundTotalPrice,
      list: deliveryData,
    };
    info.info(`deliveryReportList fetched successfully`);
    const response = generateResponse(
      "Delivery report list fetched",
      200,
      "success",
      result
    );
    res.status(200).json(response);
  } catch (err: any) {
    error.error(`deliveryReportList error:${err.message}`);
    res.status(500).json(generateResponse(`Internal server error`,500,`failed`))
  }
}

export async function itemDeliveryReport(req: Request, res: Response) {
  try {
    info.info(`itemDeliveryList initiated`);
    info.info(`itemDeliveryList req.query:${req.query}`);
    info.info(`itemDeliveryList req.body:${req.body}`);

    const { orgId, divId, itemId, monthAndYear, dateRange } = req.body;
    let page = parseInt(req.query.page as string, 10) || 1;
    const pageSize = parseInt(req.query.pageSize as string, 10) || 10;
    let skip = (page - 1) * pageSize;

    const sortField = req.query.sortField
      ? req.query.sortField.toString()
      : "orderedDate";

    const sortOrder = req.query.sortOrder === "desc" ? -1 : 1;
    if (!orgId || orgId === "") {
      info.info(`itemDeliveryReport error: orgId missing`)
      return res
        .status(404)
        .json(generateResponse("Organisation Id is missing", 404, "failure"));
    }
    if (!divId || divId === "") {
      info.info(`itemDeliveryReport error: divId missing`)
      return res
        .status(404)
        .json(generateResponse("Division Id is missing", 404, "failure"));
    }
    if (!itemId || itemId === "") {
      info.info(`itemDeliveryReport error: itemId missing`)
      return res
        .status(404)
        .json(generateResponse("Item Id is missing", 404, "failure"));
    }

    const queryCondition: any = [
      { $eq: ["$orgId", orgId] },
      { $eq: ["$divId", divId] },
      { $eq: ["$itemId", itemId] },
      { $eq: ["$isReceived", true] },
      { $eq: ["$isDeleted", false] },
    ];

    const dateRegex = /^\d{4}-\d{2}-\d{2}$/;

    const validateDate = (
      res: Response<any, Record<string, any>>,
      date: string,
      errorMessage: string
    ) => {
      if (!dateRegex.test(date)) {
        return res
          .status(400)
          .json(generateResponse(errorMessage, 400, "failure"));
      }
      return true;
    };

    const validateNumeric = (
      res: Response<any, Record<string, any>>,
      date: string,
      errorMessage: string,
      length: number
    ) => {
      const numericRegex = new RegExp(`^\\d{${length}}$`);
      if (!numericRegex.test(date)) {
        return res
          .status(400)
          .json(generateResponse(errorMessage, 400, "failure"));
      }
      return true;
    };

    if (monthAndYear) {
      const { month, year } = monthAndYear;
      if (
        validateNumeric(res, month, "Invalid Month value", 2) &&
        validateNumeric(res, year, "Invalid Year value", 4)
      ) {
        queryCondition.push(
          {
            $eq: [{ $year: { $toDate: "$orderedDate" } }, parseInt(year)],
          },
          {
            $eq: [{ $month: { $toDate: "$orderedDate" } }, parseInt(month)],
          }
        );
      }
    } else if (dateRange) {
      const { fromDate, toDate } = dateRange;
      if (
        validateDate(res, fromDate, "Invalid From date value") &&
        validateDate(res, toDate, "Invalid To date value")
      ) {
        queryCondition.push(
          {
            $gte: ["$orderedDate", fromDate],
          },
          {
            $lte: ["$orderedDate", toDate],
          }
        );
      }
    } else {
      return res
        .status(404)
        .json(generateResponse("Date value is missing", 404, "failure"));
    }
    info.info(
      `itemDeliveryList queryCondition data: ${JSON.stringify(queryCondition)}`
    );

    const deliveryReportResult = await collection
      .aggregate([
        {
          $match: {
            $expr: {
              $and: queryCondition,
            },
          },
        },
        {
          $project: {
            _id: 1,
            divisionName: 1,
            orderedQuantity: 1,
            unit: 1,
            orderedDate: 1,
          },
        },
        {
          $sort: { [sortField]: sortOrder },
        },
        {
          $skip: skip,
        },
        {
          $limit: Number(pageSize),
        },
        {
          $facet: {
            data: [],
            total: [{ $count: "count" }],
          },
        },
      ])
      .toArray();

    const itemPriceDetails = await itemPriceDetail(itemId);

    if (!itemPriceDetails) {
      return res
        .status(500)
        .json(generateResponse("Something went wrong", 500, "failure"));
    }

    const price = parseFloat(itemPriceDetails.price);
    const orderedQty = parseFloat(itemPriceDetails.orderedQty);

    let deliveryData = deliveryReportResult[0]?.data || [];
    let totalCount = deliveryReportResult[0]?.total[0]?.count || 0;
    let totalPriceAmount = 0;
    deliveryData.map((item: { orderedQuantity: any }) => {
      const currentItemQty = parseFloat(item.orderedQuantity);
      const amount = (price / orderedQty) * currentItemQty;
      totalPriceAmount += amount;
    });
    info.info(`itemDeliveryReport totalPriceAmount:${totalPriceAmount}`)
    let roundTotalPrice = (Math.round(totalPriceAmount * 100) / 100).toFixed(2);
    const axiosItemQtyResponse = await axios.get(
      `http://${baseURL}:${productServicePort}/api/productServices/item/getCurrentQty/${itemId}`
    );
    info.info(
      `itemEntryReportList axiosItemQtyResponse data: ${JSON.stringify(
        axiosItemQtyResponse
      )}`
    );
    const availableQty = axiosItemQtyResponse.data.currentQty || 0;

    const result = {
      totalCount,
      totalPriceAmount: roundTotalPrice,
      availableQty,
      list: deliveryData,
    };
    info.info(`itemDeliveryList fetched successfully`);
    const response = generateResponse(
      "Delivery report list fetched",
      200,
      "success",
      result
    );
    res.status(200).json(response);
  } catch (err: any) {
    error.error(`itemDeliveryList error:${err.message}`);
    res.status(500).send({ err: err.message });
  }
}

export const itemDeliverySingleDateData = async (queryCondition: any) => {
  info.info(`itemDeliverySingleDateData initiated`)
  info.info(`itemDeliverySingleDateData queryCondition: ${JSON.stringify(queryCondition)}`)
  try {
    const pipeLine =[
      {
        $match: {
          $expr: {
            $and: queryCondition,
          },
        },
      },
      {
        $group: {
          _id: "$divId",
          orderedQuantity: { $sum: "$orderedQuantity" },
          unit: { $first: "$unit" },
          divisionName: { $first: "$divisionName" },
        },
      },
      {
        $group: {
          _id: null,
          list: {
            $push: {
              orderedQuantity: "$orderedQuantity",
              divId: "$_id",
              divisionName: "$divisionName",
              unit: "$unit",
            },
          },
        },
      },
      {
        $project: {
          _id: 0,
          list: 1,
        },
      },
    ]
    const deliveryItemResult = await collection
      .aggregate(pipeLine)
      .toArray();
    info.info(`itemDeliverySingleDateData completed pipeLine: ${JSON.stringify(pipeLine)}`)  
    return deliveryItemResult;
  } catch (err: any) {
    error.error(`itemDeliverySingleDateData error:${err.message}`);
    return false;
  }
};

export async function sectionDeliveryReport(req: Request, res: Response) {
  try {
    info.info(`sectionDeliveryReport initiated`);
    info.info(`sectionDeliveryReport req.query:${req.query}`);
    info.info(`sectionDeliveryReport req.body:${req.body}`);

    const { orgId, divId, section, date, monthAndYear, dateRange } = req.body;
    let page = parseInt(req.query.page as string, 10) || 1;
    const pageSize = parseInt(req.query.pageSize as string, 10) || 10;
    let skip = (page - 1) * pageSize;

    const sortField = req.query.sortField
      ? req.query.sortField.toString()
      : "orderedDate";

    const sortOrder = req.query.sortOrder === "desc" ? -1 : 1;
    if (!orgId || orgId === "") {
      error.error(`sectionDeliveryReport error: orgId missing`)
      return res
        .status(400)
        .json(generateResponse("Organisation Id is missing", 400, "failure"));
    }
    if (!divId || divId === "") {
      error.error(`sectionDeliveryReport error: divId missing`)
      return res
        .status(400)
        .json(generateResponse("Division Id is missing", 400, "failure"));
    }
    if (!section || section === "") {
      error.error(`sectionDeliveryReport error: sectionName missing`)
      return res
        .status(400)
        .json(generateResponse("Section Name is missing", 400, "failure"));
    }

    const queryCondition: any = [
      { $eq: ["$orgId", orgId] },
      { $eq: ["$divId", divId] },
      { $eq: ["$section", section] },
      { $eq: ["$isReceived", true] },
      { $eq: ["$isDeleted", false] },
    ];

    const dateRegex = /^\d{4}-\d{2}-\d{2}$/;

    const validateDate = (
      res: Response<any, Record<string, any>>,
      date: string,
      errorMessage: string
    ) => {
      if (!dateRegex.test(date)) {
        return res
          .status(400)
          .json(generateResponse(errorMessage, 400, "failure"));
      }
      return true;
    };

    const validateNumeric = (
      res: Response<any, Record<string, any>>,
      date: string,
      errorMessage: string,
      length: number
    ) => {
      const numericRegex = new RegExp(`^\\d{${length}}$`);
      if (!numericRegex.test(date)) {
        return res
          .status(400)
          .json(generateResponse(errorMessage, 400, "failure"));
      }
      return true;
    };
    if (date) {
      if (validateDate(res, date, "Invalid date value")) {
        queryCondition.push({ $eq: ["$orderedDate", date] });
      }
    } else if (monthAndYear) {
      const { month, year } = monthAndYear;
      if (
        validateNumeric(res, month, "Invalid Month value", 2) &&
        validateNumeric(res, year, "Invalid Year value", 4)
      ) {
        queryCondition.push(
          {
            $eq: [{ $year: { $toDate: "$orderedDate" } }, parseInt(year)],
          },
          {
            $eq: [{ $month: { $toDate: "$orderedDate" } }, parseInt(month)],
          }
        );
      }
    } else if (dateRange) {
      const { fromDate, toDate } = dateRange;
      if (
        validateDate(res, fromDate, "Invalid From date value") &&
        validateDate(res, toDate, "Invalid To date value")
      ) {
        queryCondition.push(
          {
            $gte: ["$orderedDate", fromDate],
          },
          {
            $lte: ["$orderedDate", toDate],
          }
        );
      }
    } else {
      return res
        .status(404)
        .json(generateResponse("Date value is missing", 404, "failure"));
    }
    info.info(
      `sectionDeliveryReport queryCondition data: ${JSON.stringify(
        queryCondition
      )}`
    );
    const pipeLine =[
      {
        $match: {
          $expr: {
            $and: queryCondition,
          },
        },
      },
      {
        $project: {
          _id: 0,
          itemName: 1,
          divId: 1,
          divisionName: 1,
          orderedQuantity: 1,
          unit: 1,
          orderedDate: 1,
        },
      },
      {
        $sort: { [sortField]: sortOrder },
      },
      {
        $skip: skip,
      },
      {
        $limit: Number(pageSize),
      },
      {
        $facet: {
          data: [],
          total: [{ $count: "count" }],
        },
      },
    ]
    const deliveryReportResult = await collection
      .aggregate(pipeLine)
      .toArray();

    let deliveryData = deliveryReportResult[0]?.data || [];
    let totalCount = deliveryReportResult[0]?.total[0]?.count || 0;

    const result = {
      totalCount,
      list: deliveryData,
    };
    info.info(`sectionDeliveryReport fetched pipeLine: ${JSON.stringify(pipeLine)}`);
    const response = generateResponse(
      "Section delivery report list fetched",
      200,
      "success",
      result
    );
    res.status(200).json(response);
  } catch (err: any) {
    console.log("err", err);
    error.error(`sectionDeliveryReport error:${err.message}`);
    res.status(500).send({ err: err.message });
  }
}
