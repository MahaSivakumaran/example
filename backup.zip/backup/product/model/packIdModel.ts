import { databaseConnection } from "../app/db";
import { info, error } from "../config/loggerConfig";


export async function packId(){
    
    try{
        const db = await databaseConnection();
        const collection = await db.collection('packId',{
            validator:{
                $jsonSchema:{
                    bsonType: 'string',
                    title: 'Pack ID',
                    properties:{
                        packId:{
                            bsonType: 'int'
                        }
                    }
                }
            }
        });
        return collection;
    }
    catch(err){
        error.error(`packId database connection failed error${err}`);
        throw err;
    }
}