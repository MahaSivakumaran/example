import { databaseConnection } from "../app/db";
import { info, error } from "../config/loggerConfig";


export async function sectionId(){
    
    try{
        const db = await databaseConnection();
        const collection = await db.collection('sectionId',{
            validator:{
                $jsonSchema:{
                    bsonType: 'object',
                    title: 'Section ID',
                    properties:{
                        sectionId:{
                            bsonType: 'int'
                        }
                    }
                }
            }
        });
        return collection;
    }
    catch(err){
        error.error(`sectionId database connection failed error${err}`);
        throw err;
    }
}