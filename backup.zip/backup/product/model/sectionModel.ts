import { databaseConnection } from "../app/db";
import { error } from "../config/loggerConfig";


export async function section() {

    try {
        const db = await databaseConnection();
        const collection = await db.collection('section', {
            validator: {
                $jsonSchema: {
                    bsonType: 'object',
                    title: 'Section',
                    properties: {
                        _id: {
                            bsonType: 'string'
                        },
                        orgId: {
                            bsonType: 'sting'
                        },
                        name: {
                            bsonType: 'string'
                        },
                        prodItems: {
                            bsonType: 'array',
                            items: {
                                bsonType: 'object',
                                properties:{
                                    id:{
                                        bsonType: 'string'
                                    },
                                    name:{
                                        bsonType: 'string'
                                    }

                                }
                            }
                        },

                        isDeleted: {
                            bsonType: 'bool'
                        },
                        createdAt: {
                            bsonType: 'date',
                        },
                        updatedAt: {
                            bsonType: 'date',
                        },
                    },
                    required: ['orgId', 'name']
                }
            }
        });
        return collection;
    }
    catch (err) {
        error.error(`section database connection failed error${err}`);
        throw err;
    }
}