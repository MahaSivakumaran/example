import { databaseConnection } from "../app/db";
import { error } from "../config/loggerConfig";

export async function product() {
    try {
        const db = await databaseConnection();
        const collection = db.collection('product', {
            validator: {
                $jsonSchema: {
                    bsonType: 'object',
                    title: 'Product',
                    properties: {
                        _id:{
                            bsontype : 'string'
                        },
                        orgId: {
                            bsonType: 'string'
                        },
                        name: {
                            bsonType: 'string'
                        },
                        shift: {
                            bsonType: 'array',
                            items: {
                                bsonType: 'string'
                            }
                        },
                        isSingle:{
                            bsonType: 'bool',
                        },
                        procedure: {
                            bsonType: 'array',
                            items: {
                                bsonType: 'object',
                                properties: {
                                    procedureId: {
                                        bsontype: 'string'
                                    },
                                    name: {
                                        bsonType: 'string'
                                    },
                                    qty: {
                                        bsonType: 'double'
                                    },
                                    unit: {
                                        bsonType: 'string'
                                    },
                                    price: {
                                        bsonType: 'string'
                                    },
                                    isDeleted: {
                                        bsonType: 'bool',
                                    },
                                    rawMaterial: {
                                        bsonType: 'array',
                                        items: {
                                            bsonType: 'object',
                                            properties: {
                                                id: {
                                                    bsonType: 'string'
                                                },
                                                name: {
                                                    bsonType: 'string'
                                                },
                                                qty: {
                                                    bsonType: 'double'
                                                },
                                                unit: {
                                                    bsonType: 'string'
                                                }
                                            }
                                        }
                                    },
                                    processingList: {
                                        bsonType: 'array',
                                        items: {
                                            bsonType: 'object',
                                            properties: {
                                                name: {
                                                    bsonType: 'string'
                                                },
                                                qty: {
                                                    bsonType: 'double'
                                                },
                                                unit: {
                                                    bsonType: 'string'
                                                }
                                            }
                                        }
                                    },
                                    createdAt: {
                                        bsonType: 'date',
                                        default: new Date()
                                    },
                                    updatedAt: {
                                        bsonType: 'date',
                                        default: new Date()
                                    }
                                }
                            }
                        }
                    }
                }
            }
        });
        collection.createIndex({ 'procedure.procedureId': 'text' }, function(err: any, result: any) {
            if (err) {
                console.error('Error creating index:', err);
            } else {
                console.log('Index created successfully:', result);
            }
        });
        return collection;
    } catch (err: any) {
        error.error(`product database connection failed error${err}`);
        throw err;
    }
}
