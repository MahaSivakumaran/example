import { databaseConnection } from "../app/db";
import { info, error } from "../config/loggerConfig";


export async function productId(){
    
    try{
        const db = await databaseConnection();
        const collection = await db.collection('productId',{
            validator:{
                $jsonSchema:{
                    bsonType: 'object',
                    title: 'Product ID',
                    properties:{
                        productId:{
                            bsonType: 'int'
                        }
                    }
                }
            }
        });
        return collection;
    }
    catch(err){
        error.error(`productId database connection failed error${err}`);
        throw err;
    }
}