import { databaseConnection } from "../app/db";
import { info, error } from "../config/loggerConfig";


export async function itemId(){
    
    try{
        const db = await databaseConnection();
        const collection = await db.collection('itemId',{
            validator:{
                $jsonSchema:{
                    bsonType: 'string',
                    title: 'Item ID',
                    properties:{
                        itemId:{
                            bsonType: 'int'
                        }
                    }
                }
            }
        });
        return collection;
    }
    catch(err){
        error.error(`itemId database connection failed error${err}`);
        throw err;
    }
}