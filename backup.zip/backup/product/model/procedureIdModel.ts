import { databaseConnection } from "../app/db";
import { info, error } from "../config/loggerConfig";


export async function procedureId(){
    
    try{
        const db = await databaseConnection();
        const collection = await db.collection('procedureId',{
            validator:{
                $jsonSchema:{
                    bsonType: 'string',
                    title: 'Procedure ID',
                    properties:{
                        orgId: {
                            bsonType: 'string'
                        },
                        procedureId:{
                            bsonType: 'string'
                        },
                        count:{
                            bsonType: 'int'
                        }
                    }
                }
            }
        });
        return collection;
    }
    catch(err){
        error.error(`procedureId database connection failed error${err}`);
        throw err;
    }
}