import { databaseConnection } from "../app/db";
import { info, error } from "../config/loggerConfig";

export async function item() {
    
   try {
    const db  = await databaseConnection();
    const collection = await db.collection('item', {
        validator: {
            $jsonSchema:{
                bsonType: 'object',
                title: 'Godown item',
                properties:{
                    _id:{
                        bsonType: 'string'
                    },
                    name:{
                        bsonType: 'string'
                    },
                    orgId:{
                        bsonType: 'string'
                    },
                    minQty:{
                        bsonType: 'int'
                    },
                    maxQty:{
                        bsonType: 'int'
                    },
                    unit:{
                        bsonType: 'sting'
                    },
                    section:{
                        bsontype: 'array',
                        items:{
                            bsonType: 'string'
                        }
                    },
                    supplier:{
                        bsonType: 'array',
                        items:{
                            bsonType: 'string'
                        }
                    },
                    currentQty:{
                        bsonType: 'int',
                    },
                    createdAt:{
                        bsonType: 'date'
                    },
                    updatedAt:{
                        bsonType: 'date'
                    },
                    isDeleted: {
                        bsonType: 'bool'
                    }
                }
            }
        }
    });
    return collection;
}
catch(err){
    error.error(`item database connection failed error${err}`);
    throw err;
}
}