import { databaseConnection } from "../app/db";
import { error } from "../config/loggerConfig";


export async function pack(){

    try{
    const db = await databaseConnection(); 
    const collection = db.collection('pack',{
        validator:{
            $jsonSchema:{
                bsonType: 'object',
                title: 'Pack',
                properties: {
                    _id:{
                        bsonType: 'string'
                    },
                    orgId:{
                        bsonType: 'string'
                    },
                    name:{
                        bsonType: 'string'
                    },
                    price:{
                        bsonType: 'double'
                    },
                    heads:{
                        bsonType: 'int'
                    },
                    shift:{
                        bsonType: 'array',
                        items:{
                            bsonType: 'string',
                        }
                    },
                    isDeleted:{
                        bsonType: 'bool'
                    },
                    productList:{
                        bsonType: 'array',
                        items:{
                            bsonType: 'object',
                            properties:{
                                id:{
                                    bsonType: 'string'
                                },
                                name:{
                                    bsonType: 'string'
                                },
                                procedureName:{
                                    bsonType: 'string'
                                },
                                quantity:{
                                    bsonType: 'string'
                                },
                                unit:{
                                    bsontype: 'string'
                                }                                
                            }
                        }
                    },
                    createdAt:{
                        bsonType: 'date'
                    },
                    updatedAt:{
                        bsonType: 'date'
                    },
                }
            }
        }
    });
    return collection;
}
catch(err:any){
    error.error(`group database connection failed error${err.message}`);
    throw err;
}
}