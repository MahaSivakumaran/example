import { databaseConnection } from "../app/db";
import {  error } from "../config/loggerConfig";


export async function group(){
    
    try{
    const db = await databaseConnection(); 
    const collection = db.collection('group',{
        validator:{
            $jsonSchema:{
                bsonType: 'object',
                title: 'Group',
                properties: {
                    _id:{
                        bsonType: 'string'
                    },
                    orgId:{
                        bsonType: 'string'
                    },
                    name:{
                        bsonType: 'string'
                    },
                    price:{
                        bsonType: 'double'
                    },
                    shift:{
                        bsonType: 'array',
                        items:{
                            bsonType: 'string',
                        }
                    },
                    isDeleted:{
                        bsonType: 'bool'
                    },
                    productList:{
                        bsonType: 'array',
                        items:{
                            bsonType: 'object',
                            properties:{
                                productId:{
                                    bsonType: 'string'
                                },
                                name:{
                                    bsonType: 'string'
                                },
                                quantity:{
                                    bsonType: 'string'
                                },
                                unit:{
                                    bsontype: 'string'
                                }                                
                            }
                        }
                    },
                    createdAt:{
                        bsonType: 'date'
                    },
                    updatedAt:{
                        bsonType: 'date'
                    },
                }
            }
        }
    });
    return collection;
}
catch(err:any){
    error.error(`group database connection failed error${err.message}`);
    throw err;
}
}