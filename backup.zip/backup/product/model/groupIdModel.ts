import { databaseConnection } from "../app/db";
import { info, error } from "../config/loggerConfig";


export async function groupId(){
    
    try{
        const db = await databaseConnection();
        const collection = await db.collection('groupId',{
            validator:{
                $jsonSchema:{
                    bsonType: 'object',
                    title: 'Group ID',
                    properties:{
                        groupId:{
                            bsonType: 'int'
                        }
                    }
                }
            }
        });
        return collection;
    }
    catch(err){
        error.error(`groupId database connection failed error${err}`);
        throw err;
    }
}