import { sectionId } from "../model/sectionIdModel";
import { info, error } from "../config/loggerConfig";

export async function initializeSectionId(){
    try{
        info.info(`initializeSectionId initiated`);
        const collection = await sectionId();
        const sectionData = await collection.findOne();
        if(sectionData == null)
        {
            await collection.insertOne({
                sectionId: 1000
            });
            info.info(`initializeSectionId sectionId:1000 db created`);
        }
    }
    catch(err: any){
        error.error(`initializeSectionId error:${err.message}`);
    }
}

export async function createSectionId() {
    try {
        info.info(`createSectionId initiated`);
        const collection = await sectionId();
        const sectionData = await collection.find({}).toArray();
        let id = sectionData[0]._id;
        let sId = sectionData[0].sectionId + 1;
        await collection.findOneAndUpdate({ _id: id }, {
            $set: { sectionId: sId }
        },
            {
                new: true
            });
        sId = "section_" + sId;
        info.info(`createSectionId created sectionId:${sId}`);
        return sId;
    }
    catch(err: any){
        error.error(`createSectionId error:${err.message}`);
        return false;
    }
}