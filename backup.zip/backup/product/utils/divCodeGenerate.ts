import { info, error } from "../config/loggerConfig";
import { divCodeModel } from "../model/divCodeModel";


export async function createDivCode(orgId: any , code: any) {

    info.info(`createDivCode initiated`);
    info.info(`createDivCode orgId:${orgId} code:${code}`);
    try {
        let collection = await divCodeModel();
        await collection.insertOne({
            orgId: orgId,
            divCode: code,
            count: 0
        });
        info.info(`createDivcode orgId:${orgId} created successfully`);
        return
    }
    catch (err: any) {
        error.error(`createDivID orgId:${orgId} error:${err.message}`);
        return
    }
}

export async function addDivCodeCount(orgId: any) {

    info.info(`addDivCodeCount initiated orgId:${orgId}`);
    try {
        let collection = await divCodeModel();
        const divCodeRes = await collection.findOne({orgId},{
            count: 1,
            divCode: 1
        });
        const count = divCodeRes.count + 1;
        const divCode = divCodeRes.divCode;
        await collection.findOneAndUpdate({ orgId }, {
            $set: {count}
          },
            {
              new: true
            });
            info.info(`addDivCodeCount orgId:${orgId} data updated count:${count}`);
        return {count, divCode};
    }
    catch (err: any) {
        error.error(`addDivCode orgId:${orgId} error:${err.message}`);
        return
    }
}