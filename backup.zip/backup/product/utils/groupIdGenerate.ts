import { groupId } from "../model/groupIdModel";
import { info, error } from "../config/loggerConfig";

export async function initializeGroupId(){
    try{
        info.info(`initializeGroupId initiated`);
        const collection = await groupId();
        const groupData = await collection.findOne();
        if(groupData == null)
        {
            await collection.insertOne({
                groupId: 1000
            });
            info.info(`initializeGroupId groupId:1000 db created`);
        }
    }
    catch(err: any){
        error.error(`initializeGroupId error:${err.message}`);
    }
}

export async function createGroupId() {
    try {
        info.info(`createGroupId initiated`);
        const collection = await groupId();
        const groupData = await collection.find({}).toArray();
        let id = groupData[0]._id;
        let gId = groupData[0].groupId + 1;
        await collection.findOneAndUpdate({ _id: id }, {
            $set: { groupId: gId }
        },
            {
                new: true
            });
        gId = "group_" + gId;
        info.info(`createGroupId created groupId:${gId}`);
        return gId;
    }
    catch(err: any){
        error.error(`createGroupId error:${err.message}`);
        return;
    }
}