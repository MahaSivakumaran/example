import { packId } from "../model/packIdModel";
import { info, error } from "../config/loggerConfig";

export async function initializePackId(){
    try{
        info.info(`initializePackId initiated`);
        const collection = await packId();
        const packData = await collection.findOne();
        if(packData == null)
        {
            await collection.insertOne({
                packId: 1000
            });
            info.info(`initializePackId packId:1000 db created`);
        }
    }
    catch(err: any){
        error.error(`initializePackId error:${err.message}`);
    }
}

export async function createPackId() {
    try {
        info.info(`createPackId initiated`);
        const collection = await packId();
        const packData = await collection.find({}).toArray();
        let id = packData[0]._id;
        let pId = packData[0].packId + 1;
        await collection.findOneAndUpdate({ _id: id }, {
            $set: { packId: pId }
        },
            {
                new: true
            });
        pId = "pack_" + pId;
        info.info(`createPackId created packId:${pId}`);
        return pId;
    }
    catch(err: any){
        error.error(`createPackId error:${err.message}`);
        return;
    }
}