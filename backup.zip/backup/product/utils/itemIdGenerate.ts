import { itemId } from "../model/itemIdModel";
import { info, error } from "../config/loggerConfig";

export async function initializeItemId(){
    try{
        info.info(`initializeItemId initiated`);
        const collection = await itemId();
        const itemData = await collection.findOne();
        if(itemData == null)
        {
            await collection.insertOne({
                itemId: 1000
            });
            info.info(`initializeItemId itemId:1000 db created`);
        }
    }
    catch(err: any){
        error.error(`initializeItemId error:${err.message}`);
    }
}

export async function createItemId() {
    try {
        info.info(`createItemId initiated`);
        const collection = await itemId();
        const itemData = await collection.find({}).toArray();
        let id = itemData[0]._id;
        let iId = itemData[0].itemId + 1;
        await collection.findOneAndUpdate({ _id: id }, {
            $set: { itemId: iId }
        },
            {
                new: true
            });
        iId = "item_" + iId;
        info.info(`createItemId created itemId:${iId}`);
        return iId;
    }
    catch(err: any){
        error.error(`createItemId error:${err.message}`);
        return false;
    }
}