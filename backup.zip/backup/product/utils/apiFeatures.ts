export async function searchAndPaginate(collection:any, query:any, page:any, sortBy:any, sortColumn:any, pageSize:any, orgId : any) {
    
    let skip = 0;
    const searchFilter = {
        orgId,
        isDeleted: false,
        ...(query ? {
            $or: [
                { name: { $regex: query, $options: 'i' } },
                { section: { $elemMatch: { $regex: query, $options: 'i' } } },
                { price: { $regex: query, $options: 'i' } },
                { shift: { $regex: query, $options: 'i' } },
                { productList: { $regex: query, $options: 'i' } },
                {[ 'prodItems.name']: { $regex: query, $options: 'i' } },
                
            ],
        } : {}),
    };
 
    const currentPage = parseInt(page) || 1;
    const page_Size = parseInt(pageSize as string,10) || 10;
    
    skip = (currentPage - 1) * page_Size;
 
    const sortOptions:any = {};
    const sortOrder = ( sortBy === "desc" ? -1 : 1);
    if (sortColumn === 'name' || sortColumn === 'price' || sortColumn === 'shift' || sortColumn === 'productList' || sortColumn === 'type' || sortColumn === 'period' ) {
        sortOptions[sortColumn] = sortOrder;
    }
 
    sortOptions['createdAt'] = 1;
 
    const projection = {
        _id: 1,
        name:1,
        section:1,
        minQty:1,
        maxQty:1,
        unit:1,
        supplier:1,
        price:1,
        shift:1,
        productList:1,
        procedure:1,
        prodItems:1,
    };
 
    const aggregatePipeline = [
        { $match: searchFilter },
        { $sort: sortOptions },
        {
            $facet: {
                metadata: [
                    { $skip: skip },
                    { $limit: page_Size },
                    { $project: projection },
                ],
                totalCount: [
                    { $count: 'value' },
                ],
            },
        },
        { $unwind: '$totalCount' },
    ];
    const results = await collection.aggregate(aggregatePipeline).toArray();
    const list = results[0].metadata || [];
    const count = results[0].totalCount ? results[0].totalCount.value : 0;
    return {
        totalCount: count,
        list,
    };
}


export async function calculateNoOfProducts(items: any[]) {
    const productCountMap: { [productId: string]: number } = {};
    let totalCount = 0;

    items.forEach((item: any) => {
        item.productList.forEach((product: any) => {
            const productId = product.productId;
            if (!productCountMap[productId]) {
                productCountMap[productId] = 1;
                totalCount += 1;
            }
        });
    });

    return items.map((item: any) => ({
        name: item.name,
        price: item.price,
        noOfProducts: item.productList.reduce(
            (count: number, product: any) => count + (productCountMap[product.productId] || 0),
            0
        ),
    }));
}