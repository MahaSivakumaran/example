import { info, error } from "../config/loggerConfig";
import { procedureId } from "../model/procedureIdModel";
import { Request, Response } from "express";

export async function initializeProcedureId( req: Request, res: Response ){
    try{
        const {procedureCode, orgId} = req.body;
        info.info(`initializeProcedureId initiated`);
        info.info(`initializeProcedureId req.body:${JSON.stringify(req.body)}`);
        const collection = await procedureId();
        await collection.insertOne({
            orgId,
            procedureId: procedureCode,
            count: 0
        });
        info.info(`initializeProcedureId productId:${procedureCode} db created`);
        res.status(200).send({
            message: "success"
        })
    }
    catch(err: any){
        error.error(`initializeProcedureId error:${err.message}`);
        res.status(500).send({
            message: "failed"
        })
    }
}

export async function createProcedureId( id: string ) {
    try {
        info.info(`createProcedureId initiated orgId:${id}`);
        const collection = await procedureId();
        const procedureData = await collection.findOne({orgId: id});
        let pId = procedureData.procedureId;
        let count = procedureData.count + 1;
        await collection.findOneAndUpdate({ orgId: id }, {
            $set: { count }
        },
            {
                new: true
            });
        pId = pId + count;
        info.info(`createProcedureId created orgId:${id} procedureId:${pId} count:${count}`);
        return pId;
    }
    catch(err: any){
        error.error(`createProcedureId error:${err.message}`);
        return false;
    }
}