import { productId } from "../model/productIdModel";
import { info, error } from "../config/loggerConfig";

export async function initializeProductId(){
    try{
        info.info(`initializeProductId initiated`);
        const collection = await productId();
        const productData = await collection.findOne();
        if(productData == null)
        {
            await collection.insertOne({
                productId: 1000
            });
            info.info(`initializeProductId productId:1000 db created`);
        }
    }
    catch(err: any){
        error.error(`initializeProductId error:${err.message}`);
    }
}

export async function createProductId() {
    try {
        info.info(`createProductId initiated`);
        const collection = await productId();
        const productData = await collection.find({}).toArray();
        let id = productData[0]._id;
        let pId = productData[0].productId + 1;
        await collection.findOneAndUpdate({ _id: id }, {
            $set: { productId: pId }
        },
            {
                new: true
            });
        pId = "product_" + pId;
        info.info(`createProductId created productId:${pId}`);
        return pId;
    }
    catch(err: any){
        error.error(`createProductId error:${err.message}`);
        return false;
    }
}