module.exports = {
    apps: [
      {
        name: 'atvara-product-service',
        script: './app/app.ts',
        interpreter: './node_modules/.bin/ts-node',
      },
    ],
  };
  