import { Request, Response } from "express";
import { group } from "../model/groupModel";
import { info, error } from "../config/loggerConfig";
import { generateResponse } from "../utils/responseGenerate";
import { calculateNoOfProducts, searchAndPaginate } from "../utils/apiFeatures";
import { createGroupId } from "../utils/groupIdGenerate";

let collection: any;
export async function groupInstance() {
    collection = await group();
}

export async function createGroup(req: Request, res: Response) {
    info.info(`createGroup initiated`)
    info.info(`createGroup req.body ${JSON.stringify(req.body)}`)
    
    const { orgId,
            name,
            price,
            shift,
            productList
    } = req.body;

    const result = await collection.aggregate([
      {
        $match: {
            $and: [
              { orgId: orgId },
                { $or: [{ name: name }] },
            ]
        }
    },
      
      {
        $unionWith: {
          coll: "pack",
          pipeline: [
            { $match: {  orgId, name } },
          ]
        }
      },
      {
        $unionWith: {
          coll: "product",
          pipeline: [
            { $match: { orgId, name } },
          ]
        }
      },
      {
        $limit: 1 
      }
    ]).toArray();
  

    if (result.length > 0) {
      error.error(`createGroup error: Name already exists`)
        const response = generateResponse("Name already exists", 400, "failed");
        return res.status(400).json(response);
    }


    const id = await createGroupId();
    try {
      const insertData ={
        _id: id,
        orgId,
        name,
        price,
        shift,
        productList,
        isDeleted: false,
        createdAt: new Date(),
        updatedAt: new Date()
    }
        await collection.insertOne(insertData)
        const response = generateResponse("Group Created Successfully", 201, "success")
        res.status(201).json(response)
        info.info(`createGroup data: ${JSON.stringify(insertData)}`)

    } catch (err: any) {
        const response = generateResponse("Internal server error", 500, "failed")
        error.error(`createGroup error: ${err.message}`)
        res.status(500).json(response)
    }
}

export const editGroup = async (req: Request, res: Response) => {
    info.info(`editGroup initiated`);
    info.info(`editGroup req.body ${JSON.stringify(req.body)}`);
    info.info(`editGroup req.query:${JSON.stringify(req.query)}`);
    const {orgId} = req.query;
    if(!orgId || orgId === ""){
      error.error(`editGroup error: orgId missing`)
      return res.status(400).json(generateResponse(`orgId missing`,400,`failed`))
    };
    const id = req.params.id;
    const { name, price, shift, productList } = req.body;

    const updatedData = {
        name,
        price,
        shift,
        productList,
        updatedAt: new Date()
    }
    try {
        const result = await collection.aggregate([
            {
                $match: { _id: {$ne: id}, orgId, name }
            },
            {
                $unionWith: {
                    coll: "product",
                    pipeline: [
                        { $match: { name , orgId } },
                        
                    ]
                }
            },
            {
                $unionWith: {
                    coll: "pack",
                    pipeline: [
                        { $match: { name } , orgId},
                        
                    ]
                }
            },
            {
                $match: {
                    $or: [
                        { name: name },
                        { "productData.name": name },
                        { "packData.name": name }
                    ]
                }
            }
        ]).toArray();

        if (result.length > 0) {
            error.error(`editGroup error: Name already exists`)
            const response = generateResponse("Name already exists", 400, "failed");
            return res.status(400).json(response);
        }
        await collection.findOneAndUpdate({ _id: id }, {
            $set: updatedData
        },
            {
                new: true
            }
        )
        const response = generateResponse("Group Updated Successfully", 200, "success")
        res.status(200).json(response);
        info.info(`editGroup updatedData: ${JSON.stringify(updatedData)}`)

    } catch (err: any) {
        const response = generateResponse("Internal server error", 500, "failed")
        error.error(`editGroup error: ${err.message}`)
        res.status(500).json(response);
    }
}

export const deleteGroup = async (req: Request, res: Response) => {
    info.info(`deleteGroup initiated`)
    info.info(`deleteGroup req.params ${JSON.stringify(req.params)}`)
    const { id } = req.params;
    const {orgId} = req.query;
    if(!orgId || orgId === ""){
      error.error(`deleteGtroup error: orgId is missing`);
      return res.status(400).json(generateResponse(`orgId missing`,400,`failed`))
    }
    const updatedData = {
        isDeleted: true,
        updatedAt: new Date()
    }
    try {
        await collection.findOneAndUpdate(
          { _id: id ,orgId},
          { $set: updatedData }
        )
        const response = generateResponse("Group deleted Successfully", 200, "success")
        info.info(`deleteGroup updatedData: ${JSON.stringify(updatedData)}`)

        res.status(200).json(response);
    } catch (err: any) {
        const response = generateResponse("Internal server error", 500, "failed")
        error.error(`deleteGroup error: ${err.message}`)
        res.status(500).json(response);
    }
}

export const getGroup = async (req: Request, res: Response) => {
    info.info(`getGroup initiated`);
    info.info(`getGroup queryParams ${JSON.stringify(req.query)}`);
    const { query, page, sortBy, sortColumn, pageSize , orgId } = req.query;
  if(!orgId || orgId === ""){
    error.error(`getGroup error: orgId missing`);
    return res.status(400).json(generateResponse(`OrgId is missing`,400,`failed`))
  }
    try {
        const data = await searchAndPaginate( collection, query, page, sortColumn, sortBy, pageSize , orgId);
        const updatedData = await calculateNoOfProducts(data.list);
        const response = generateResponse("data fetched..", 200, "success", {
          ...data,
          list:updatedData});
        res.status(200).json(response);
        info.info(`getGroup completed`);
    } catch (err: any) {
        const response = generateResponse("Internal server error", 500, "failed");
        error.error(`getGroup error: ${err.message}`);
        res.status(500).json(response);
    }
};



export const grpDetails = async(req: Request, res: Response)=>{    
  info.info(`grpDetails initialized`);
  info.info(`grpDetails req.params:${JSON.stringify(req.params)} req.query:${JSON.stringify(req.query)}`);
  const {id} = req.params;
  const {orgId} = req.query;
  if(!orgId || orgId === ""){
    error.error(`grpDetails error: orgId missing`);
    return res.status(400).json(generateResponse(`orgId is missing`,400,`failed`));
  }
    try {
        const query = { 
            _id: id,
            orgId,
            isDeleted: false
         };

    const projection = {
      name: 1,
      price: 1,
      shift: 1,
      'productList.name': 1,
      'productList.quantity': 1,
      'productList.unit': 1,
    };
    const result = await collection.findOne(query, {projection});
    if(result)
    {
      if(Object.keys(result).length>0)
      {
        info.info(`grpDetails id:${id} data fetched`);
        const response  = generateResponse("Data fetched..",200,"success",result);
        return res.status(200).json(response);
      }
      else{
      error.error(`grpDetails id:${id} error: group not found`);
      return res.status(404).json(generateResponse("Group not found", 404, "failed"));
      }
    }
    else
    {
      error.error(`grpDetails id:${id} error: group not found`);
      return res.status(404).json(generateResponse("Group not found", 404, "failed"));
    }
    } catch (err: any) {
      error.error(`grpDetails id:${id} error: ${err.message}`);
      res.status(500).json(generateResponse(`Internal server error`,500,"failed"))
    }
};


export const prodAndGrpNamesForPackage = async (req: Request, res: Response) => {
    const { orgId,query } = req.query;
    info.info(`prodAndGrpNamesForPackage queryParams: ${JSON.stringify(req.query)}`)
    if(!orgId || orgId === ""){
      error.error(`prodAndGrpNamesForPackage error: orgId missing`)
    return  res.status(400).json(generateResponse(`orgId missing`,400,`failed`));
    }
    try {
      const pipeLine =  [
        {
          $match: {
            name: {
              $regex: new RegExp(query as string, 'i'),
            },
            orgId,
            isDeleted: { $ne: true },
          },
        },
        {
          $project: {
            _id: 1,
            name: 1,
            products: {
              $map: {
                input: '$productList',
                as: 'product',
                in: {
                  prodId: '$$product.productId',
                  prodName: '$$product.name',
                },
              },
            },
            type: { $literal: 'group' },
          },
        },
        {
          $unionWith: {
            coll: 'product',
            pipeline: [
              {
                $match: {
                  name: {
                    $regex: new RegExp(query as string, 'i'),
                  },
                },
              },
              {
                $project: {
                  _id: 1,
                  name: 1,
                  type: { $literal: 'product' },
                  procedure: {
                    $filter: {
                      input: '$procedure',
                      as: 'proc',
                      cond: { $ne: ['$$proc.isDeleted', true] }, 
                    },
                  },
                },
              },
              {
                $project: {
                  _id: 0,
                  name: 1,
                  type: 1,
                  product: {
                    $map: {
                      input: '$procedure',
                      as: 'proc',
                      in: {
                        prodId: '$$proc.prodId',
                        prodName: '$$proc.name',
                      },
                    },
                  },
                },
              },
            ],
          },
        },
        {
          $project: {
            _id: 1,
            name: 1,
            type: 1,
            products: {
              $map: {
                input: '$products',
                as: 'product',
                in: {
                  _id: '$$product.prodId',
                  name: '$$product.prodName',
                },
              },
            },
            procedureName: 1,
            product: 1,
          },
        },
      ]

      info.info(`prodAndGrpNamesForPackage pipeLine: ${JSON.stringify(pipeLine)}`)
      const result = await collection.aggregate(pipeLine).toArray();
      if (result.length === 0) {
        error.error(`prodAndGrpNamesForPackage error: No data found`);
        return res.status(404).json(generateResponse('No data found', 404, "failed"));
    }
      const response = generateResponse('Data fetched..', 200, "success", result);
      res.status(200).json(response);
      info.info(`prodAndGrpNamesForPackage completed`)
    } catch (err: any) {
      error.error(`prodAndGrpNamesForPackage error: ${err.message}`);
      res.status(500).json(generateResponse('Internal Server Error', 500, "failed"));
    }
  };
  


