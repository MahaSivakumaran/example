import { Request, Response } from "express";
import { product } from "../model/productModel";
import { info, error } from "../config/loggerConfig";
import { createProductId } from "../utils/productIdGenerate";
import { generateResponse } from "../utils/responseGenerate";
import { createProcedureId } from "../utils/procedureIdGenerate";

let collection: any;
export async function productInstance() {
    collection = await product();
}


export const createProduct = async (req: Request, res: Response) => {
    info.info(`createProduct initiated`)
    info.info(`createProduct req.body ${JSON.stringify(req.body)}`);
    const { orgId, name, shift, procedure, isSingle } = req.body;
    if (!orgId || orgId === "") {
      error.error(`createProducts error: orgId missing`)
      return res.status(400).json(generateResponse("orgId is missing", 400, "failed"))
    }
    const result = await collection.aggregate([
      {
          $match: {
              $and: [
                { orgId },
                { $or: [{ name }] },
              ]
          }
      },
      {
          $unionWith: {
              coll: "group",
              pipeline: [
                  { $match: {  orgId , name } },
              ]
          }
      },
      {
          $unionWith: {
              coll: "pack",
              pipeline: [
                  { $match: {  orgId, name } },
              ]
          }
      },
      {
          $limit: 1 
      }
  ]).toArray();

    if (result.length > 0) {
        error.error(`createProduct error: Name already exists`)
        const response = generateResponse("Name already exists", 400, "failed");
        return res.status(400).json(response);
    }
    const product: any = [];
    const insertedData= {
      _id: await createProductId(),
      orgId,  
      name,
      shift,
      isSingle,
      procedure: product,
      createdAt: new Date(),
      updatedAt: new Date(),
  }
    for (const prod of procedure) {
        const procedureId = await createProcedureId(orgId);
        product.push({ ...prod, isDeleted: false, procedureId });
    }
    try {
        await collection.insertOne(insertedData)


        info.info(`createSection insertedData:${JSON.stringify(insertedData)}`)
        const response = generateResponse("Product Created Successfully", 201, "success");
        res.status(201).json(response);

    } catch (err: any) {
        const response = generateResponse("Internal server error", 500, "failed");
        error.error(`createSection errMessage : ${err.message}`);
        res.status(500).json(response);
    }


}

export const productDetails = async (req: Request, res: Response) => {
    info.info(`getProduct initiated`);
    info.info(`getProduct req.query:${JSON.stringify(req.query)}`);
    const {orgId } = req.params    
    try {
        const searchQuery = req.query.query
            ? { name: { $regex: new RegExp(req.query.query as string, 'i') } }
            : {};
        const result = await collection
            .find(searchQuery,orgId)
            .project({
                _id: 0,
                name: 1,
                shift: 1,
                procedure: {
                    $filter: {
                        input: {
                            $map: {
                                input: '$procedure',
                                as: 'proc',
                                in: {
                                    $cond: {
                                        if: { $eq: ['$$proc.isDeleted', false] },
                                        then: {
                                            procedureCode: '$$proc.procedureCode',
                                            name: '$$proc.name',
                                            qty: '$$proc.qty',
                                            unit: '$$proc.unit',
                                            price: '$$proc.price',
                                            productId: '$$proc.procedureId',
                                            rawMaterial: '$$proc.rawMaterial',
                                            processingList: '$$proc.processingList',
                                        },
                                        else: null,
                                    },
                                },
                            },
                        },
                        as: 'proc',
                        cond: { $ne: ['$$proc', null] },
                    },
                },
            })
            .toArray();


        const filteredResult = result.map((doc: any) => {
            if (!doc.procedure || doc.procedure.length === 0) {
                return null;
            }
            return doc;
        }).filter(Boolean);

        info.info(`productDetails data fetched`);
        const response = generateResponse("Products fetched..!", 200, "success", filteredResult);
        res.status(200).json(response);
    } catch (err:any) {
       error.error(`productDetails error: ${err.message}`)
        res.status(500).json(generateResponse(`Internal server error`,500,"failed"));
    }
};

export async function anyProduct (req: Request, res: Response) {
  const {id} = req.params;
  const {orgId} = req.query;
  info.info(`anyProduct initiated`);
  info.info(`anyProduct req.params:${JSON.stringify(req.params)} req.query:${JSON.stringify(req.query)}`);
  try{
    const prodData = await collection.findOne({_id: id, isDeleted: false, orgId}, {projection: {
      _id: 1,
      orgId: 1,
      name: 1,
      shift: 1,
      procedure: 1
    }});
    if(prodData)
    {
      if(Object.keys(prodData).length > 0)
      {
        info.info(`anyProduct id:${id} data fetched`);
        return res.status(200).json(generateResponse("Data fetched...", 200, "success", prodData));
      }
      else{
        error.error(`anyProduct id:${id} error: product not found`);
        return res.status(404).json(generateResponse("Product not found", 404, "failed"));
      }
    }
    else{
      error.error(`anyProduct id:${id} error: product not found`);
      return res.status(404).json(generateResponse("Product not found", 404, "failed"));
    }
  }
  catch(err: any)
  {
    error.error(`anyProduct id:${id} error: ${err.message}`);
    return res.status(500).json(generateResponse("Internal server error", 500, "failed"));
  }
}

export const editProduct = async (req: Request, res: Response) => {
    info.info(`editProduct initiated`)
    info.info(`editProduct req.params ${JSON.stringify(req.params)}`);
    info.info(`editProduct req.body:${JSON.stringify(req.body)}`);
    info.info(`editProduct req.query:${JSON.stringify(req.query)}`);

    const { id } = req.params;
    const {orgId} = req.query;

    if (!orgId) {
      error.error(`editProduct error: orgId missing`)
      return res.status(400).json(generateResponse("orgId is missing", 400, "failed"))
    }
    const { name, shift, price, procedure } = req.body;
    const result = await collection.aggregate([
      {
          $match: { _id: { $ne: id }, orgId, name: name }
      },
      {
          $unionWith: {
              coll: "group",
              pipeline: [
                  { $match: {  orgId , name } },
              ]
          }
      },
      {
          $unionWith: {
              coll: "pack",
              pipeline: [
                  { $match: {  orgId, name } },
              ]
          }
      },
      {
          $limit: 1 
      }
  ]).toArray();

    if (result.length > 0) {
        error.error(`createProduct error: Name already exists`)
        const response = generateResponse("Name already exists", 400, "failed");
        return res.status(400).json(response);
    }
    const updatedData = {
        name,
        shift,
        price,
        procedure,
        updatedAt: new Date()
    }
    try {
        await collection.findOneAndUpdate({ _id: id }, {
            $set: updatedData

        }, { new: true })

        info.info(`editProduct id:${id} updatedData:${JSON.stringify(updatedData)}`);
        const response = generateResponse(`Product edited for id: ${id} `, 201, "success");
        res.status(201).json(response);

    } catch (err: any) {
        error.error(`editProduct id:${id} errMessage: ${err.message}`);
        const response = generateResponse("Internal server error", 500, "failed");
        res.status(500).json(response);
    }

}

export const deleteProduct = async (req: Request, res: Response) => {
    info.info(`deleteProcedure initiated`);
    info.info(`deleteProcedure req.params ${JSON.stringify(req.params)}`);

    const { procedureId } = req.params;

    const filter = {
        'procedure.procedureId': procedureId,
    };

    const update = {
        $set: {
            'procedure.$.isDeleted': true,
            updatedAt: new Date(),
        },
    };

    try {
        const result = await collection.updateOne(filter, update);

        if (result.matchedCount > 0) {
            const response = generateResponse(`Procedure with procedureId ${procedureId} deleted successfully`, 200, "success");
            res.status(200).json(response);
        } else {
            const response = generateResponse(`Procedure with procedureId not found`, 404, "failed");
            res.status(404).json(response);
        }

        info.info(`deleteProcedure deleted for id: ${procedureId}`);
    } catch (err: any) {
        const response = generateResponse("Internal server error", 500, "failed");
        error.error(`deleteProcedure errMessage: ${err.message}`);
        res.status(500).json(response);
    }
};

export const allProductsName = async (req: Request, res: Response) => {
  info.info(`allProductsName initiated`);  
  info.info(`allProductsName req.query:${JSON.stringify(req.query)}`);
  try {
      const page = parseInt(req.query.page as string) || 1;
      const pageSize = parseInt(req.query.pageSize as string) || 10;
      const skip = (page - 1) * pageSize;

      const search = req.query.query || '';

      const sortField: any = req.query.sortField || 'name';
      const sortOrder = req.query.sortOrder === 'desc' ? -1 : 1;
      const sort = { [sortField]: sortOrder };
      const {orgId} = req.params 
      
      let filter: any = search ? { name: { $regex: search, $options: 'i' } } : {};
      if (orgId) {
        filter.orgId = orgId;
      }
  
      info.info(`allProductsName filter:${JSON.stringify(filter)}`);

      const aggregationPipeline = [
          { $match: filter },
          { $sort: sort },
          { $facet: {
              metadata: [
                  { $group: { _id: null, totalCount: { $sum: 1 } } },
                  { $project: {
                      totalCount: 1,
                      _id: 0
                  }}
              ],
              data: [
                  { $skip: skip },
                  { $limit: pageSize },
                  { $project: { name: 1, _id: 0 } }
              ]
          }}
      ];
      info.info(`allProductsName aggregationPipeline:${JSON.stringify(aggregationPipeline)}`);

      const result = await collection.aggregate(aggregationPipeline).toArray();     

      const response = generateResponse('Data fetched..', 200, "success", {
          totalCount: result[0]?.metadata[0]?.totalCount || 0,
          data: result[0]?.data || []
      });

      info.info(`allProductsName data fetched `);
      res.status(200).json(response);
  } catch (err: any) {
      const response = generateResponse('Internal server error', 500, "failed");
      error.error(`allProductsName errMessage: ${err.message}`);
      res.status(500).json(response);
  }
};

export const allProdNamesForGrp = async (req: Request, res: Response) => {
    info.info(`allProdNamesForGrp initiated`);
    info.info(`allProdNamesForGrp req.query:${JSON.stringify(req.query)}`);
    const {orgId} = req.query;
    if(!orgId || orgId === ""){
      error.error(`allProdNamesForGrp error: orgId missing`);
      return res.status(400).json(generateResponse(`orgId Missing..`,400,`failed`));
    }
    try {

        const prodName = await collection.aggregate([
            {
                $unwind: '$procedure'
            },
            {
                $match: {
                  orgId,
                    'procedure.isDeleted': { $ne: true }
                }
            },
            {
                $group: {
                    _id: '$_id',
                    procedure: { $push: '$procedure' }
                }
            },
            {
                $project: {
                    _id: 0,
                    'procedure.name': 1,
                    'procedure.procedureId': 1
                }
            }
        ]).toArray();

        info.info(`allProdNamesForGrp completed`);
        const response = generateResponse("Product Details Fetched..", 200, "success", prodName);
        res.status(200).json(response);
    } catch (err: any) {
      error.error(`allProdNamesForGrp error: ${err.message}`)
        const response = generateResponse("Internal server error", 500,"failed");
        res.status(200).json(response);
    }
}

export const productQuantity = async ( req: Request, res: Response ) => {
    info.info(`productQuantity initialized`);
    info.info(`productQuantity req.body:${JSON.stringify(req.body)}`);
    const {product} = req.body;
    const procedureIds = product.map((item: any) => item.procedureId);
    const pipeline = [
        {
        $match: {
            "procedure.procedureId": { $in: procedureIds },
        },
        },
        {
        $unwind: "$procedure",
        },
        {
        $match: {
            "procedure.procedureId": { $in: procedureIds },
        },
        },
        {
        $project: {
            _id: 0,
            procedureId: "$procedure.procedureId",
            procedureCode: "$procedure.procedureCode",
            name: "$procedure.name",
            qty: "$procedure.qty",
            unit: "$procedure.unit",
            rawMaterial: "$procedure.rawMaterial",
            processingList: "$procedure.processingList",
        },
        },
    ];
    
    const procedureDetails = await collection.aggregate(pipeline).toArray();
    const processedResult = procedureDetails.map((item: any) => {
        const prodQuantity = item.qty;
        const rawQuantity =
        product.find((data: any) => data.procedureId === item.procedureId)?.qty || 1;
    
        item.rawMaterial = item.rawMaterial.map((rawItem: any) => ({
        ...rawItem,
        qty: (rawItem.qty / prodQuantity) * rawQuantity,
        }));
        item.processingList = item.processingList.map((processingItem: any) => ({
        ...processingItem,
        qty: (processingItem.qty / prodQuantity) * rawQuantity,
        }));
        item.qty = rawQuantity;
        info.info(`productQuantity rawQuantity:${rawQuantity} prodQuantity:${prodQuantity}`);
        return item;
    });
    return res.status(200).json(generateResponse(`Data fetched..`,200,`success`,processedResult));
}

export const getProductPrice = async (req: Request, res: Response) => {
  try {
    info.info(`getProductPrice initiated`);
    info.info(`getProductPrice req.params ${JSON.stringify(req.params)}`);

    const { procedureId } = req.params;

    if (!procedureId) {
      error.error(`getProductPrice error: procedureId missing`)
      return res
        .status(404)
        .json(generateResponse("product Id is missing", 404, "failed"));
    }

    const pipeline = [
      {
        $match: {
          "procedure.procedureId": procedureId,
        },
      },
      {
        $unwind: "$procedure",
      },
      {
        $match: {
          "procedure.procedureId": procedureId,
        },
      },
      {
        $project: {
          _id: 0,
          qty: "$procedure.qty",
          price: "$procedure.price",
        },
      },
    ];
    info.info(`getProductPrice pipeline:${(JSON.stringify(pipeline))}`);

    const result = await collection.aggregate(pipeline).toArray();
    if (result.length == 1) {
      info.info(`getProductPrice completed`);
      res.status(200).json(result[0]);
    } else {
      info.info(`getProductPrice completed empty array result`);
      res.status(200).json(result);
    }
  } catch (err: any) {
    const response = generateResponse("Internal server error", 500, "failed");
    error.error(`getProductPrice errMessage: ${err.message}`);
    res.status(500).json(response);
  }
};

export const productQtyPriceCal = async (req: Request, res: Response) => {
  try {
    info.info(`productQtyPriceCal initiated`);
    info.info(`productQtyPriceCal req.body:${JSON.stringify(req.body)}`);

    const { prodIdDetails } = req.body;

    const proIds = prodIdDetails.map(
      (item: { procedureId: string }) => item.procedureId
    );

    info.info(`productQtyPriceCal proIds: ${JSON.stringify(proIds)}`);
    const pipeline = [
      {
        $match: {
          "procedure.procedureId": { $in: proIds },
        },
      },
      {
        $unwind: "$procedure",
      },
      {
        $match: {
          "procedure.procedureId": { $in: proIds },
        },
      },
      {
        $project: {
          _id: 1,
          procedureId: "$procedure.procedureId",
          qty: "$procedure.qty",
          price: "$procedure.price",
        },
      },
    ];

    info.info(`productQtyPriceCal pipeline:${JSON.stringify(pipeline)}`);

    const procedureAndpriceDetails =
      (await collection.aggregate(pipeline).toArray()) || [];

    const procedureDetails = new Map(
      procedureAndpriceDetails.map((item: { procedureId: string }) => [
        item.procedureId,
        item,
      ])
    );

    const result = prodIdDetails.map(
      (item: { procedureId: string; qty: any }) => {
        const { procedureId, qty } = item;
        const correspondingItem: any = procedureDetails.get(procedureId);

        if (correspondingItem) {
          const { price } = correspondingItem;
          const newPrice = (qty / correspondingItem.qty) * parseFloat(price);
          info.info(`productQtyPriceCal procedureId:${procedureId} newPrice:${newPrice}`);
          return { procedureId, newPrice };
        } else {
          info.info(`productQtyPriceCal procedureId:${procedureId} newPrice:0`);
          return { procedureId, newPrice: 0 };
        }
      }
    );

    info.info(`product Qty and price , data fetched`);
    const response = generateResponse(
      "Item price list fetched",
      200,
      "success",
      result
    );
    res.status(200).json(response);
  } catch (err: any) {
    const response = generateResponse("Internal server error", 500, "failed");
    error.error(`productQtyPriceCal errMessage: ${err.message}`);
    res.status(500).json(response);
  }
};

export const productReportList = async (req: Request, res: Response) => {
  try {
    info.info(`productReportList initiated`);
    info.info(`productReportList req.query ${JSON.stringify(req.query)}`);

    const { orgId } = req.query;

    if (!orgId || orgId === "") {
      error.error(`productReportList error: orgId missing`)
      return res
        .status(400)
        .json(generateResponse("Organisation Id is missing", 400, "failed"));
    }

    const projection = {
      _id: 1,
      procedureId: "$procedure.procedureId",
      name: "$procedure.name",
      price: "$procedure.price",
    };
    const productList = await collection
      .find({ orgId, isDeleted: false }, { projection })
      .toArray();
    info.info(`kitchen Product List ${JSON.stringify(productList)}`);

    const productListNewArrayResult = productList.flatMap((item: { name: any[]; procedureId: { [x: string]: any; }; price: { [x: string]: number; }; }) => 
        item.name.map((name, index) => ({
            procedureId: item.procedureId[index],
            name,
            price: (Math.round(item.price[index] * 100) / 100).toFixed(2)
        }))
    )

    info.info(`Product list fetched successfully`);
    const response = generateResponse(
      "Product list fetched",
      200,
      "success",
      productListNewArrayResult
    );
    res.status(200).json(response);
  } catch (err: any) {
    console.log("err", err);
    const response = generateResponse("Internal server error", 500, "failed");
    error.error(`productReportList errMessage: ${err.message}`);
    res.status(500).json(response);
  }
};