import { Request, Response } from "express";
import { item } from "../model/itemModel";
import { info, error } from "../config/loggerConfig";
import { createItemId } from "../utils/itemIdGenerate";
import { searchAndPaginate } from "../utils/apiFeatures";
import { generateResponse } from "../utils/responseGenerate";
import axios from "axios";

let collection: any;

export async function itemInstance(){
    collection = await item();
}
const baseUrl = process.env.BASE_URL;
const userServicePort = process.env.USER_SERVICE_PORT;

export async function createItem ( req: Request, res: Response ) {
    info.info(`createItem initiated`);
    info.info(`createItem reqBodyParams:${JSON.stringify(req.body)}`);
    try{
        const {name, minQty, maxQty, unit, orgId} = req.body;
        const supplier = req.body.supplier ? req.body.supplier : null ;
        const section = req.body.section ? req.body.section : null ;
        const id = await createItemId();
        const insertData={
            _id: id,
            name,
            minQty,
            maxQty,
            unit,
            orgId,
            ...(supplier && {supplier: supplier}),
            ...(section && {section: section}),
            isDeleted: false,
            currentQty: 0,
            createdAt: new Date(),
            updatedAt: new Date()
        }
        await collection.insertOne(insertData);
        info.info(`Item created insertedData: ${JSON.stringify(insertData)} `);
        res.status(200).json(generateResponse(`Item created successfully..`,201,"success"))
    }
    catch(err:any){
        error.error(`createItem error:${err.message}`);
        res.status(500).json(generateResponse(`Internal server error`,500,"failed"))
    }
}

export async function editItem ( req: Request, res: Response ) {
    info.info(`editItem initiated`);
    info.info(`editItem reqBodyParams:${JSON.stringify(req.body)}`);
    try{
        const { id } = req.params;

        const {name, minQty, maxQty, unit} = req.body;
        const supplier = req.body.supplier ? req.body.supplier : null ;
        const section = req.body.section ? req.body.section : null ;
        
        const updateData = {
            name,
            minQty,
            maxQty,
            unit,
            ...(supplier && {supplier: supplier}),
            ...(section && {section: section}),
            updatedAt: new Date()
        }
        const data = await collection.findOne({_id: id,});
        if(!data) {
            error.error(`editItem error: No data found`);
            return res.status(404).json(generateResponse(`No data found..`,404,`failed`))
        }
        await collection.findOneAndUpdate({_id : id}, {
            $set: updateData
        },);
        info.info(`editItem edited id: ${id}`);
        res.status(200).json(generateResponse(`Item edited successfully..`,200,`success`))
    }
    catch(err: any){
        error.error(`editItem error:${err.message}`);
        res.status(500).json(generateResponse(`Internal server error`,500,`failed`))
    }
}

export async function deleteItem ( req: Request, res: Response ) {
    info.info(`deleteItem initiated`);
    info.info(`deleteItem req.params:${JSON.stringify(req.params)}`);
    const { id } = req.params;
    try{
        const data = await collection.findOne({_id: id,});
        if(!data) {
            error.error(`deleteItem error: No data found`);
            return res.status(404).json(generateResponse(`No data found..`,404,`failed`))
        }
        await collection.findOneAndUpdate({_id : id}, {
        $set: {
            isDeleted: true,
            updatedAt: new Date()
        }
        });
        info.info(`deleteItem id:${id} deleted`);
        res.status(200).json(generateResponse(`Item deleted..`,200,"success"))
    }
    catch(err){
        error.error(`deleteItem id:${id} error:${err}`);
        res.status(500).json(generateResponse(`Internal server error`,500,`failed`))
    }
}

export async function getItem (req: Request, res: Response) {
    info.info(`getItem initiated`);
    info.info(`getItem req.params:${JSON.stringify(req.params)} req.query:${JSON.stringify(req.query)}`);
    const {id} = req.params;
    const {orgId} = req.query;
    if(!orgId || orgId === ""){
     error.error(`getItem error: orgId missing`);
     return res.status(400).json(generateResponse(`orgId is missing`,400,`failed`))   
    }
    try{
        const itemData = await collection.findOne({_id: id, isDeleted: false, orgId}, {projection: {
            _id: 1,
            name: 1,
            minQty: 1,
            maxQty: 1,
            unit: 1,
            supplier: 1,
            currentQty: 1
        }});
        if(itemData)
        {
            if(Object.keys(itemData).length > 0)
            {
                info.info(`getItem id:${id} data fetched`);
                return res.status(200).json(generateResponse("Data fetched...", 200, "success", itemData));
            }
            else{
                error.error(`getItem id:${id} error: item not found`);
                return res.status(404).json(generateResponse("Item not found", 404, "failed"));
            }
        }
        else{
            error.error(`getItem id:${id} error: item not found`);
            return res.status(404).json(generateResponse("Item not found", 404, "failed"));
        }
    }
    catch(err: any)
    {
        error.error(`getItem id:${id} error:${err.message}`);
        res.status(500).json(generateResponse("Internal server error", 500, "failed"));
    }
}

export async function listItem ( req: Request, res: Response) {
    info.info(`listItem initiated`);
    info.info(`listItem req.query:${JSON.stringify(req.query)}`);
    const { query, sortColumn, sortBy, page, pageSize, orgId} = req.query;
    if(!orgId || orgId === ""){
        error.error(`listItem error: orgId missing`);
        return res.status(400).json(generateResponse(`orgId missing..`,400,`failed`))
    }
    try {
        const data = await searchAndPaginate(collection, query, page, sortBy, sortColumn, pageSize, orgId);

        const resp =generateResponse("Data fetched...", 200, "success", data);
        res.status(200).send(resp);
    }
    catch(err: any){
        const response = generateResponse("Internal server error", 400, "failed")
        error.error(`listItem errMessage : ${err.message}`)
        res.status(500).json(response)
    }
}

export async function addQty ( req: Request, res: Response ) {
    info.info(`addQty initiated`);
    info.info(`addQty req.query:${JSON.stringify(req.query)}`);
    const {id} = req.query;
    if(!id) 
    {
        error.error(`addQty error itemId missing in params`);
        return res.status(400).send({message: "Item Id is missing"});
    }
    try {

        const projection ={
            currentQty: 1
        }
        const resp = await collection.findOne({_id: id}, {projection});
        if(!resp) 
        {
            error.error(`addQty id:${id} error item not found`);
            return res.status(404).send({message: "Item not found"});
        }

        const count = req.query.qty as string;
        if(!count) 
        {
            error.error(`addQty id:${id} error quantity not found`);
            return res.status(400).send({message: "Quantity is missing"});
        }

        const qty = resp.currentQty + parseInt(count);
        await collection.findOneAndUpdate({_id:id},{
            $set : {currentQty : qty, updatedAt: new Date()}
        },
        {
            new: true
        });
        
        info.info(`addQty id:${id} currentQty updated to${qty}`);
        res.status(200).send({message: "success"});
        
    }
    catch(err: any){
        error.error(`addQty errMessage : ${err.message}`)
        res.status(500).send({message: err.message});
    }
}

export async function removeQty ( req: Request, res: Response ) {
    info.info(`removeQty initiated`);
    info.info(`removeQty req.body:${JSON.stringify(req.body)}`);
    info.info(`removeQty req.query:${JSON.stringify(req.query)}`);
    try {
        const ids = req.body.ids;
        const {orgId}: any = req.query;
        let idList: any = [];
        
        ids.forEach((id: any)  => {
            idList.push(id.itemId);
        });
        const itemDetails = await collection.find({_id: {$in : idList}}, { projection:{ _id: 1, currentQty: 1}}).toArray();
        
        let itemTemp: any;
        itemDetails.forEach((item : any) => {
            itemTemp = ids.find(({itemId}: any) => itemId === item._id);
            item.currentQty = item.currentQty - itemTemp.qty;
        });
        
        const updateQuery = itemDetails.map((item:any) => ({
            updateOne: {
              filter: { _id: item._id },
              update: { $set: { currentQty: item.currentQty, updatedAt: new Date() } }
            }
          }));

          const bulkWriteresult = await collection.bulkWrite(updateQuery);
          
          const result = await checkMinItem(orgId).then((resp)=>{
            info.info(`removeOneQty checKMinItem success`);
        }).catch((err)=>{
            if(err == true)
            {
                info.info(`removeOneQty checkMinItem no item fetched`);
            }
            else{
                error.error(`removeOneQty checkMinItem error`);
            }
        })

        res.status(200).send({message: "success"});
        
    }
    catch(err: any){
        error.error(`removeQty errMessage : ${err.message}`)
        res.status(500).send({message: err.message});
    }
}
export async function removeOneQty ( req: Request, res: Response ) {
    info.info(`removeOneQty initiated`);
    info.info(`removeOneQty req.query:${JSON.stringify(req.query)}`);
    try {
        const {id, oldQty, newQty, orgId}: any = req.query;
        
        const itemDetails = await collection.findOne({_id: id}, { projection:{ currentQty: 1}});

        let qty = itemDetails.currentQty + parseInt(oldQty) - parseInt(newQty);

        await collection.updateOne({_id: id}, {
            $set:{currentQty: qty, updatedAt: new Date()}
        });
        const result = await checkMinItem(orgId).then((resp)=>{
            info.info(`removeOneQty checKMinItem success`);
        }).catch((err)=>{
            if(err == true)
            {
                info.info(`removeOneQty checkMinItem no item fetched`);
            }
            else{
                error.error(`removeOneQty checkMinItem error`);
            }
        })
        res.status(200).send({message: "success"});
        
    }
    catch(err: any){
        error.error(`removeOneQty errMessage : ${err.message}`)
        res.status(500).send({message: err.message});
    }
}

export async function getSupplier ( req: Request, res: Response ) {
    try{
        const itemId = req.params.id;
        const {orgId} = req.query;
        if(!orgId || orgId === ""){
            error.error(`getSupplier error: orgId missing`);
            return res.status(400).json(generateResponse(`orgId is missing`,400,`failed`))   
           }
        info.info(`getSupplier initiated itemId:${itemId}, orgId:${orgId}`);
        const projection = {
            _id: 1,
            supplier: 1
        }
        const suppliers = await collection.find({orgId,_id: itemId, isDeleted: false}, {projection}).toArray();
        if(suppliers.length > 0){
            const resp = generateResponse("Data fetched...", 200, "Success", suppliers);
            res.status(200).json(resp);
        }else{
            const resp = generateResponse("No data found..", 404, "Failed");
            res.status(400).json(resp);
        }
    }
    catch(err: any)
    {
        error.error(`getSupplier error:${err.message}`);
        const resp = generateResponse("Internal server error", 500, "failed");
        res.status(500).json(resp);
    }
}

export async function validateSupplier (req: Request, res: Response) {
    try{
        info.info(`validateSupplier initiated`);
        const {itemId, supplier} = req.query;
        info.info(`validateSupplier itemId:${itemId} supplier:${supplier}`);
        const itemData = await collection.find({_id: itemId, supplier: {$in: [supplier]}}).toArray();
        if(itemData.length < 1) {
            await collection.updateOne({_id: itemId},
                {
                    $push: { supplier: supplier}
                })
                res.status(200).json(`success`)
        }
        else{
        res.status(400).json({message: "already exist"})
        }
    }
    catch(err: any)
    {
        error.error(`validateSupplier error:${err.message}`);
        const resp = generateResponse("Internal server error", 500, "failed");
        res.status(500).json(resp);
    }
}

export async function currentQty (req: Request, res: Response) {
    const {id} = req.params;
    try{
        info.info(`currentQty id:${id} initiated`);
        const itemDetail = await collection.findOne({_id: id},{projection: {currentQty: 1}});
        info.info(`currentQty id:${id} currentQty:${itemDetail.currentQty}`);
        res.status(200).send({currentQty: itemDetail.currentQty});
    }
    catch(err: any)
    {
        error.error(`currentQty id:${id} error:${err.message}`);
        res.status(500).json(generateResponse(`Internal server error`,500,"failed"));
    }
}

export async function alertList (req: Request, res: Response){
    const {orgId} = req.query;
    if(!orgId || orgId === ""){
        error.error(`alertList error: orgId missing`);
        return res.status(400).json(generateResponse(`orgId is missing`,400,`failed`))   
       }
    try{
        info.info(`alertList orgId:${orgId} initiated`);
        const pipeline = [
            {
              $match: {
                $expr: {
                  $lt: ["$currentQty", "$minQty"]
                }
              }
            },
            {
              $project: {
                _id: 1,
                minQty: 1,
                maxQty: 1,
                currentQty: 1
              }
            }
          ];
          info.info(`alertList pipeLine: ${JSON.stringify(pipeline)} `);
          const itemData = await collection.aggregate(pipeline).toArray();
          info.info(`alertList data fetched `);
          if(itemData.length > 0){
          res.status(200).json(generateResponse("Alert data fetched..", 200, "Success", itemData));
          }
          else if(itemData.length <= 0)  {
            res.status(200).json(generateResponse("No alert found...", 200, "Success"));
          }
          else {
            res.status(500).json(generateResponse("Internal server error..", 500, "Failed"));
          }
    }
    catch(err: any)
    {
        error.error(`alertList orgId:${orgId} error:${err.message}`);
        res.status(500).json(generateResponse(`Internal server error`,500,"failed"));
    }
}

async function checkMinItem ( orgId: string)
{
    return new Promise( async (resolve, reject) =>{
        info.info(`checkMinItem orgId:${orgId} initiated`);
        const itemData = await collection.find({orgId, $expr: { $lte: ["$currentQty", "$minQty"] }}, { projection: { 
            _id: 1,
            name: 1,
            minQty: 1,
            currentQty: 1
        }}).toArray();
        if(itemData.length > 0)
        {
        const userApiEndpoint = `http://${baseUrl}:${userServicePort}/api/userServices/notification/item/minQtyAlert?orgId=${orgId}`;
        const response = await axios.put(userApiEndpoint, {itemData, isAdminSend: false} ).then(() => {
            info.info(`checkMinItem orgId:${orgId} notification sent`);
            resolve(true)
        }).catch((err: any) => {
            error.error(`checkMinItem orgId:${orgId} notification error${err.message}`);
            reject(err);
        });

        }
        else{
            info.info(`checkMinItem orgId:${orgId} no item fetched`);
            reject(true);
        }
    })
}

export async function alertGuser (req: Request, res: Response) {
    const {orgId} =  req.query;
    const {id} = req.params;
    info.info(`alertGUser req.query:${JSON.stringify(req.query)}`);
    info.info(`alertGUser req.params:${JSON.stringify(req.params)}`);
    try{
        info.info(`alertGuser orgId:${orgId} itemId:${id} initiated`);
        const itemData = await collection.find({_id: id, isDeleted: false}, {projection: {
            _id: 1,
            name: 1,
            minQty: 1,
            currentQty: 1
        }}).toArray();
        if(!itemData)
        {
            info.info(`alertGuser orgId:${orgId} itemId:${id} no data found`);
            return res.status(404).json(generateResponse("No data found", 404, "Failed"));
        }
        else{
            const userApiEndpoint = `http://${baseUrl}:${userServicePort}/api/userServices/notification/item/minQtyAlert?orgId=${orgId}`;
            const response = await axios.put(userApiEndpoint, {itemData, isAdminSend: true} ).then(() => {
            info.info(`alertGuser orgId:${orgId} itemId:${id} notification sent`);
            return res.status(200).json(generateResponse("Alert sent to store user", 200, "Success"));
        }).catch((err: any) => {
            error.error(`alertGuser orgId:${orgId} itemId:${id} notification error${err.message}`);
            return res.status(500).json(generateResponse("Error while notified to store user", 500, "Failed"));
        });
        }
    }
    catch(err: any){
        error.error(`alertGuser orgId:${orgId} itemId:${id} error:${err.message}`);
        return res.status(500).json(generateResponse("Error while notified to store user", 500, "Failed")); 
    }
}