import { Request, Response } from "express";
import { info, error } from "../config/loggerConfig";
import { generateResponse } from "../utils/responseGenerate";
import { calculateNoOfProducts, searchAndPaginate } from "../utils/apiFeatures";
import { pack } from "../model/packageModel";
import { createPackId } from "../utils/packIdGenerate";

let collection: any;
export async function packInstance() {
    collection = await pack();
}

export async function createPack(req: Request, res: Response) {
    info.info(`createPack initiated`)
    info.info(`createPack req.body ${JSON.stringify(req.body)}`)
    const { orgId, name, price, heads, shift, productList } = req.body;
    const result = await collection.aggregate([
        {
            $match: {
                $and: [
                    { orgId },
                    { $or: [{ name }] }
                ]
            }
        },
        {
          $unionWith: {
            coll: "group",
            pipeline: [
              { $match: { orgId, name } },
            ]
          }
        },
        {
          $unionWith: {
            coll: "product",
            pipeline: [
              { $match: { orgId,  name } },
            ]
          }
        },
        {
          $limit: 1
        }
      ]).toArray();
    

    if (result.length > 0) {
        error.error(`createPack error: Name already exists`)
        const response = generateResponse("Name already exists", 400, "failed");
        return res.status(400).json(response);
    }
    const _id = await createPackId();
    try {
      const insertedData ={
        _id,
        orgId,
        name,
        price,
        heads,
        shift,
        isDeleted: false,
        productList,
        createdAt: new Date(),
        updatedAt: new Date()
    }
        await collection.insertOne(insertedData)
        const response = generateResponse("Pack Created Successfully", 201, "success")
        res.status(201).json(response)
        info.info(`createPack insertedData: ${JSON.stringify(insertedData)}`)

    } catch (err: any) {
        const response = generateResponse("Internal server error", 500, "failed")
        error.error(`createPack error: ${err.message}`)
        res.status(500).json(response)
    }
}

export const editPackage = async (req: Request, res: Response) => {  
    info.info(`editPackage initiated`);
    info.info(`editPackage req.params ${JSON.stringify(req.params)}`);
    info.info(`editPackage req.body:${JSON.stringify(req.body)}`);
    info.info(`editPackage req.query:${JSON.stringify(req.query)}`);
    const {orgId} = req.query;
    if (!orgId || orgId === "") {
      error.error(`editPackage error: orgId missing`)
      return res.status(400).json(generateResponse("orgId is missing", 400, "failed"))
    }

    const id = req.params.id;
    const { name, price, heads, shift, productList } = req.body;

    const result = await collection.aggregate([
        {
            $match: { _id: { $ne: id }, orgId, name: name }
        },
        {
            $unionWith: {
                coll: "group",
                pipeline: [
                    { $match: { name, orgId } },

                ]
            }
        },
        {
            $unionWith: {
                coll: "product",
                pipeline: [
                    { $match: { name, orgId } },

                ]
            }
        },
        {
            $match: {
                $or: [
                    { name: name },
                    { "groupData.name": name },
                    { "productData.name": name }
                ]
            }
        }
    ]).toArray();

    if (result.length > 0) {
        error.error(`editPackage id:${id} error: Name already exists`)
        const response = generateResponse("Name already exists", 400, "failed");
        return res.status(400).json(response);
    }
    
    const updatedData = {
        name,
        price,
        heads,
        shift,
        productList,
        updatedAt: new Date()
    }
    try {
        await collection.findOneAndUpdate({ _id: id }, {
            $set: updatedData
        },
            {
                new: true
            }
        )
        info.info(`editPackage id:${id} updatedData:${JSON.stringify(updatedData)}`);
        const response = generateResponse("Package Updated Successfully", 200, "success")
        res.status(200).json(response);

    } catch (err: any) {
        error.error(`editPackage id:${id} error: ${err.message}`);
        const response = generateResponse("Internal server error", 500, "failed")
        res.status(500).json(response);
    }
}

export async function anyPack (req: Request, res: Response)
{
  const {id} = req.params;
  info.info(`anyPack initiated`);
  info.info(`anyPack req.params:${JSON.stringify(req.params)} req.query:${JSON.stringify(req.query)}`);

  try{
    const packData = await collection.findOne({_id: id, isDeleted: false}, {projection:{
      _id: 1,
      orgId: 1,
      name: 1,
      price: 1,
      heads: 1,
      shift: 1,
      productList: 1
    }});
    if(packData)
    {
      if(Object.keys(packData).length > 0)
      {
        info.info(`anyPack id:${id} data fetched`);
        return res.status(200).json(generateResponse("Data fetched...", 200, "success", packData));
      }
      else{
        error.error(`anyPack id:${id} error: pack not found`);
        return res.status(404).json(generateResponse("Pack not found", 404, "failed"));
      }
    }
    else{
      error.error(`anyPack id:${id} error: pack not found`);
      return res.status(404).json(generateResponse("Pack not found", 404, "failed"));
    }
  }
  catch(err: any)
  {
    error.error(`anyPack id:${id} error: ${err.message}`);
    return res.status(500).json(generateResponse("Internal server error", 500, "failed"));
  }
}

export const deletePack = async (req: Request, res: Response) => {
    info.info(`deletePack initiated`)
    info.info(`deletePack req.params ${JSON.stringify(req.params)}`);
    const { id } = req.params

    const updatedData = {
        isDeleted: true,
        updatedAt: new Date()
    }
    try {

        const existingDoc = await collection.findOne({ _id: id });
        if (!existingDoc) {
            error.error(`deletePack error: Data not found`)
            const response = generateResponse(`Data not found`, 404, "failed");
            return res.status(404).json(response);
        }
        await collection.findOneAndUpdate({ _id: id }, {
            $set: updatedData
        }
        )
        info.info(`deletePack for id:${id} updatedData:${JSON.stringify(updatedData)}`)
        const response = generateResponse(`Pack deleted successfully`, 200, "success")
        res.status(200).json(response);
    } catch (err: any) {
        const response = generateResponse("Internal server error", 500, "failed")
        error.error(`deletePack error: ${err.message}`)
        res.status(500).json(response);
    }
}


export const getPack = async (req: Request, res: Response) => {
    info.info(`getPack initiated`);
    info.info(`getPack req.query ${JSON.stringify(req.query)}`);
    const { query, page, sortBy, sortColumn, pageSize , orgId} = req.query;
    if (!orgId || orgId === "") {
      error.error(`getPack error: orgId missing`)
      return res.status(404).json(generateResponse("orgId is missing", 404, "failed"))
    }
    try {
        const data = await searchAndPaginate(collection, query, page, sortColumn, sortBy,pageSize, orgId);       
        const updatedData = await calculateNoOfProducts(data.list);
        const response = generateResponse("data fetched..", 200, "success", {
            ...data,
            list:updatedData
        });
        info.info(`getPack data fetched`);
        res.status(200).json(response);
    } catch (err: any) {
        const response = generateResponse("Internal server error", 500, "failed");
        error.error(`getPack error: ${err.message}`);
        res.status(500).json(response);
    }
};


export const packageHeadCountCal = async (req: Request, res: Response) => {

  info.info(`packageHeadCountCal initiated`);
  info.info(`packageHeadCountCal req.params ${JSON.stringify(req.params)}`);
  info.info(`packageHeadCountCal req.query ${JSON.stringify(req.query)}`);

  const { id } = req.params;
  const count: any = req.query.count;


  if (!count || count === "") {
    error.error(`packageHeadCountCal error: Count value missing`);
    const response = generateResponse(
      "Count value is missing",
      404,
      "failure"
    );
    return res.status(404).json(response);
  }

  try {

    const projection = {
      heads: 1,
      productList: 1,
    };

    const packageResult = await collection.findOne(
      {
        _id: id,
        isDeleted: false,
      },
      { projection }
    );

    if (!packageResult) {
      const response = generateResponse("Package not found..!", 404, "failed");
      error.error(`packageHeadCountCal id:${id} error: Package not found`)
      return res.status(404).json(response);
    }

    const productList = packageResult.productList;
    const packageHeadCount = packageResult.heads;

    const result = await productList.map(
      (item: {
        id: string;
        name: string;
        procedureName: string;
        unit: string;
        quantity: string;
      }) => {
        const qty: any = item.quantity;
        const packageQty = (qty * count) / packageHeadCount;
        info.info(`packageHeadCountCal id:${id} productId:${item.id} qty:${qty} packageQty:${packageQty}`);

        return {
          id: item.id,
          name: item.name,
          procedureName: item.procedureName,
          quantity: Math.round(packageQty * 10) / 10,
          unit: item.unit,
        };
      }
    );

    info.info(`packageHeadCountCal id:${id} data fetched and calculated`);
    const response = generateResponse(
      "Package fetched successfully",
      200,
      "success",
      result
    );
    res.status(200).json(response);
  } catch (err: any) {
    error.error(`packageHeadCountCal id:${id} error: ${err.message}`);
    const response = generateResponse("Internal server error", 500, "failed");
    res.status(500).json(response);
  }
};