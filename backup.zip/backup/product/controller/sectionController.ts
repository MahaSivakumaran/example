import { Request, Response } from "express";
import { info, error } from "../config/loggerConfig";
import { generateResponse } from "../utils/responseGenerate";
import { section } from "../model/sectionModel";
import { createSectionId } from "../utils/sectionIdGenerate";

let collection: any;
export async function sectionInstance() {
    collection = await section();
}

export const createSection = async (req: Request, res: Response) => {
    info.info(`createSection initiated`)
    info.info(`createSection req.body ${JSON.stringify(req.body)}`);
    const { orgId, name, prodItems } = req.body;
    
    const insertedData={
        _id :await createSectionId(),
        orgId,
        name,
        prodItems,
        isDeleted: false,
        createdAt: new Date(),
        updatedAt: new Date()
    }
    try {
        await collection.insertOne(insertedData);
        const response = generateResponse("Section Created Successfully", 201, "success");
        res.status(201).json(response);
        info.info(`createSection insertedData: ${JSON.stringify(insertedData)}`)

    } catch (err: any) {
        const response = generateResponse("Internal server error", 500, "failed");
        error.error(`createSection errMessage : ${err.message}`);
        res.status(500).json(response);
    }
}

export const editSection = async (req: Request, res: Response) => {
    info.info(`editSection initiated`);
    info.info(`editSection req.body ${JSON.stringify(req.body)}`);
    info.info(`editSection req.params:${JSON.stringify(req.params)}`);

    const { id } = req.params;
    const { items } = req.body;
    const updatedData = {
        prodItems: items,
        updatedAt: new Date()
    }
    try {
        const data = await collection.findOne({_id: id});
        if(!data){
            error.error(`editSection error: data not found`)
            return res.status(404).json(generateResponse("Data not found",404,"failed"))
        }
        await collection.findOneAndUpdate({ _id: id }, {
            $set: updatedData
        }
        )
        const response = generateResponse("Section Updated Successfully", 200, "success")
        res.status(200).json(response);
        info.info(`editSection id:${id} insertedData: ${JSON.stringify(updatedData)}`)

    } catch (err: any) {
        const response = generateResponse("Internal server error", 500, "failed")
        error.error(`editSection id:${id} errMessage: ${err.message}`)
        res.status(500).json(response);
    }
}

export const deleteSection = async (req: Request, res: Response) => {
    info.info(`deleteSection initiated`)
    info.info(`deleteSection req.params:${JSON.stringify(req.params)}`)
    const { id } = req.params
    const updatedData = {
        isDeleted: true,
        updatedAt: new Date()
    }
    try {

        const data = await collection.findOne({_id:id});
        
    if (!data) {
        error.error(`deleteSection error: Data not found`)
        return res.status(404).json(generateResponse("data not found",404,"failed"))
    }
        await collection.findOneAndUpdate({ _id: id }, {
            $set: updatedData
        },
            {
                new: true
            }
        )
        const response = generateResponse("Section deleted Successfully", 200, "success")
        res.status(200).json(response);
        info.info(`deleteSection completed for id:${id}`)

    } catch (err: any) {
        const response = generateResponse("Internal server error", 500, "failed")
        error.error(`deleteSection id:${id} errMessage : ${err.message}`)
        res.status(500).json(response);
    }
}

export async function getOneSection (req: Request, res: Response) {
    info.info(`getOneSection initiated`);
    info.info(`getOneSection req.params:${JSON.stringify(req.params)}`);
    const {id} = req.params;
    try{
        info.info(`getOneSection id:${id} initiated`);
        const sectionData = await collection.findOne({_id: id, isDeleted: false}, { projection: {name: 1, prodItems: 1,}});
        if(!sectionData)
        {
            error.error(`getOneSection id:${id} error: section not found`);
            res.status(404).json(generateResponse("Section not found", 404, "Failed"));
        }
        info.info(`getOneSection id:${id} data fetched`);
        res.status(200).json(generateResponse("Section data fetched", 200, "Success", sectionData));
    }
    catch(err: any){
        error.error(`getOneSection id:${id} error:${err.message}`);
        res.status(500).json(generateResponse("Internal server error", 500, "Failed"));
    }
}

export async function renameSection (req: Request, res: Response) {
    info.info(`renameSection initiated`);
    info.info(`renameSection req.params:${JSON.stringify(req.params)}`);
    const {id} = req.params;
    
    try{
        const name: string = req.body.name;
        const data =  await collection.findOne({_id: id, isDeleted: false});
        if(!data){
            error.error(`renameSection error: Data not found`);
            return res.status(404).json(generateResponse(`Data not found`,404,`failed`));
        }
        await collection.findOneAndUpdate({_id: id, isDeleted: false}, {
            $set: { name, updatedAt: new Date()}
        });
        info.info(`renameSection id:${id} with name:${name}`);
        res.status(200).json(generateResponse("Renamed section successfully", 200, "Success"));
    }
    catch(err: any) {
        error.error(`renameSection id:${id} error:${err.message}`);
        res.status(500).json(generateResponse("Internal server error", 500, "Failed"));
    }
}

export const getSection = async (req: Request, res: Response) => {
    info.info(`getSection initiated`);
    info.info(`getSection req.query:${JSON.stringify(req.query)}`);
    let query = req.query
    let page = parseInt(query.page as string, 10) || 1;
    let pageSize = parseInt(query.pageSize as string, 10) || 10;
    const orgId = query.orgId
    const skip = (page - 1) * pageSize;

    if (!orgId || orgId === "") {
        error.error(`getSection error: orgId missing`)
        return res.status(404).json(generateResponse("orgId is missing", 404, "failed"))
      }

    const project = {
        _id: 1,
        orgId: 1,
        name: 1,
        prodItems: 1
    };
    try {
        const result = await collection
            .aggregate([
                { $match: { orgId, isDeleted: false } },
                { $project: project },
                {
                    $facet: {
                        data: [
                            { $skip: skip },
                            { $limit: Number(pageSize) }
                        ],
                        total: [
                            { $count: 'count' }
                        ]
                    }
                }
            ])
            .toArray();

        const list = result[0]?.data || [];
        const total = result[0]?.total[0]?.count || 0;

        const response = generateResponse("data fetched...", 200, "success", {
            totalCount :total,
            list,
        });
        res.status(200).json(response);
        info.info(`getSection completed`);
    } catch (err: any) {
        const response = generateResponse("Internal server error", 500, "failed");
        error.error(`getSection errMessage: ${err.message}`);
        res.status(500).json(response);
    }
};

export async function getSectionList ( req: Request, res: Response ) {
    info.info(`getSectionList initiated`);
    info.info(`getSectionList req.query:${JSON.stringify(req.query)}`);
    const {orgId} = req.query;
    if(!orgId)
    {
        error.error(`getSectionList error: orgId missing`);
        return res.status(400).json(generateResponse("orgId is missing", 400, "failed"));
    }
    try{
        const projection = {
            _id: 1,
            name: 1
        }
        const sectionList = await collection.find({orgId, isDeleted: false}, {projection}).toArray();
        const resp = generateResponse("Data fetched...", 200, "Success", sectionList);
        info.info(`getSectoinList orgId:${orgId} data fetched`)
        res.status(200).json(resp);
    }
    catch(err: any)
    {
        error.error(`getSectionList orgId:${orgId} error:${err.message}`);
        const resp = generateResponse("Internal server error", 500, "failed");
        res.status(500).json(resp);
    }
}

export async function getSectionItemList ( req: Request, res: Response ) {
    info.info(`getSectionItemList initiated`);
    info.info(`getSectionItemList req.query:${JSON.stringify(req.query)}`);
    info.info(`getSectionItemList req.params:${JSON.stringify(req.params)}`);
    const {orgId} = req.query;
    const {sectionId} = req.params;

    if (!orgId || orgId === "") {
        error.error(`getSectionItemList error: orgId missing`)
        return res.status(404).json(generateResponse("orgId is missing", 404, "failed"))
      }
    try{
        const projection = {
            _id: 1,
            prodItems: 1
        }
        const data = await collection.findOne({_id: sectionId, isDeleted: false});
        if(!data){
            error.error(`getSectionItemList error: data not found`);
        return res.status(404).json(generateResponse("Data not found", 404, "failed"))
        }
        const itemList = await collection.find({orgId, _id: sectionId, isDeleted: false}, {projection}).toArray();
        info.info(`getSectionItemList sectionId:${sectionId} data fetched successfully`);
        const resp = generateResponse("Data fetched...", 200, "Success", itemList);
        res.status(200).json(resp);
    }
    catch(err: any)
    {
        error.error(`getSectionItemList sectionId:${sectionId} error:${err.message}`);
        const resp = generateResponse("Internal server error", 500, "failed");
        res.status(500).json(resp);
    }
}

