import express from 'express';
import { Request, Response, NextFunction } from 'express';
import { productMgmt } from "../middleware/userValidation";
import { userAccess } from "../middleware/userAccessValidation";
import { firebaseValidation } from "../middleware/firebaseValidation";
import { createSection, deleteSection, editSection, getOneSection, getSection, getSectionItemList, getSectionList, renameSection } from '../controller/sectionController';
import { generateResponse } from '../utils/responseGenerate';
export const sectionRouter = express.Router();

let accessValidation : any;

async function userValidator(req: Request, res: Response, next: NextFunction){
    if((req as any).firebaseData.uid.includes("orgOwner")){
        return next();
    }
    else if((req as any).firebaseData.uid.includes("orgAd")){
        accessValidation = "PM";
        userAccess(accessValidation) (req, res, next);
    }
    else{
        res.status(404).json(generateResponse("Invalid User", 401, "Failed"));
    }
}

sectionRouter.post("/create", firebaseValidation, productMgmt, userValidator, createSection);
sectionRouter.put("/edit/:id", firebaseValidation, productMgmt, userValidator, editSection);
sectionRouter.put("/delete/:id", firebaseValidation, productMgmt, userValidator, deleteSection);
sectionRouter.get("/any/:id", firebaseValidation, productMgmt, userValidator, getOneSection);
sectionRouter.get("/all", firebaseValidation, productMgmt, userValidator, getSection);
sectionRouter.get('/list', firebaseValidation, getSectionList);
sectionRouter.get('/itemList/:sectionId', firebaseValidation, getSectionItemList);
sectionRouter.get('/rename/:id', firebaseValidation, productMgmt, userValidator, renameSection);
