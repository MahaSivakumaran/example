import express from 'express';
import { Request, Response, NextFunction } from 'express';
import { productMgmt } from "../middleware/userValidation";
import { userAccess } from "../middleware/userAccessValidation";
import { firebaseValidation } from "../middleware/firebaseValidation";
import { allProdNamesForGrp, allProductsName, createProduct, deleteProduct, editProduct, productDetails, getProductPrice, productQtyPriceCal, productReportList } from '../controller/productController';
import { generateResponse } from '../utils/responseGenerate';
export const productRouter = express.Router();

let accessValidation : any;

async function userValidator(req: Request, res: Response, next: NextFunction){
    if((req as any).firebaseData.uid.includes("orgOwner")){
        return next();
    }
    else if((req as any).firebaseData.uid.includes("orgAd")){
        accessValidation = "PM";
        userAccess(accessValidation) (req, res, next);
    }
    else{
        res.status(404).json(generateResponse("Invalid User", 401, "Failed"));
    }
}

productRouter.post("/create", firebaseValidation, productMgmt, userValidator, createProduct)
productRouter.get("/details/:orgId", firebaseValidation, productMgmt, userValidator, productDetails)
productRouter.put("/edit/:id", firebaseValidation, productMgmt, userValidator, editProduct)
productRouter.put("/delete/:procedureId", firebaseValidation, productMgmt, userValidator, deleteProduct)
productRouter.get("/allProdNameList/:orgId", firebaseValidation, allProductsName)
productRouter.get("/prodNames/group", firebaseValidation, allProdNamesForGrp)
productRouter.get("/getPrice/:procedureId",getProductPrice) // S to S from Orders & demand service
productRouter.post("/proc/price",productQtyPriceCal) // S to S from Orders & demand service
productRouter.get("/list", productReportList)