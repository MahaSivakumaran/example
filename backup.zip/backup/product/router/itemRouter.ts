import express from 'express';
import { Request, Response, NextFunction } from 'express';
import { inventoryMgmt } from "../middleware/userValidation";
import { userAccess } from "../middleware/userAccessValidation";
import { firebaseValidation } from "../middleware/firebaseValidation";
import { alertGuser, alertList, createItem, deleteItem, editItem, getItem, getSupplier, listItem } from "../controller/itemController";
import { generateResponse } from '../utils/responseGenerate';

let accessValidation : any;

async function userValidator(req: Request, res: Response, next: NextFunction){
    if((req as any).firebaseData.uid.includes("orgOwner")){
        return next();
    }
    else if((req as any).firebaseData.uid.includes("gUser")){
        return next();
    }
    else if((req as any).firebaseData.uid.includes("orgAd")){
        accessValidation = "PM";
        userAccess(accessValidation) (req, res, next);
    }
    else{
        res.status(401).json(generateResponse("Invalid User", 401, "Failed"));
    }
}
async function adminValidator(req: Request, res: Response, next: NextFunction)
{
    if((req as any).firebaseData.uid.includes("orgOwner")){
        return next();
    }
    else if((req as any).firebaseData.uid.includes("orgAd")){
        accessValidation = "PM";
        userAccess(accessValidation) (req, res, next);
    }
    else{
        res.status(401).json(generateResponse("Invalid User", 401, "Failed"));
    }
}

export const itemRouter = express.Router();

itemRouter.post('/create', firebaseValidation, inventoryMgmt, userValidator, createItem);
itemRouter.post('/edit/:id', firebaseValidation, inventoryMgmt, userValidator, editItem);
itemRouter.get('/any/:id', firebaseValidation, inventoryMgmt, userValidator, getItem);
itemRouter.put('/delete/:id', firebaseValidation, inventoryMgmt, userValidator, deleteItem);
itemRouter.get('/list', firebaseValidation, inventoryMgmt, userValidator, listItem);
itemRouter.get('/getSupplier/:id', firebaseValidation, inventoryMgmt, userValidator, getSupplier);
itemRouter.get('/alertList', firebaseValidation, inventoryMgmt, userValidator, alertList);
itemRouter.put('/alertStore/:id', firebaseValidation, inventoryMgmt, adminValidator, alertGuser);