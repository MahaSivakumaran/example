import express from 'express';
import { initializeProcedureId } from '../utils/procedureIdGenerate';
import { productQuantity } from '../controller/productController';
import { addQty, currentQty, removeOneQty, removeQty, validateSupplier } from '../controller/itemController';
export const productServicesRouter = express.Router();

productServicesRouter.post("/createProductId", initializeProcedureId); // S to S from Organisation service
productServicesRouter.post("/getProductQuantity", productQuantity);
productServicesRouter.put('/itemSupplierValidate', validateSupplier); // S to S from Orders & demand service
productServicesRouter.put('/addItemQty', addQty); // S to S from Orders & demand service
productServicesRouter.put('/removeItemQty', removeQty); // S to S from Orders & demand service
productServicesRouter.put('/removeOneItemQty', removeOneQty); // S to S from Orders & demand service
productServicesRouter.get('/item/getCurrentQty/:id', currentQty); // S to S from Orders & demand service