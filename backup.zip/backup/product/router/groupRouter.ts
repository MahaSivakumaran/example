import express from 'express';
import { Request, Response, NextFunction } from 'express';
import { productMgmt } from "../middleware/userValidation";
import { userAccess } from "../middleware/userAccessValidation";
import { firebaseValidation } from "../middleware/firebaseValidation";
import { createGroup, deleteGroup, editGroup, getGroup, grpDetails, prodAndGrpNamesForPackage } from '../controller/groupController';
import { generateResponse } from '../utils/responseGenerate';
export const groupRouter = express.Router();

let accessValidation : any;

async function userValidator(req: Request, res: Response, next: NextFunction){
    if((req as any).firebaseData.uid.includes("orgOwner")){
        return next();
    }
    else if((req as any).firebaseData.uid.includes("orgAd")){
        accessValidation = "PM";
        userAccess(accessValidation) (req, res, next);
    }
    else{
        res.status(404).json(generateResponse("Invalid User", 401, "Failed"));
    }
}

groupRouter.post("/create", firebaseValidation, productMgmt, userValidator, createGroup);
groupRouter.put("/edit/:id", firebaseValidation, productMgmt, userValidator, editGroup);
groupRouter.put("/delete/:id", firebaseValidation, productMgmt, userValidator, deleteGroup);
groupRouter.get("/all", firebaseValidation, productMgmt, userValidator, getGroup);
groupRouter.get("/prodAndGrp/package", firebaseValidation, productMgmt, userValidator, prodAndGrpNamesForPackage);
groupRouter.get("/any/:id", firebaseValidation, productMgmt, userValidator, grpDetails);
