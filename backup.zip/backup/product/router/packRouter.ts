import express from 'express';
import { Request, Response, NextFunction } from 'express';
import { productMgmt } from "../middleware/userValidation";
import { userAccess } from "../middleware/userAccessValidation";
import { firebaseValidation } from "../middleware/firebaseValidation";
import { anyPack, createPack, deletePack, editPackage, getPack, packageHeadCountCal } from '../controller/packController';
import { generateResponse } from '../utils/responseGenerate';
export const packRouter = express.Router();

let accessValidation : any;

async function userValidator(req: Request, res: Response, next: NextFunction){
    if((req as any).firebaseData.uid.includes("orgOwner")){
        return next();
    }
    else if((req as any).firebaseData.uid.includes("orgAd")){
        accessValidation = "PM";
        userAccess(accessValidation) (req, res, next);
    }
    else{
        res.status(404).json(generateResponse("Invalid User", 401, "Failed"));
    }
}

packRouter.post("/create", firebaseValidation, productMgmt, userValidator, createPack);
packRouter.put("/edit/:id", firebaseValidation, productMgmt, userValidator, editPackage);
packRouter.put("/delete/:id", firebaseValidation, productMgmt, userValidator, deletePack);
packRouter.get("/all", firebaseValidation, productMgmt, userValidator, getPack);
packRouter.get("/any/:id", firebaseValidation, productMgmt, userValidator, anyPack);
packRouter.get("/head/count/:id", firebaseValidation, packageHeadCountCal);