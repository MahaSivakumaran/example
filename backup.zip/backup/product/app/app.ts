import * as dotenv from 'dotenv';
import bodyParser from 'body-parser';
import { databaseConnection } from './db';
import express, { Application } from 'express';
import swaggerUi from 'swagger-ui-express';
import * as YAML from 'yamljs';
import path from 'path';
var cors = require("cors");
import httpContext from 'express-http-context';
dotenv.config();
import { initializeGroupId } from '../utils/groupIdGenerate';
import { initializeItemId } from '../utils/itemIdGenerate';
import { initializePackId } from '../utils/packIdGenerate';
import { initializeProductId } from '../utils/productIdGenerate';
import { initializeSectionId } from '../utils/sectionIdGenerate';
import { itemRouter } from '../router/itemRouter';
import { itemInstance } from '../controller/itemController';
import { productRouter } from '../router/productRouter';
import { productInstance } from '../controller/productController';
import { sectionRouter } from '../router/sectionRouter';
import { sectionInstance } from '../controller/sectionController';
import { groupInstance } from '../controller/groupController';
import { groupRouter } from '../router/groupRouter';
import { packInstance } from '../controller/packController';
import { packRouter } from '../router/packRouter';
import { productServicesRouter } from '../router/productServices';

const swaggerDocument = YAML.load(
  path.join(__dirname, "../config/swagger.yaml")
);
export const app: Application = express();
app.use("/api-docs", swaggerUi.serve, swaggerUi.setup(swaggerDocument));
dotenv.config();
databaseConnection()
.then(async()=>{
    await initializeGroupId();
    await initializeItemId();
    await initializePackId();
    await initializeProductId();
    await initializeSectionId();
    await itemInstance();
    await productInstance();
    await sectionInstance();
    await groupInstance();
    await packInstance();
})
.catch((err)=>{
    console.log(err)
});

const { PORT } = process.env;

app.use(express.json());
app.use(bodyParser.json());
app.use(httpContext.middleware);
app.use(cors());

app.use("/api/product",productRouter)
app.use("/api/section",sectionRouter)
app.use('/api/item',itemRouter);
app.use('/api/group',groupRouter);
app.use('/api/pack',packRouter);
app.use("/api/productServices", productServicesRouter);

app.listen(PORT,()=>{
    console.log(`Server connected to the PORT : ${PORT}`)
})

