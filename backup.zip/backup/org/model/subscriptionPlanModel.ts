import { databaseConnection } from "../app/db";

export async function subscriptionPlan() {
  try {
    const db = await databaseConnection();
    const collection = await db?.collection("subscriptionPlan", {
      validator: {
        $jsonSchema: {
          bsonType: "object",
          title: "subscriptionPlan",
          properties: {
            _id:{
                bsonType : 'string'
            },
            planName:{
                bsonType:'string'
            },
            amount: {
              bsonType: 'double',
            },
            period: {
              bsonType: 'string',
            },
            features: {
              bsonType: 'array',
              items:{
                bsonType: 'string'
              }
            },
            type: {
              bsonType: 'string',
            },
            isDeleted: {
              bsonType: 'bool',
              default: false,
            },
            createdAt: {
              bsonType: 'date',
              default: Date.now
            },
            updatedAt: {
              bsonType: 'date',
              default: Date.now
            },
          },
          required: ["planName", "amount", "period"],
        },
      },
    });
    return collection;
  } catch (err) {
    throw err;
  }
}