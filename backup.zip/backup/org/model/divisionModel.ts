import { databaseConnection } from '../app/db';

export async function division() {
  try {
    const db = await databaseConnection();
    const collection = await db?.collection('division', {
      validator: {
        $jsonSchema: {
          bsonType: 'object',
          title: 'division',
          properties: {
            _id:{
                bsonType : 'string'
            },
            divId:{
              bsonType: 'string'
            },
            orgId:{
                bsonType:'string'
            },
            divName: {
              bsonType: 'string',

            },
            fssai: {
              bsonType: 'string'

            },
            isMain:{
              bsonType : 'bool'
            },
            shift: {
              bsonType: 'array',

              items: {
                bsonType: 'object',

                properties: {
                  shiftId: {
                    bsonType: 'string',

                  },
                  from: {
                    bsonType: 'string',
                    
                  },
                  to: {
                    bsonType: 'string',
                    
                  },
                  shiftNo:{
                    bsonType: 'int',
                  }
                },
                required: ['shiftId', 'shiftNo', 'from', 'to'],
              },
            },
            isDeleted: {
              bsonType: 'bool'

            },
            createdAt: {
              bsonType: 'date',
              default: Date.now
            },
            updatedAt: {
              bsonType: 'date',
              default: Date.now
            },
          },
          required: ['divName','shift','fssai'],
        },
      },
    });
    return collection;
  } catch (err) {
    throw err;
  }
}