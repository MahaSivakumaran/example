import { databaseConnection } from '../app/db';

export async function orgIdModel() {
    try {
      const db = await databaseConnection();
      const collection = await db?.collection('organisationId', {
        validator: {
          $jsonSchema: {
            bsonType: 'object',
            title: 'organisation Id',
            properties: {
              orgId:{
                  bsonType : 'int'
              },
            },
          },
        },
      });
      return collection;
    } catch (err) {
      throw err;
    }
  }