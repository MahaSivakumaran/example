import { databaseConnection } from '../app/db';

export async function organisation() {
  try {
    const db = await databaseConnection();
    const collection = await db?.collection('organisation', {
      validator: {
        $jsonSchema: {
          bsonType: 'object',
          title: 'organisation',
          properties: {
            _id: {
              bsonType: 'string',
            },
            orgName: {
              bsonType: 'string',
            },
            gst: {
              bsonType: 'string',
            },
            logoUrl: {
              bsonType: 'string',
            },
            entity:{
              bsonType: 'string'
            },
            isDeleted: {
              bsonType: 'bool'
            },
            subscription: {
              bsonType: 'object',
              properties: {
                planId:{
                  bsonType : 'string'  
                },
                planName:{
                  bsonType: 'string'
                },
                type: {
                  bsonType: 'string'
                },
                features:{
                  bsonType: 'array',
                  items:{
                    bsonType: 'string'
                  }
                },
                period: {
                  bsonType: 'string'
                },
                amount: {
                  bsonType: 'string'
                },
                isExpired: {
                  bsonType: 'bool'
                },
                subscribedDate: {
                  bsonType: 'string'
                },
                expiryDate: {
                  bsonType: 'string'
                },
                isUnSubscribed: {
                  bsonType: 'bool'
                },
              }
            },
            isActive: {
              bsonType: 'bool'
            },
            createdAt: {
              bsonType: 'date',
            },
            updatedAt: {
              bsonType: 'date',
            },
          },
          required: ['orgName','gst'],
        },
      },
    });
    return collection;
  } catch (err) {
    throw err;
  }
}