import { databaseConnection } from '../app/db';

export async function shiftIdModel() {
    try {
      const db = await databaseConnection();
      const collection = await db?.collection('shiftId', {
        validator: {
          $jsonSchema: {
            bsonType: 'object',
            title: 'shift Id',
            properties: {
                divId:{
                    bsonType: 'string'
                },
                shiftId:{
                    bsonType : 'int'
                },
            },
          },
        },
      });
      return collection;
    } catch (err) {
      throw err;
    }
  }