import { databaseConnection } from '../app/db';

export async function subsIdModel() {
    try {
      const db = await databaseConnection();
      const collection = await db?.collection('subscriptionId', {
        validator: {
          $jsonSchema: {
            bsonType: 'object',
            title: 'subscription Id',
            properties: {
              subsId:{
                  bsonType : 'int'
              },
            },
          },
        },
      });
      return collection;
    } catch (err) {
      throw err;
    }
  }