import { databaseConnection } from '../app/db';

export async function divIdModel() {
    try {
      const db = await databaseConnection();
      const collection = await db?.collection('divisionId', {
        validator: {
          $jsonSchema: {
            bsonType: 'object',
            title: 'division Id',
            properties: {
              divId:{
                  bsonType : 'int'
              },
            },
          },
        },
      });
      return collection;
    } catch (err) {
      throw err;
    }
  }