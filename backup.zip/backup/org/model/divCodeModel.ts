import { databaseConnection } from '../app/db';

export async function divCodeModel() {
    try {
      const db = await databaseConnection();
      const collection = await db?.collection('divisionCode', {
        validator: {
          $jsonSchema: {
            bsonType: 'object',
            title: 'division Code',
            properties: {
              orgId: {
                bsonType: 'string'
              },
              divCode:{
                  bsonType : 'string'
              },
              count: {
                bsonType: 'int'
              }
            },
          },
        },
      });
      return collection;
    } catch (err) {
      throw err;
    }
  }