import * as dotenv from 'dotenv';
import bodyParser from 'body-parser';
import { databaseConnection } from './db';
import express, { Application } from 'express';
import swaggerUi from 'swagger-ui-express';
import * as YAML from 'yamljs';
import path from 'path';
import httpContext from 'express-http-context';
var cors = require("cors");
dotenv.config();
import { orgRouter } from '../router/orgRouter';
import {divRouter} from '../router/divisionRouter';
import { orgInstance } from '../controller/organisationController';
import { divInstance } from '../controller/divisionController';
import { createOrgCount } from '../utils/orgIdGenerate';
import { createDivCount } from '../utils/divIdGenerate';
import { createSubsCount } from '../utils/subsIdgenerate';
import { subscriptionPlanRouter } from "../router/subscriptionPlan";
import { subscriptionInstance } from "../controller/subscriptionPlanController";


const swaggerDocument = YAML.load(
  path.join(__dirname, "../config/swagger.yaml")
);
export const app: Application = express();
app.use("/api-docs", swaggerUi.serve, swaggerUi.setup(swaggerDocument));
databaseConnection()
.then(()=>{
    createOrgCount(),
    createDivCount(),
    createSubsCount(),
    orgInstance();
    divInstance();
    subscriptionInstance();
})
.catch((err)=>{
    console.log(err)
});

const { PORT } = process.env;

app.use(express.json());
app.use(bodyParser.json());
app.use(httpContext.middleware);
app.use(cors());


app.listen(PORT,()=>{
    console.log(`Server connected to the PORT : ${PORT}`)
})
app.use("/api/org", orgRouter);
app.use("/api/div",divRouter);
app.use("/api/subscription", subscriptionPlanRouter);
