import { Request, Response, NextFunction } from "express";
import { info, error } from "../config/loggerConfig";

export function userMgmt(req: Request, res: Response, next: NextFunction) {
    if ((req as any).firebaseData.uid.includes("pa") || (req as any).firebaseData.uid.includes("orgOwner") || (req as any).firebaseData.uid.includes("orgAd") || (req as any).firebaseData.uid.includes("divM") || (req as any).firebaseData.uid.includes("divS")) {
        info.info("userMgmt access passed");
        next();
    }
    else {
        error.error("userMgmt access failed")
        return res.status(401).send({
            success: false,
            message: "Unathorised"
        })
    }
}

export function subMgmt(req: Request, res: Response, next: NextFunction) {
    if ((req as any).firebaseData.uid.includes("pa") || (req as any).firebaseData.uid.includes("orgOwner")) {
        info.info("subMgmt access passed");
        next();
    }
    else {
        error.error("subMgmt access failed")
        return res.status(401).send({
            success: false,
            message: "Unathorised"
        })
    }
}

export function orgMgmt(req: Request, res: Response, next: NextFunction) {
    if ((req as any).firebaseData.uid.includes("pa") || (req as any).firebaseData.uid.includes("orgOwner")) {
        info.info("orgMgmt access passed");
        next();
    }
    else {
        error.error("orgMgmt access failed")
        return res.status(401).send({
            success: false,
            message: "Unathorised"
        })
    }
}

export function divMgmt(req: Request, res: Response, next: NextFunction) {
    if ((req as any).firebaseData.uid.includes("pa") || (req as any).firebaseData.uid.includes("orgOwner") || (req as any).firebaseData.uid.includes("orgAd")) {
        info.info("divMgmt access passed");
        next();
    }
    else {
        error.error("divMgmt access failed")
        return res.status(401).send({
            success: false,
            message: "Unathorised"
        })
    }
}

export function reportMgmt(req: Request, res: Response, next: NextFunction) {
    if ((req as any).firebaseData.uid.includes("orgOwner") || (req as any).firebaseData.uid.includes("orgAd")) {
        info.info("reportMgmt access passed");
        next();
    }
    else {
        error.error("reportMgmt access failed")
        return res.status(401).send({
            success: false,
            message: "Unathorised"
        })
    }
}

export function inventoryMgmt(req: Request, res: Response, next: NextFunction) {
    if ((req as any).firebaseData.uid.includes("orgOwner") || (req as any).firebaseData.uid.includes("orgAd") || (req as any).firebaseData.uid.includes("gUser")) {
        info.info("inventoryMgmt access passed");
        next();
    }
    else {
        error.error("inventoryMgmt access failed")
        return res.status(401).send({
            success: false,
            message: "Unathorised"
        })
    }
}

export function demandMgmt(req: Request, res: Response, next: NextFunction) {
    if ((req as any).firebaseData.uid.includes("orgOwner") || (req as any).firebaseData.uid.includes("orgAd") || (req as any).firebaseData.uid.includes("divM") || (req as any).firebaseData.uid.includes("divS")) {
        info.info("demandMgmt access passed");
        next();
    }
    else {
        error.error("demandMgmt access failed")
        return res.status(401).send({
            success: false,
            message: "Unathorised"
        })
    }
}

export function approvalMgmt(req: Request, res: Response, next: NextFunction) {
    if ((req as any).firebaseData.uid.includes("orgOwner") || (req as any).firebaseData.uid.includes("orgAd")) {
        info.info("approvalMgmt access passed");
        next();
    }
    else {
        error.error("approvalMgmt access failed")
        return res.status(401).send({
            success: false,
            message: "Unathorised"
        })
    }
}

export function loadInMgmt(req: Request, res: Response, next: NextFunction) {
    if ((req as any).firebaseData.uid.includes("gUser") || (req as any).firebaseData.uid.includes("tUser")) {
        info.info("loadInMgmt access passed");
        next();
    }
    else {
        error.error("loadInMgmt access failed")
        return res.status(401).send({
            success: false,
            message: "Unathorised"
        })
    }
}

export function loadOutMgmt(req: Request, res: Response, next: NextFunction) {
    if ((req as any).firebaseData.uid.includes("tUser")) {
        info.info("loadOutMgmt access passed");
        next();
    }
    else {
        error.error("loadOutMgmt access failed")
        return res.status(401).send({
            success: false,
            message: "Unathorised"
        })
    }
}