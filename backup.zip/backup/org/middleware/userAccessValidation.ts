import { Request, Response, NextFunction } from "express";
import { info, error } from "../config/loggerConfig";
import { uniqueId } from "../lib/loggerSyncId";
import httpContext from 'express-http-context';

export const userAccess = (requiredAccess: any) => {
    return async (req: Request, res: Response, next: NextFunction) => {

        httpContext.set("x_user_id", (req as any).firebaseData.uid);
        httpContext.set("x_api_name", req.originalUrl);
        httpContext.set('x_txn_id', await uniqueId());
        info.info("useraccess called")
        let accessObj = (req as any).firebaseData.customClaims.access;
        let check = 0;
        if(accessObj){
        if(accessObj.length > 0){
        for(let outerObj of accessObj)
        {
            if(outerObj.access)
            {
                for(let innerObj of outerObj.access )
                {
                    if(innerObj.title == requiredAccess && innerObj.isAllowed == true)
                    {
                        check+=1;
                    }
                }
            }
            else{
                if(outerObj.title == requiredAccess && outerObj.isAllowed == true)
                    {
                        check+=1;
                    }
            }
        }
        }
        }
        else{
            if((req as any).firebaseData.uid.includes("orgOwner"))
            {
            return next();
            }
            else{
                return res.status(401).send({
                    message: "Unauthorized user",
                    status: "Failed"
                });
            }
        }
        if (!check) {
            return res.status(401).send({
                success: false,
                message: "Access Denied"
            })
        }
        else {
            next()
        }
    };
};
