import { Request, Response, NextFunction } from "express";
import { info, error } from "../config/loggerConfig";
let pack = require('firebasepackage');

export async function firebaseValidation(req: Request, res: Response, next: NextFunction) {
    info.info("firebaseValidation called");
    const userToken = req.headers['sso-token'];
    if(!userToken)
    {
        error.error(`firebaseValidation error- Missing sso-token`);
        return res.status(400).send({
            success: false,
            message: "Missing authorization token"
        });
    }
    await pack.verifyUser(req, res);
    const orgId = req.query.orgId ? req.query.orgId : null;
    if (req.body.firebaseVerify) {
        if ((req as any).firebaseData.uid.includes("pa") || (req as any).firebaseData.uid.includes("orgOwner") ) {
            info.info("firebaseValidation passed");
            next();
        }
        else if ((req as any).firebaseData.customClaims.orgId === orgId) {
            info.info("firebaseValidation passed");
            next();
        }
        else {
            error.error("firebaseValidation invalid orgId");
            return res.status(403).send({
                success: false,
                message: "Invalid organisaiton ID"
            })
        }
    }
    else {
        error.error('firebaseValidation failed');
        return;
    }
}