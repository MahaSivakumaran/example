import { info, error } from "../config/loggerConfig";
import { shiftIdModel } from "../model/shiftIdModel";


export async function addShiftIdCount(divId: any) {

    try {
        let collection = await shiftIdModel();
        const shiftIdRes = await collection.findOne({divId});
        let shiftId: number;
        if(shiftIdRes === null){
            await collection.insertOne({
                divId,
                shiftId: 100
            });
            shiftId = 100;
            }
        else{
            shiftId = shiftIdRes.shiftId + 1;
        await collection.findOneAndUpdate({ divId }, {
            $set: {shiftId}
          },
            {
              new: true
            });
        }
        return shiftId;
    }
    catch (err) {
        error.error(`addDivCode error:${err}`);
        return
    }
}