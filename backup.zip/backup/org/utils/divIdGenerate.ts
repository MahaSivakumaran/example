import {divIdModel } from "../model/divIdModel";
import { info, error } from "../config/loggerConfig";

export async function createDivCount() {
    try {
        var collection = await divIdModel();
        let data = await collection.findOne();
        if (data === null) {
            console.log("inside div")
            const collection = await divIdModel();
            await collection.insertOne({
              divId:1000,
            });
            info.info(`createDivCount created successfully`);
        }
    }
    catch (err: any) {
        error.error(`createDivCount errorMessage:${err}`);
    }
}

export async function addDivId() {

    try {
        let collection = await divIdModel();
        let list = await collection.find({}).toArray();
        let id = list[0]._id;
        let divId = list[0].divId + 1;
        await collection.findOneAndUpdate({ _id: id }, {
            $set: { divId}
        },
            {
                new: true
            });
        divId = "div_" + divId;
        return divId;
    }
    catch (err) {
        error.error(`createDivID error:${err}`);
        return false;
    }
}