export async function searchAndPaginate(collection:any, query:any, page:any, sortBy:any, sortColumn:any ,pageSize : any) {
    let skip = 0;
    const searchFilter = {
        isDeleted: false,
        ...(query ? {
            $or: [
                { planName: { $regex: query, $options: 'i' } },
                { type: { $regex: query, $options: 'i' } },
                { amount: { $regex: query, $options: 'i' } },
                { period: { $regex: query, $options: 'i' } },
                {divName: { $regex: query, $options: 'i' }},
                {divId: { $regex: query, $options: 'i' }},
                {orgName: { $regex: query, $options: 'i' }},
                { orgId: { $regex: query, $options: 'i' }}
            ],
        } : {}),
    };

    const currentPage = parseInt(page) || 1;
    const page_Size = parseInt(pageSize as string,10) || 10;
    skip = (currentPage - 1) * page_Size;

    const sortOptions:any = {};
    const sortOrder = ( sortBy === "desc" ? -1 : 1);
    if (sortColumn === 'planName' || sortColumn === 'type' || sortColumn === 'amount' || sortColumn === 'period'  || sortColumn === 'divName'  || sortColumn === 'orgName' ) {
        sortOptions[sortColumn] = sortOrder;
    }

    sortOptions['createdAt'] = 1; 

    const projection = {
        _id: 1,
        planName: 1,
        features: 1,
        type: 1,
        amount: 1,
        period: 1,
        divName: 1,
        divId: 1,
        orgName: 1,
        shift: 1,
        fssai: 1,
        gst: 1,
        planId: 1,
        entity: 1,
        isMain: 1,
        orgId: 1
    };

   
    const aggregatePipeline = [
        { $match: searchFilter },
        { $sort: sortOptions },
        {
            $facet: {
                metadata: [
                    { $skip: skip },
                    { $limit: page_Size },
                    { $project: projection },
                ],
                totalCount: [
                    { $count: 'value' },
                ],
            },
        },
        { $unwind: '$totalCount' },
    ];
    const results = await collection.aggregate(aggregatePipeline).toArray();
    const result = results[0].metadata || [];
    const count = results[0].totalCount ? results[0].totalCount.value : 0;
    return {
        totalCount: count,
        result,
    };
}
