import {subsIdModel } from "../model/subsIdModel";
import { info, error } from "../config/loggerConfig";

export async function createSubsCount() {
    try {
        var collection = await subsIdModel();
        let data = await collection.findOne();
        if (data === null) {
            const collection = await subsIdModel();
            await collection.insertOne({
              subsId:1000,
            });
            info.info(`createSubsCount created successfully`);
        }
    }
    catch (err: any) {
        error.error(`createSubsCount errorMessage:${err}`);
    }
}

export async function addSubsId() {

    try {
        let collection = await subsIdModel();
        let list = await collection.find({}).toArray();
        let id = list[0]._id;
        let subsId = list[0].subsId + 1;
        await collection.findOneAndUpdate({ _id: id }, {
            $set: { subsId}
        },
            {
                new: true
            });
        subsId = "subs_" + subsId;
        return subsId;
    }
    catch (err) {
        error.error(`createSubsID error:${err}`);
        return false;
    }
}