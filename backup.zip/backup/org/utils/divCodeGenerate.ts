import { info, error } from "../config/loggerConfig";
import { divCodeModel } from "../model/divCodeModel";


export async function createDivCode(orgId: string , code: string) {

    try {
        let collection = await divCodeModel();
        await collection.insertOne({
            orgId: orgId,
            divCode: code,
            count: 0
        });
        console.log(orgId, code);
        return
    }
    catch (err) {
        error.error(`createDivID error:${err}`);
        return
    }
}

export async function addDivCodeCount(orgId: string) {

    try {
        let collection = await divCodeModel();
        const divCodeRes = await collection.findOne({orgId},{
            count: 1,
            divCode: 1
        });
        const count = divCodeRes.count + 1;
        const divCode = divCodeRes.divCode;
        await collection.findOneAndUpdate({ orgId }, {
            $set: {count}
          },
            {
              new: true
            });
        return {count, divCode};
    }
    catch (err) {
        error.error(`addDivCode error:${err}`);
        return
    }
}

export async function checkDuplicateDivCode(divCode: string){
    try{
        info.info(`checkDuplicateDivCode divCode:${divCode} initiated`);
        let collection = await divCodeModel();
        const divData = await collection.find({divCode: divCode+'B'}, {divCode: 1}).toArray();
        if(divData.length < 1)
        {
            return divCode;
        }
        else{
            let divCodes = divData.map((div: any) => div.divCode);
            let index = 0;
            while (divCodes.includes(divCode+'B')){
                divCode = divCode + String.fromCharCode(65 + index);
                index++;
                if (index > 25) {
                    error.error(`checkDuplicateDivCode error:index>25`);
                    return false
                }
                }
            return divCode;
        }
    }
    catch (err) {
        error.error(`checkDuplicateDivCode error:${err}`);
        return false;
    }
}