import {orgIdModel } from "../model/orgIdModel";
import { info, error } from "../config/loggerConfig";

export async function createOrgCount() {
    try {
        var collection = await orgIdModel();
        let data = await collection.findOne();
        if (data === null) {
            console.log("inside org")
            const collection = await orgIdModel();
            await collection.insertOne({
              orgId:1000,
            });
            info.info(`createOrgCount created successfully`);
        }
    }
    catch (err: any) {
        error.error(`createOrgCount errorMessage:${err}`);
    }
}

export async function addOrgId() {

    try {
        let collection = await orgIdModel();
        let list = await collection.find({}).toArray();
        let id = list[0]._id;
        let orgId = list[0].orgId + 1;
        await collection.findOneAndUpdate({ _id: id }, {
            $set: { orgId}
        },
            {
                new: true
            });
        orgId = "org_" + orgId;
        return orgId;
    }
    catch (err) {
        error.error(`createOrgID error:${err}`);
        return false;
    }
}