import { Request, Response } from 'express';
import { organisation } from "../model/organsationModel";
import { deleteAllDiv, divCreate } from './divisionController';
import { addOrgId } from '../utils/orgIdGenerate';
import { checkDuplicateDivCode, createDivCode } from '../utils/divCodeGenerate';
import { generateResponse } from '../utils/responseGenerate';
import { error, info } from '../config/loggerConfig';
import moment from 'moment';
import { getSubsPlan } from './subscriptionPlanController';
const schedule = require('node-schedule');

const axios = require('axios');
const aws = require('aws-sdk');

const currentDate: moment.Moment = moment();

let collection: any;
const baseURL = process.env.BASE_URL;
const userPort = process.env.USER_PORT;
const productPort = process.env.PRODUCT_PORT;
export const orgInstance = async () => {
  collection = await organisation()
}

async function s3ImageUpload (fileName: any)
{
  let s3bucket = await new aws.S3({
  accessKeyId: process.env.S3_ACCESS_KEY_ID,
  secretAccessKey: process.env.S3_SECRET_ACCESS_KEY,
  region: process.env.S3_BUCKET_REGION,
  });
 
  const expires = 300;
 
  const signedUrl = await s3bucket.getSignedUrl("putObject", {
    Bucket: process.env.S3_BUCKET_NAME,
    Key: fileName,
    Expires: expires,
    ContentType: "image/*",
  });
 
  const accessUrl = `https://s3.${process.env.S3_BUCKET_REGION}.amazonaws.com/${process.env.S3_BUCKET_NAME}/${fileName}`;
 
  return {signedUrl, accessUrl};
}

async function s3ImageDelete (accessUrl: any)
{
  return new Promise((resolve, reject) =>{
  let s3bucket = new aws.S3({
    accessKeyId: process.env.S3_ACCESS_KEY_ID,
    secretAccessKey: process.env.S3_SECRET_ACCESS_KEY,
    region: process.env.S3_BUCKET_REGION,
    });
 
  const params = {
    Bucket: process.env.S3_BUCKET_NAME,
    Key: accessUrl
  };
 
  s3bucket.deleteObject(params, (err: any, data: any) => {
    if (err) {
      error.error(`s3ImageDelete error:${JSON.stringify(err)}`);
      resolve(true);  
    } else {
      info.info(`s3ImageDelete deleted successfully data:${JSON.stringify(data)}`);
      reject(false);
    }
  });
  });
}

export async function orgCreate(req: Request, res: Response) {
  info.info(`orgCreate initiated req.body:${JSON.stringify(req.body)}`);
  const { name, gst, entity } = req.body.org;
  try {
    const { planId } = req.body.subscriptionPlan;
    info.info(`orgCreate initiated req.body.org:${JSON.stringify(req.body.org)}`);
    info.info(`orgCreate name:${name} req.body.subscriptionPlan:${JSON.stringify(req.body.subscriptionPlan)}`);
    info.info(`orgCreate name:${name} req.body.division:${JSON.stringify(req.body.division)}`);
    info.info(`orgCreate name:${name} req.body.orgOwner:${JSON.stringify(req.body.orgOwner)}`);

    if(!name)
    {
      error.error(`orgCreate error: missing org name`);
      return res.status(400).json(generateResponse("Missing company name", 400, "failed"));
    }
    else if(!gst)
    {
      error.error(`orgCreate name:${name} error: missing gst`);
      return res.status(400).json(generateResponse("Missing GST number", 400, "failed"));
    }
    else if(!planId)
    {
      error.error(`orgCreate name:${name} error: missing planId`);
      return res.status(400).json(generateResponse("Missing subscription plan", 400, "failed"));
    }
    else if(!req.body.division)
    {
      error.error(`orgCreate name:${name} error: missing division details`);
      return res.status(400).json(generateResponse("Missing branch details", 400, "failed"));
    }
    else if(!req.body.orgOwner)
    {
      error.error(`orgCreate name:${name} error: missing orgOwner details`);
      return res.status(400).json(generateResponse("Missing company owner details", 400, "failed"));
    }
    const orgId = await addOrgId();
    info.info(`orgCreate orgName:${name} generated orgId:${orgId}`);

    let orgNameSplit = name.split(' ');
    let orgNameAcronym = '';
    let orgName;
    for (let i = 0; i < orgNameSplit.length; i++) {
      orgName = orgNameSplit[i];
      if (orgName.length > 0) {
        orgNameAcronym += orgName[0].toUpperCase();
      }
    }
    const divCode = await checkDuplicateDivCode(orgNameAcronym);
    info.info(`orgCreate orgId:${orgId} generated divCode:${divCode}`);
    if(!divCode)
    {
      error.error(`orgCreate orgId:${orgId} checkDuplicateDivCode error`);
      return res.status(500).json(generateResponse("Internal server error", 500, "Failed"));
    }
    orgNameAcronym = divCode;

    let check: number = 0;

    let orgAcronym = orgNameAcronym + 'B';
    await createDivCode(orgId, orgAcronym);
    const planData = await getSubsPlan(planId);
    if(!planData)
    {
      error.error(`orgCreate orgId:${orgId} getSubsPlan details not fetched`);
      res.status(500).json(generateResponse("Internal server error", 500, "Failed"));
    }

    let reqBody = {
      orgId,
      procedureCode: orgNameAcronym
    }
    const productApiEndpoint = `http://${baseURL}:${productPort}/api/productServices/createProductId`;
    let productResp = await axios.post(productApiEndpoint, reqBody).then(() => {
      info.info(`orgCreate orgId:${orgId} createProductId S-S success`);
    }).catch(async (err: any) => {
      error.error(`orgCreate orgId:${orgId} createProductId error:${err.message}`);
      check +=1;
      res.status(500).json(await generateResponse("Internal server error", 500, "Failed"))
    })
    if(check)
    {
      return;
    }

    req.body.orgOwner.orgId = orgId;
    const userApiEndpoint = `http://${baseURL}:${userPort}/api/userServices/orgOwner/create`;
    const response = await axios.post(userApiEndpoint, req.body.orgOwner).then(() => {
      info.info(`orgCreate orgId:${orgId} ownerCreate S-S success`);
    }).catch((err: any) => {
      error.error(`orgCreate orgId:${orgId} ownerCreate error:${err.response.data.message} status:${err.response.status}`);
      res.status(err.response.status).json(generateResponse(err.response.data.message, err.response.status, "failed"));
      check +=1;
    });
    if(check){
      return;
    }

    var fileName = `companyLogo/logo-pic-${orgId}.jpg`;
    info.info(`orgCreate orgId:${orgId} generated fileName:${fileName}`);

    let s3Url;
    if(req.body.isLogoUploaded){
    s3Url = await s3ImageUpload(fileName);
    }

    const subscribedDate: string = currentDate.format('YYYY-MM-DD');

    const days = (planData.period == 'Monthly') ? 31 : 365;
    info.info(`orgCreate orgId:${orgId} subscription days:${days}`);
    const expiryDate: string = moment(subscribedDate).add(days, 'days').format('YYYY-MM-DD');
    const orgData = {
      _id: orgId,
      orgName: name,
      gst,
      entity,
      logoUrl: s3Url ? s3Url.accessUrl : null,
      isDeleted: false,
      isActive: true,
      subscription: {
      planId,
      planName: planData.planName,
      type: planData.type,
      features: planData.features,
      period: planData.period,
      ...(planData.amount && {amount: planData.amount}),
      subscribedDate,
      expiryDate,
      isExpired: false,
      isUnSubscribed: false
    },
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    await collection.insertOne(orgData);
    info.info(`createOrg orgId:${orgId} createdData:${JSON.stringify(orgData)}`);
    req.body.division.isMain = true;
    req.body.division.orgId = orgId;
    req.body.division.isSToS = true;
   
    const divResponse = await divCreate(req, res);
    if(divResponse == false)
    {
      error.error(`createOrg orgId:${orgId} error: divCreate`);
      return res.status(500).json(generateResponse("Internal server error", 500, "failed"));
    }
    else if(divResponse == 'missing details')
    {
      error.error(`createOrg orgId:${orgId} error: divCreate missing details`);
      return res.status(400).json(generateResponse("Missing arguments in branch", 400, "failed"));
    }
    else if(divResponse == 'shift similar time')
    {
      error.error(`createOrg orgId:${orgId} error: divCreate shift similar time`);
      return res.status(400).json(generateResponse("Some shift has similar time in branch", 400, "failed"));
    }

      let userResponse = {
        success: true,
        message:'Company created successfully',
        ...(s3Url && {signedUrl: s3Url.signedUrl}),
      }
      res.status(200).send(userResponse);
  } catch (err: any) {
    error.error(`orgCreate name:${name} error:${err.message}`);
    res.status(500).json(await generateResponse("Internal server error",500,"failed"));
  }
}

export async function getOrgDetail(req: Request, res: Response) {
  const { id } = req.params;
  info.info(`getOrgDetail orgId:${id} initiated`);
  try {
    const projection = {
      _id: 1,
      orgName: 1,
      entity: 1,
      planId: 1,
      gst: 1,
      logoUrl: 1,
      isDeleted: 1,
    };

    const org = await collection.findOne({ _id: id }, { projection });
    if (org) {
      if (!org.isDeleted) {
        info.info(`getOrgDetail orgId:${id} success`);
        const response = generateResponse('organisation found', 200, 'success', org)
        res.status(200).json(response);
      }
      else {
        error.error(`getOrgDetail orgId:${id} error: org deleted`);
        const response = generateResponse('organisation not found', 404, 'error')
        res.status(404).json(response);
      }
    } else {
      error.error(`getOrgDetail orgId:${id} error: org not found`);
      const response = generateResponse('organisation not found', 404, 'error')
      res.status(404).json(response);
    }
  } catch (err: any) {
    error.error(`getOrgDetail orgId:${id} error:${err.message}`);
    res.status(500).json(generateResponse("Internal server error", 500, "Failed"));

  }
}

export async function orgEdit (req: Request, res: Response) {
  let { name, gst, isLogoUploaded, isLogoDeleted } = req.body;
  let {id} = req.params;
  info.info(`orgEdit orgId:${id} initiated`);
  if( !name || !gst){
    error.error(`orgEdit orgId:${id} error: Missing company name/gst`);
    return res.status(400).json(generateResponse("Invalid arguments", 400, "Failed"));
  }
  try
  {
    info.info(`orgEdit orgId:${id} req.body:${JSON.stringify(req.body)}`);
 
    let s3Url;
    let fileName = `companyLogo/logo-pic-${id}.jpg`;
    if(isLogoUploaded)
    {
    s3Url = await s3ImageUpload(fileName);
    }
    else if(isLogoDeleted)
    {
      await s3ImageDelete(fileName).then().catch((err)=>{error.error(`ordEdit orgId:${id} AWS s3 error`)});
    }
 
    await collection.findOneAndUpdate({_id:id},
      {
        $set: {
          orgName: name,
          gst,
        ...(isLogoDeleted && {logoUrl: null}),
        ...(isLogoUploaded && {logoUrl: s3Url?.accessUrl}),
        updatedAt: new Date()
        }
      },
      {
        new: true
      });
 
      let response = {
        success: true,
        message: "Company edited successfully",
        ...(s3Url && {signedUrl: s3Url?.signedUrl})
      }
      info.info(`orgEdit orgId:${id} updated data name:${name},gst:${gst},${JSON.stringify({...(isLogoDeleted && {logoUrl: null}),
      ...(isLogoUploaded && {logoUrl: s3Url?.accessUrl})})}`);
      res.status(200).send(response);
  }
  catch(err: any)
  {
    error.error(`orgEdit orgId:${id} error:${err.message}`);
    res.status(500).json(generateResponse('Internal serever error', 500, "Failed"));
  }
}

export async function orgList(req: Request, res: Response) {
  try {
    info.info(`orgList initiated`);
    const projection = {
      _id: 1,
      orgName: 1,
      logoUrl: 1
    };
    const org = await collection.find({ isDeleted: false }).sort({orgName: 1}).project(projection).toArray();
    if (org) {
      info.info(`orgList success`);
      const response = generateResponse('organisation found', 200, 'success', org)
      res.status(200).json(response);
    } else {
      error.error(`orgList org not found`);
      const response = generateResponse('organisation not found', 404, 'error')
      res.status(404).json(response);
    }
  } catch (err: any) {
    error.error(`orgList error:${err.message}`);
    res.status(500).json(generateResponse('Internal server error', 500, "Failed"));
  }
}
export const companyList = async (req: Request, res: Response) => {
  try {
    let page = req.query.page ? parseInt(req.query.page as string, 10) : 1;
    const pageSize = req.query.pageSize ? parseInt(req.query.pageSize as string, 10) : 10;
    const query = req.query.query && req.query.query.toString().trim().length >= 3 ? req.query.query.toString().trim() : '';
    const sortField = req.query.sortField ? req.query.sortField.toString() : 'orgName';
    const sortOrder = req.query.sortOrder === 'desc' ? -1 : 1;
    info.info(`companyList initiated`);
    info.info(`companyList req.query:${JSON.stringify(req.query)}`);
    const result = await collection.aggregate([
      {
        $match: {
          "_id": { $exists: true },
          $or: [
            { "orgName": { $regex: query, $options: 'i' } },
          ],
          "isDeleted": { $eq: false },
        },
      },
      {
        $facet: {
          totalCount: [
            {
              $group: {
                _id: null,
                count: { $sum: 1 },
              },
            },
          ],
          distinctOrgIds: [
            {
              $group: {
                _id: null,
                orgIds: { $addToSet: "$_id" },
              },
            },
          ],
          paginatedData: [
            {
              $lookup: {
                from: "division",
                let: { orgId: "$_id" },
                pipeline: [
                  {
                    $match: {
                      $expr: {
                        $and: [
                          { $eq: ["$orgId", "$$orgId"] },
                          { $eq: ["$isDeleted", false] },
                        ],
                      },
                    },
                  },
                ],
                as: "divisions",
              },
            },
            {
              $unwind: {
                path: "$divisions",
                preserveNullAndEmptyArrays: true,
              },
            },
            {
              $group: {
                _id: {
                  _id: "$_id",
                  orgName: "$orgName",
                  logoUrl: "$logoUrl",
                },
                divisionCount: { $sum: { $cond: [{ $gt: ["$divisions", null] }, 1, 0] } },
                storeCount: {
                  $sum: {
                    $cond: [
                      { $eq: ["$divisions.isMain", true] },
                      1,
                      0,
                    ],
                  },
                },
              },
            },
            {
              $project: {
                _id: "$_id._id",
                orgName: "$_id.orgName",
                logoUrl: "$_id.logoUrl",
                divisionCount: 1,
                storeCount: 1,
              },
            },
            {
              $sort: { [sortField]: sortOrder },
            },
            {
              $skip: (page - 1) * pageSize,
            },
            {
              $limit: pageSize,
            },
          ],
        },
      },
      {
        $unwind: "$totalCount",
      },
      {
        $unwind: "$distinctOrgIds",
      },
    ]).toArray();

    const totalCount = result[0]?.totalCount?.count || 0;
    const orgIds = result[0]?.distinctOrgIds?.orgIds || [];

    const axiosResponse = await axios.post(`http://${process.env.BASE_URL}:${userPort}/api/userServices/org/count`, { orgIds });

    const mergedList = result[0]?.paginatedData?.map((item: any) => {
      const matchingAxiosItem = axiosResponse.data.find((axiosItem: any) => axiosItem.orgId === item._id);
      return {
        _id: item._id,
        logo: item.logoUrl,
        orgName: item.orgName,
        divisionCount: item.divisionCount,
        storeCount: item.storeCount,
        totalUsers: matchingAxiosItem ? matchingAxiosItem.totalUsers : 0,
      };
    }) || [];

    mergedList.sort((a: any, b: any) => {
      if (a[sortField] < b[sortField]) return -sortOrder;
      if (a[sortField] > b[sortField]) return sortOrder;
      return 0;
    });
    const data = {
      totalCount: totalCount,
      list: mergedList,
    };
    info.info(`companyList data fetched successfully`);
    const response = generateResponse("Documents fetched successfully", 200, "success", data);
    res.status(200).json(response);
  } catch (err: any) {
    error.error(`companyList error:${err.message}`);
    res.status(500).json(generateResponse("Internal server error", 500, "Failed"));
  }
};

export const orgDetails = async (req: Request, res: Response) => {

  const { id } = req.params;
  info.info(`orgDetails(S-S) orgId:${id} initiated`);
  const projection = {
    _id: 1,
    gst: 1,
    orgName: 1,
    logoUrl: 1
  }
  try {
    const data = await collection.findOne({ _id: id }, { projection })
    info.info(`orgDetail(S-S) orgId:${id} data fetched`);
    res.status(200).json(data)
  } catch (err: any) {
    error.error(`orgDetails(S-S) orgId:${id} error:${err.message}`);
    res.status(500).json({errorMessage: err.message});
  }
}

export const orgData = async (req: Request, res: Response) => {

  const { ids } = req.body;
  info.info(`orgData(S-S) ids:${JSON.stringify(ids)} initiated`);

  const projection = {
    _id: 1,
    orgName: 1,
    logoUrl: 1
  }
  try {
    const data = await collection.find({ _id: { $in: ids } }, { projection }).toArray();
    info.info(`orgData(S-S) data fetched`);
    res.status(200).json(data)
  } catch (err: any) {
    error.error(`orgData(S-S) error:${err.message}`);
    res.status(500).json({errorMessage: err.message});
  }

}

export const deleteOrg = async (req: Request, res: Response) => {
  const _id = req.params.id
  info.info(`deleteOrg initiated orgId:${_id}`);
  try {
    await collection.findOneAndUpdate({ _id}, { $set: {isDeleted : true, updatedAt: new Date() } });
    await deleteAllDiv(_id);
    await axios.post(`http://${process.env.BASE_URL}:${userPort}/api/om/deleteAllOrgUsers/${_id}`).then(()=> {
      info.info(`deleteOrg orgId:${_id} om/deleteAllOrgUsers success`);
    }).catch((err: any)=> {
      error.error(`deleteOrg orgId:${_id} error: ${err.message}`);
    })

    info.info(`deleteOrg orgId:${_id} success`);
    res.status(200).json(generateResponse(`Organisation deleted successfully`, 200, "success"))

  } catch (err:any) {
    error.error(`deleteOrg orgId:${_id} error:${err.message}`)
    res.status(500).json(generateResponse(`Internal server error`,500,"failed"));
  }
}

export async function getSubscriptionPlan (req: Request, res: Response) {
  const {id} = req.params;
  info.info(`getSubscriptionPlan orgId:${id} initiated`);
  try {
    const orgSubsData = await collection.findOne({_id: id, isDeleted: false, isActive: true},{projection:{ subscription: 1 }});
    if(!orgSubsData)
    {
      error.error(`getSubscriptionPlan orgId:${id} not found`);
      return res.status(400).json(generateResponse("Company not found..", 400, "Failed"));
    }
    info.info(`getSubscriptionPlan orgId:${id} data fetched`);
    res.status(200).json(generateResponse("Subscription details fetched..", 200, "Success", orgSubsData.subscription));
  }
  catch(err: any)
  {
    error.error(`getSubscriptionPlan orgId:${id} error:${err.message}`);
    res.status(500).json(generateResponse("Internal server error...", 500, "Failed"));
  }
}

export async function subscribePlan (req: Request, res: Response) {
  const {planId} = req.body;
  const orgId = req.params.id;
  info.info(`subscribePlan initiated orgId:${orgId} req.body:${JSON.stringify(req.body)}`);
  if(!planId)
  {
    error.error(`subscribePlan error: planId missing`);
    return res.status(400).json(generateResponse("Missing plan id", 400, "failed"));
  }
  if(!orgId)
  {
    error.error(`subscribePlan error: orgId missing`);
    return res.status(400).json(generateResponse("Missing company id", 400, "failed"));
  }
  try{
    const subscribedDate: string = currentDate.format('YYYY-MM-DD');
    info.info(`subscribePlan subscribedDate:${subscribedDate}`);
    const subsData = await getSubsPlan(planId);
    if(!subsData)
    {
      error.error(`subscribePlan orgId:${orgId} getSubsPlan data not fetched`);
      return res.status(500).json(generateResponse("Internal server error", 500, "Failed"));
    }
    const days = (subsData.period == 'Monthly') ? 31 : 365;
    info.info(`subscribePlan orgId:${orgId} generated days:${days}`);
    const expiryDate: string = moment(subscribedDate).add(days, 'days').format('YYYY-MM-DD');
    const updatedData = {
      planId, 
      subscribedDate, 
      expiryDate, 
      isExpired: false, 
      isUnSubscribed: false,
      planName: subsData.planName,
      type: subsData.type,
      features: subsData.features,
      period: subsData.period,
      ...(subsData.amount && {amount: subsData.amount}),
    }
    info.info(`subscribePlan orgId:${orgId} updated subscription data:${JSON.stringify(updatedData)}`);
    await collection.findOneAndUpdate({ _id: orgId, isDeleted: false}, 
      {
        $set: {subscription: updatedData, updatedAt: new Date()}
      },
      {
        new: true
      });
      const userApiEndpoint = `http://${baseURL}:${userPort}/api/userServices/delete/notification`;
    const response = await axios.put(userApiEndpoint, {orgId}).then(() => {
      info.info(`subscribePlan orgId:${orgId} notification collection updated`);
    }).catch((err: any) => {
      error.error(`subscribePlan orgId:${orgId} notification collection updation error:${err.meta.displayMessage}`);
    });
      res.status(200).json(generateResponse("Company subscribed successfully...", 200, "Success"));
  }
  catch(err: any){
    error.error(`subscribePlan orgId:${orgId} error:${err.message}`);
    res.status(500).json(generateResponse("Company subscription failed. Internal server error...", 500, "Failed"));
  }
}

export async function unsubscribePlan(req: Request, res: Response) {
  const {id} = req.params;
  try{
    info.info(`unsubscribePlan orgId:${id} initiated`);
    const expiryDate: string = currentDate.format('YYYY-MM-DD');

    await collection.findOneAndUpdate({_id: id}, {
      $set: {
        "subscription.expiryDate":expiryDate,
        "subscription.isUnSubscribed": true,
        updatedAt: new Date()
      }
    });
    info.info(`unsubscribePlan orgId:${id} updated expiryDate:${expiryDate}`);
    res.status(200).json(generateResponse("Company successfully unsubscribed...", 200, "Success"));
  }
  catch(err: any){
    error.error(`unsubscribePlan orgId:${id} error:${err.message}`);
    res.status(500).json(generateResponse("Company unsubscription failed. Internal server error...", 500, "Failed"));
  }
}

async function checkSubscriptionExpiry ( ) {
  const todayDate: string = currentDate.format('YYYY-MM-DD');
  info.info(`checkSubscriptionExpiry date:${todayDate} initiated`);
  try{
    const orgData = await collection.find({ "subscription.expiryDate": todayDate, isDeleted: false, "subscription.isExpired": false, "subscription.isUnSubscribed": false}, {projection: {_id: 1, subscription: 1}}).toArray();
    if(orgData.length < 1){
      info.info(`checkSubscriptionExpiry date:${todayDate} no company found`);
      return;
    }
    info.info(`checkSubscriptionExpiry orgData:${JSON.stringify(orgData)}`);

    const ids = orgData.map((org: any) => org._id);

    await collection.updateMany({ _id : {$in : ids}}, { 
      $set: { "subscription.isExpired": true}
    });
    info.info(`checkSubscriptionExpiry date:${todayDate} for ids:${JSON.stringify(ids)}`);
    const userApiEndpoint = `http://${baseURL}:${userPort}/api/userServices/sub/notification`;
    const response = await axios.post(userApiEndpoint, {orgData, isExpired: true }).then(() => {
      info.info(`checkSubscriptionExpiry date:${todayDate} for ids:${JSON.stringify(ids)} notification sent`);
    }).catch((err: any) => {
      error.error(`checkSubscriptionExpiry date:${todayDate} for ids:${JSON.stringify(ids)} error:${err.meta.displayMessage}`);
    });
    return;
  }
  catch(err: any) {
    error.error(`checkSubscriptionExpiry date:${todayDate} error:${err.message}`);
    return;
  }
}

const expiringSubscription = async () => {
  const todayDate: string = moment().format("YYYY-MM-DD");

  const almostAWeekLater: string = moment().add(1, "week").format("YYYY-MM-DD");
  info.info(
    `expiringSubscription todayDate:${todayDate} almostAWeekLater:${almostAWeekLater} initiated`
  );

  try {
    const pipeline = [
      {
        $match: {
          "subscription.expiryDate": {
            $gte: todayDate,
            $lte: almostAWeekLater, // Less than or equal to almostAWeekLater
          },
          "subscription.isExpired": false,
          "subscription.isUnSubscribed": false,
          isDeleted: false,
        },
      },
      {
        $project: {
          _id: 1,
          subscription: 1
        },
      },
    ];
    const orgData = await collection.aggregate(pipeline).toArray();

    if (orgData.length < 1) {
      info.info(
        `expiringSubscription todayDate:${todayDate} almostAWeekLater:${almostAWeekLater} no company found`
      );
      return;
    }
    else{
    info.info(`expiringSubscription todayDate:${todayDate} almostAWeekLater:${almostAWeekLater} orgData:${JSON.stringify(orgData)}`);
    const userApiEndpoint = `http://${baseURL}:${userPort}/api/userServices/sub/notification`;
    const response = await axios.post(userApiEndpoint, {orgData, isExpired: false }).then(() => {
      info.info(`expiringSubscription todayDate:${todayDate} almostAWeekLater:${almostAWeekLater} notification sent`);
    }).catch((err: any) => {
      error.error(`expiringSubscription todayDate:${todayDate} almostAWeekLater:${almostAWeekLater} error:${err.meta.displayMessage}`);
    });
    return;
    }
  } catch (err: any) {
    error.error(
      `expiringSubscription todayDate:${todayDate} almostAWeekLater:${almostAWeekLater} error:${err.message}`
    );
    return;
  }
};

const subscriptionExpiryScheduler = schedule.scheduleJob('58 23 * * *', () => {
  checkSubscriptionExpiry();
});

// To schedule a job to run at 12 AM (midnight)
const subscriptionScheduler = schedule.scheduleJob('0 0 * * *', () => {
  expiringSubscription();
});