import { Request, Response } from 'express';
import { division } from "../model/divisionModel";
import { addDivId } from '../utils/divIdGenerate';
import { info, error } from "../config/loggerConfig";
import { generateResponse } from "../utils/responseGenerate";
import { addDivCodeCount } from '../utils/divCodeGenerate';
import { addShiftIdCount } from '../utils/shiftIdGenerate';
import axios from 'axios';
let collection: any;
export const divInstance = async () => {
  collection = await division();
}
const  userPort = process.env.USER_PORT
const  baseURL = process.env.BASE_URL

export async function divCreate(req: Request, res: Response) {

  let { division, name, shift, fssai, orgId, isMain, isSToS } = req.body;
  
  if (division) {
    ({ name, shift, fssai, orgId, isMain, isSToS } = division);
  }

  isMain = isMain || false;

  const bodyValues = division ? req.body.division : req.body;

  const logMessage = division ? 'divCreate initiated from org controller' : 'divCreate initiated';

  info.info(`${logMessage} bodyValues:${JSON.stringify(bodyValues)}`);

  if(!name || !shift || !fssai || !orgId){
    error.error(`divCreate name:${name} missing details`);
    if(isSToS)
        {
          return "missing details";
        }
        else{
          return res.status(400).json(generateResponse("Missing details", 400, "failed"));    
        } 
  }
  try {

    const existingDivision = await collection.findOne({ orgId, divName: name });
    if (existingDivision) {
      if(isSToS)
      {
        error.error(`divCreate orgId:${orgId} name:${name} error: divName already exist`);
        return false;
      }
      else{
        error.error(`divCreate orgId:${orgId} name:${name} error: divName already exist`);
        return res.status(400).send(
        generateResponse(`Name already existed`,400,"failed")
      );
      }
    }
  
    const divId = await addDivId();
    info.info(`divCreate orgId:${orgId} generated divId:${divId}`);
    const divCodeRes = await addDivCodeCount(orgId);
    info.info(`divCreate orgId:${orgId} generated divCodeRes:${JSON.stringify(divCodeRes)}`);

    let count = divCodeRes?.count;
    if (divCodeRes?.count < 10) {
      count = `0${divCodeRes?.count}`;
    }
    const divCode = `${divCodeRes?.divCode}${count}`;
    let shiftSet = new Set();
    for (const shiftDetail of shift) {
      if (shiftSet.has(shiftDetail.from)) {
        error.error(`createDiv orgId:${orgId} divId:${divId} error:shift with similar time`);
        if(isSToS)
        {
          return "shift similar time";
        }
        else{
          return res.status(400).json(generateResponse("Some shift has similar from time", 400, "Failed"));
        } 
      } else {
        shiftSet.add(shiftDetail.from);
      }
    }

    if (shift.length > 0) {

      for (const shiftData of shift) {
        try {
          const response = await addShiftIdCount(divId);
          shiftData.shiftId = `shift_${response}`;
        } catch (err: any) {
          error.error(`createDiv orgId:${orgId} divId:${divId} addShiftIdCount error:${err.message}`);
          if(isSToS)
          {
          return false;
          }
          else
          {
          return res.status(500).json(generateResponse("Internal server error", 500, "Failed"));
          }
        }
      }
    }

    let shifts = await updateShitTimeAndNo(shift)
    
    const divData = {
      _id: divId,
      divName: name,
      divId: divCode,
      shift: shifts,
      fssai,
      isMain,
      orgId,
      isDeleted: false,
      isActive: true,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    await collection.insertOne(divData);
    info.info(`divCreate orgId:${orgId} divId:${divId} insertedData:${JSON.stringify(divData)}`);
    if(req.body.orgOwner){
    req.body.orgOwner.divId = divId;
    }

    if (isSToS) {
      return true;
    } else {
      return res.status(200).json(generateResponse("Branch created successfully", 200, "Success"));
    }}
  catch (err : any){
    error.error(`divCreate orgId:${orgId} error:${err.message}`);
    if(isSToS){
      return false
    }
    else{
    return res.status(500).json(generateResponse("Internal server error", 500, "Failed"));
    }
  }
}


export async function divUpdate(req: Request, res: Response) {
  const {id} = req.params;
  info.info(`divUpdate initiated divId:${id}`);
  const {orgId} = req.query;
  const { name, fssai } = req.body;
  info.info(`divUpdate divId:${id} req.query:${JSON.stringify(req.query)} req.body:${JSON.stringify(req.body)}`);
  if(!orgId || !name || !fssai) {
    error.error(`divUpdate divId:${id} error: missing details`);
    return res.status(400).json(generateResponse("Missing details", 400, "failed"));
  }
  
  try {
    const updateData = {
      divName: name,
      fssai,
      updatedAt: new Date(),
    };
    const existingDivision = await collection.findOne({ _id: { $ne: id}, orgId, divName: name });
    if (existingDivision)
    {
      error.error(`divUpdate divId:${id} name:${name} divName already exist`);
      return res.status(400).json(generateResponse("Branch name already present", 400, "Failed"));
    }
    await collection.findOneAndUpdate({ _id: id }, {
      $set: updateData
      },
      {
        new: true
      });
    info.info(`divUpdate divId:${id} updatedData:${JSON.stringify(updateData)}`);
    res.status(200).json(generateResponse("Branch updated successfully", 200, "Success"));
  }
  catch (err:any) {
    error.error(`divUpdate divId:${id} error:${err.message}`);
    res.status(500).json(generateResponse("Internal server error", 500, "Failed"));
  }
}

export async function divDelete(req: Request, res: Response) {
  const { id } = req.params;
  info.info(`divDelete initiated divId:${id}`);
  try {
    info.info(`divDelete divId:${id} initiated`);
    await collection.findOneAndUpdate({ _id: id }, {
      $set: {
        isDeleted: true,
        updatedAt: new Date()
      }
    }, { new: true });

    await axios.put(`http://${baseURL}:${userPort}/api/om/inActiveAllDivUsers/${id}`).then(()=> {
      info.info(`divDelete divId:${id} inActiveAllDivUsers success`);
    }).catch((err: any)=>{
      error.error(`divDelete divId:${id} inActiveAllDivUsers error:${JSON.stringify(err)}`);
    })

    info.info(`divDelete divId:${id} success`);
    res.status(200).json(generateResponse("Branch deleted successfully", 200, "Success"));
  } catch (err: any) {
    error.error(`divDelete divId:${id} error:${err.message}`);
    res.status(500).json(generateResponse("Internal server error", 500, "Failed"));
  }
}

export async function divTypeChange(req: Request, res: Response) {
  const {id} = req.params;
  const { isMain } = req.body;
  info.info(`divTypeChange divId:${id} req.body:${JSON.stringify(req.body)} initiated`);
  if(isMain === "" || isMain == undefined)
  {
    error.error(`divTypeChange divId:${id} error: missing isMain`);
    return res.status(400).json(generateResponse("Missing arguments", 400, "failed"));
  }
  try {
    await collection.findOneAndUpdate({ _id: id }, {
      $set: {isMain}
    },
      {
        new: true
      });
    info.info(`divTypeChange divId:${id} isMain:${isMain} updated successfully`);
    res.status(200).json(generateResponse("Type changed successfully", 200, "Success"));
  }
  catch(err: any) {
    error.error(`divTypeChange divId:${id} error:${err.message}`);
    res.status(500).json(generateResponse("Internal server error", 500, "Failed"));
  }
}

export async function getDivListAll(req: Request, res: Response) {

  let orgId = req.params.id;
  info.info(`getDivListAll orgId:${orgId} initiated`);
  info.info(`getDivListAll req.query:${JSON.stringify(req.query)}`);
  try {
    if (collection) {
      const { query, sortBy } = req.query;
      let sortColumn : any = req.query.sortColumn;
      let page : any = req.query.page;

      const searchFilter = {
        orgId,
        isDeleted: false, 
        ...(query
          ? {
              $or: [
                { divName: { $regex: query, $options: 'i' } },
                { divId: { $regex: query, $options: 'i' }}
              ],
            }
          : {}),
      };
  
      const sortOptions: any = {};
      if (sortColumn) {
        sortOptions[sortColumn] = sortBy === 'asc' ? 1 : -1;
      }
  
      
      const pageSize = parseInt(req.query.pageSize as string, 10) || 10;
      const currentPage = parseInt(page) || 1;

      const skip = (currentPage - 1) * pageSize;
  
      const projection = {
        _id: 1,
        divName: 1,
        divId: 1,
        shift: 1
      };
  
      const divisions = await collection
        .find(searchFilter)
        .project(projection)
        .sort(sortOptions)
        .skip(skip)
        .limit(pageSize)
        .toArray();
  
      const totalDivisions = await collection.countDocuments(searchFilter);

      let divIds = [];
      for(let divId of divisions)
      {
        if(divId._id){
        divIds.push(divId._id);
        }
      }
      const userApiEndpoint = `http://${baseURL}:${userPort}/api/userServices/divCount`;

      let divisionList : any = [];
        const resp =  await axios.post(userApiEndpoint, {divIds}).then((count : any)=>{
          info.info(`getDivListAll orgId:${orgId} userServices/divCount S-S success`);
          for(let div of count.data)
          {
            for(let divList of divisions)
            {
              if(divList._id == div.divId)
              {
                divList.totalUsers = div.totalUsers;
                divisionList.push(divList);
              }
            }
          }
        }).catch((err:any)=>{
          error.error(`getDivListAll orgId:${orgId} userServices/divCount error:${err.meta.displayMessage}`);
          return res.status(400).json(generateResponse("Internal server error", 500, "Failed"));
        })
      res.status(200).send( {
        totalCount: totalDivisions,
        divisionList
      });

    }
    else {
      error.error(`getDivListAll orgId:${orgId} error collection not connected`);
      return res.status(500).json(generateResponse('Internal server error', 500, 'Failed'));
    }
  } catch (err: any) {
    error.error(`getDivListAll orgId:${orgId} errorMessage:${err.message}`);
    return res.status(500).json(generateResponse("Internal server error", 500, "Failed"));
  }
}

export async function getDivListByOrg(req: Request, res: Response) {

  const { id } = req.params;
  const uType = req.query.userType ? req.query.userType : null;
  info.info(`getDivListByOrg orgId:${id} uType:${uType} initiated`);
  try {
    const projection = {
      _id: 1,
      divName:1,
      orgId: 1,
      shift:1
    }
    let isMain;
    if(uType){
      if(uType == "storeUser"){
        isMain = true;
      }
    }
    const divList = await collection.find({
      orgId:id, 
      isDeleted: false, 
      isActive: true,
      ...(isMain && {isMain : isMain})
    }).project(projection).toArray();
    if (divList) {
      info.info(`getDivListByOrg data fetched`);
      const response = generateResponse('Division List', 200, 'success', divList)
      res.status(200).send({
        response
      });
    } else {
      info.info(`getDivListByOrg div not found`);
      const response = generateResponse('Division list not found', 404, 'failed')
      res.status(404).json(response);
    }
  } catch (err: any) {
    error.error(`getDivListByOrg errorMessage:${err.message}`);
    res.status(500).json(generateResponse("Internal server error", 500, "Failed"));
  }
}

export async function getDivNameList (req: Request, res: Response) {
  const {orgId, query, page, pageSize}: any = req.query;
  info.info(`getDivNameList initiated`);
  info.info(`getDivNameList req.query:${JSON.stringify(req.query)}`);
  try{
    const size = parseInt(pageSize as string, 10) || 10;
    const currentPage = parseInt(page) || 1;

      const skip = (currentPage - 1) * size;

      const pipeline = [
        {
          $match: {
            orgId,
            isDeleted: false,
            ...(query && 
              { divName: { $regex: query, $options: 'i' } })
          },
        },
        {
          $facet: {
            paginatedResult: [
              { $project: { _id: 1, divName: 1, divId: 1 } },
              { $skip: skip },
              { $limit: size },
            ],
            totalCount: [
              { $count: 'total' },
            ],
          },
        },
        {
          $unwind: '$totalCount',
        },
        {
          $project: {
            paginatedResult: 1,
            totalCount: '$totalCount.total',
          },
        },
      ];

      const result = await collection.aggregate(pipeline).toArray();
      let paginatedResult = [];
      let totalCount = 0;
      if(result.length > 0 )
      {
        paginatedResult= result[0].paginatedResult ;
        totalCount= result[0].totalCount;
      }
      else{
        return res.status(404).json(generateResponse("No results found", 404, "failed"));
      }

      return res.status(200).json(generateResponse("Data fetched", 200, "success", {paginatedResult, totalCount}));
  }
  catch(err: any){
    error.error(`getDivNameList orgId:${orgId} error: ${err.message}`);
    return res.status(500).json(generateResponse("Internal server error", 500, "failed"));
  }
}

export async function getDivDetail(req: Request, res: Response) {

  const { id } = req.params;
  info.info(`getDivDetail divId:${id} initiated`);
  try {

      const projection = {
        _id: 1,
        divName:1,
        divId:1,
        fssai:1,
        shift:1,
        orgId:1,
        isMain:1,
        isDeleted:1,
      };

      const division = await collection.findOne({ _id: id }, { projection });
      if (division) {
        if(!division.isDeleted)
        {
        info.info(`getDivDetail divId:${id} success`);
        const response = generateResponse('division found', 200, 'success', division)
        res.status(200).json(response);
        }
        else{
        error.error(`getDivDetail divId:${id} division deleted`);
        const response = generateResponse('division not found', 404, 'failed')
        res.status(404).json(response);
        }
      } else {
        error.error(`getDivDetail divId:${id} division not found`);
        const response = generateResponse('Branch not found', 404, 'failed')
        res.status(404).json(response);
      }

  } catch (err: any) {
    error.error(`getdivDetail divId:${id} errorMessage:${err.message}`);
    res.status(500).json(generateResponse("Internal server error", 500, "Failed"));
  }
}


export const updateShitTimeAndNo = async (shifts: any) => {
  const sortShifts = await shifts.sort((a: any, b: any) => {
    const [hoursA, minutesA] = a.from.split(":").map(Number);
    const [hoursB, minutesB] = b.from.split(":").map(Number);

    // Sort by "from" time
    if (hoursA !== hoursB) {
      return hoursA - hoursB;
    }

    // If hours are the same, sort by minutes
    if (minutesA !== minutesB) {
      return minutesA - minutesB;
    }

    // If "from" time is the same, sort by "to" time
    const [toHoursA, toMinutesA] = a.to.split(":").map(Number);
    const [toHoursB, toMinutesB] = b.to.split(":").map(Number);

    if (toHoursA !== toHoursB) {
      return toHoursA - toHoursB;
    }

    return toMinutesA - toMinutesB;
  });

  const shiftsResult = await sortShifts.map((shift: any, index: number) => ({
    ...shift,
    shiftNo: index + 1,
  }));

  return shiftsResult;
};

export async function createShifts(req: Request, res: Response) {
  const { id } = req.params;
  info.info(`createShifts initiated divId:${id}`);
  info.info(`createShifts req body:${JSON.stringify(req.body)}`);
  const { from, to } = req.body;
  if(!from || !to)
  {
    error.error(`createShifts divId:${id} error: req.body missing`);
    return res.status(400).json(generateResponse("Missing arguments", 400, "failed"));
  }
  
  try {
    
    if (from === "" || to === "") {
      error.error(`createShifts divId:${id} error: time is empty`);
      res.status(400).json(generateResponse("Time is empty", 400, "failed"));
      return;
    }

    if (from >= to) {
      error.error(`createShifts divId:${id} error: from >= to`);
      res
        .status(400)
        .json(
          generateResponse("From time should be less than to time", 400, "failed")
        );

      return;
    }

    const divisionDocument = await collection.findOne({ _id: id });

    if (!divisionDocument) {
      error.error(`createShifts divId:${id} error: div not found`);
      res.status(404).json(generateResponse("Branch not found", 404, "failed"));
      return;
    }

    const shifts = divisionDocument.shift;

    if (shifts.length > 0) {
      const isExists = shifts.some(
        (shift: { from: any; to: any }) =>
          shift.from === from && shift.to === to
      );

      if (isExists) {
      error.error(`createShifts divId:${id} error: from & to already exist`);
        res
          .status(400)
          .json(
            generateResponse("From and To time is already exists", 400, "Failed")
          );
        return;
      }
    }

    let shiftId = await addShiftIdCount(id);

    const newShift = {
      shiftId: `shift_${shiftId}` ,
      from,
      to,
      shiftNo: null,
    };

    shifts.push(newShift);

    const createShiftTimeAndNo = await updateShitTimeAndNo(shifts);

    const result = await collection.updateOne(
      { _id: id },
      { $set: { shift: createShiftTimeAndNo, updatedAt: new Date() } }
    );

    if (result) {
      info.info(`createShifts divId:${id} success`);
      res
        .status(200)
        .json(generateResponse("Created the shift successfully", 200, "success"));
    } else {
      error.error(`createShifts divId:${id} not created`);
      res.status(400).json(generateResponse("Internal server error", 400, "Failed"));
    }
  } catch (err: any) {
    error.error(`createShifts divId:${id} error:${err.message}`);
    res
      .status(500)
      .json(
        generateResponse(`Internal server error`, 500, "Failed")
      );
  }
}

export async function editShifts(req: Request, res: Response) {
  const { id, shiftId } = req.params;
  info.info(`editShifts initiated divId:${id} shiftId:${shiftId}`);
  info.info(`editShifts req body:${JSON.stringify(req.body)}`);

  try {
    const { from, to } = req.body;

    if (from === "" || to === "") {
      error.error(`editShifts divId:${id} error: Time is empty`);
      res.status(400).json(generateResponse("Time is empty", 400, "Failed"));
      return;
    }

    if (from >= to) {
      error.error(`editShifts divId:${id} error: from > to`);
      res
        .status(400)
        .json(
          generateResponse("From time should be less than to time", 400, "Failed")
        );

      return;
    }

    const divisionDocument = await collection.findOne({ _id: id });

    if (!divisionDocument) {
      error.error(`editShifts divId:${id} error: div not found`);
      res.status(404).json(generateResponse("Branch not found", 404, "Failed"));
      return;
    }

    const shifts = divisionDocument.shift;

    const shiftIndex = shifts.findIndex(
      (shift: { shiftId: any }) => shift.shiftId === shiftId
    );

    if (shiftIndex === -1) {
      error.error(`editShifts divId:${id} error: shift not found`);
      res.status(404).json(generateResponse("Shift not found", 404, "Failed"));
      return;
    }
    if (shifts.length > 0) {
      const isExists = shifts.some(
        (shift: { from: any; to: any }) =>
          shift.from === from && shift.to === to
      );

      if (isExists) {
      error.error(`editShifts divId:${id} error: from & to already exist`);
        res
          .status(400)
          .json(
            generateResponse("From and To time is already exists", 400, "Failed")
          );
        return;
      }
    }

    shifts[shiftIndex].from = from;
    shifts[shiftIndex].to = to;

    const updateShiftTimeAndNo = await updateShitTimeAndNo(shifts);

    const result = await collection.updateOne(
      { _id: id },
      { $set: { shift: updateShiftTimeAndNo, updatedAt: new Date() } }
    );

    info.info(`editShifts divId:${id} updatedData:${JSON.stringify(updateShiftTimeAndNo)}`);

    res
      .status(200)
      .json(generateResponse("Updated the shift successfully", 200, "success"));

  } catch (err: any) {
    res
      .status(500)
      .json(
        generateResponse(`Update shifts error, Internal server error`, 500, "Failed")
      );
  }
}

export async function deleteShifts(req: Request, res: Response) {
  info.info(`deleteShifts initiated`);
  const { id, shiftId } = req.params;
  info.info(`deleteShifts divId:${id} shiftId:${shiftId}`);

  try {

    if (id === "" || shiftId === "") {
      error.error(`deleteShifts divId:${id} error: Missing divId/shiftId`);
      res
        .status(400)
        .json(
          generateResponse("Send the correct branch id and shift id", 400, "Failed")
        );
      return;
    }

    const divisionDocument = await collection.findOne({ _id: id });

    if (!divisionDocument) {
      error.error(`deleteShifts divId:${id} error: div not found`);
      const response = generateResponse("Branch not found", 404, "Failed");
      res.status(404).json(response);
      return;
    }

    const shifts = divisionDocument.shift;
    const shiftIndex = shifts.findIndex(
      (shift: { shiftId: any }) => shift.shiftId === shiftId
    );

    if (shiftIndex === -1) {
      error.error(`deleteShifts divId:${id} error: Shift not found`);
      res.status(404).json(generateResponse("Shift not found", 404, "Failed"));
      return;
    }

    const removeShift = shifts.filter((shift: { shiftId: any }) => {
      return shift.shiftId !== shiftId;
    });
    const updateShiftTimeAndNo = await updateShitTimeAndNo(removeShift);

    const result = await collection.updateOne(
      { _id: id },
      { $set: { shift: updateShiftTimeAndNo, updatedAt: new Date() } }
    );
    info.info(`deleteShifts divId:${id} updatedData:${JSON.stringify(updateShiftTimeAndNo)}`);

    // Call the user services API to remove the shifts id in user DB
    const userApiEndpoint = `http://${baseURL}:${userPort}/api/userServices/deleteShiftId`;
        
      
      const response =  await axios.post(userApiEndpoint, {shiftId}).then(()=>{
        info.info(`deleteShifts divId:${id} deleteShiftId S-S success`);
        return res
        .status(200)
        .json(generateResponse("Shift deleted successfully", 200, "success"));
      }).catch((err:any)=>{
        return res.status(500).json(generateResponse("Internal server error", 500, "Failed"));
      })

  } catch (err: any) {
    error.error(`deleteShifts divId:${id} error:${err.message}`);
    res
      .status(500)
      .json(
        generateResponse(`Internal server error`, 500, "Failed")
      );
  }
}

export async function getOneShift(req: Request, res: Response) {
  info.info(`getOneShift initiated`);
  const { id, shiftId } = req.params;
  info.info(`getOneShift divId:${id} shiftId:${shiftId}`);

  try {

    const divisionDocument = await collection.findOne({ _id: id });

    if (!divisionDocument) {
      error.error(`getOneShift divId:${id} error: div not found`);
      const response = generateResponse("Branch not found", 404, "Failed");
      res.status(404).json(response);
      return;
    }
    const shifts = divisionDocument.shift;

    const shiftIndex = shifts.findIndex(
      (shift: { shiftId: any }) => shift.shiftId === shiftId
    );

    if (shiftIndex === -1) {
      error.error(`getOneShift divId:${id} error: Shift not found`);
      res.status(404).json(generateResponse("Shift not found", 404, "Failed"));
      return;
    }

    const oneShift = shifts.find(
      (shift: { shiftId: any }) => shift.shiftId == shiftId
    );

    const response = generateResponse("Shift found", 200, "success", oneShift);
    res.status(200).json(response);
  } catch (err: any) {
    error.error(`getOneShift divId:${id} error:${err.message}`);
    res
      .status(400)
      .json(
        generateResponse(`Internal server error`, 400, "Failed")
      );
  }
}

export async function getAllShifts(req: Request, res: Response) {
  const { id } = req.params;
  info.info(`getAllShifts divId:${id} initiated`);
  info.info(`getAllShifts reqParams:${JSON.stringify(req.params)}`);
  info.info(`getAllShifts reqQuery:${JSON.stringify(req.query)}`);

  try {
    const { page, sortBy } = req.query;
    const currentPage: any = page || 1;
    const pageSize = parseInt(req.query.pageSize as string) || 10;
    const sortColumn: any = req.query.sortColumn
      ? req.query.sortColumn
      : "shiftNo";

    const divisionDocument = await collection.findOne({ _id: id });
    if (!divisionDocument) {
      error.error(`getAllShifts divId:${id} error: div not found`);
      const response = generateResponse("Branch not found", 404, "Failed");
      res.status(404).json(response);
      return;
    }

    const shifts = divisionDocument.shift;

    const sortedShiftDetails = shifts.sort((a: any, b: any) => {
      const order = sortBy === "desc" ? -1 : 1;
      return order * (a[sortColumn] - b[sortColumn]);
    });

    const startIndex = (currentPage - 1) * pageSize;
    const paginatedShiftDetails = sortedShiftDetails.slice(
      startIndex,
      startIndex + pageSize
    );
    const totalPages = Math.ceil(shifts.length / pageSize);

    const data = {
      shiftDetails: paginatedShiftDetails,
      totalCount: shifts.length,
      totalPages,
    };
    const response = generateResponse(
      "Shift fetched successfully",
      200,
      "success",
      data
    );
    info.info(`getAllShifts divId:${id} data fetched`);
    res.status(200).json(response);
  } catch (err: any) {
    error.error(`getAllShifts divId:${id} error:${err.message}`)
    res
      .status(400)
      .json(
        generateResponse(`Internal server error`, 400, "Failed")
      );
  }
}

export async function getShiftNoList(req: Request, res: Response) {
  const { id } = req.params;
  info.info(`getShiftNoList initiated divId:${id}`);
  try {
    interface Shift {
      shiftId: string;
      shiftNo: number;
    }

    const divisionDocument = await collection.findOne({ _id: id });
    if (!divisionDocument) {
      error.error(`getShiftNoList divId:${id} error: div not found`);
      const response = generateResponse("Branch not found", 404, "Failed");
      res.status(404).json(response);
      return;
    }

    const shifts: Shift[] = divisionDocument.shift;
    const extractedShiftDetails = shifts.map(({ shiftId, shiftNo }) => ({
      shiftId,
      shiftNo,
    }));

    const response = generateResponse(
      "Fetched shits list successfully",
      200,
      "success",
      extractedShiftDetails
    );
    info.info(`getShiftNoList divId:${id} data fetched`);
    res.status(200).json(response);
  } catch (err: any) {
    error.error(`getShiftNoList divId:${id} error:${err.message}`);
    res
      .status(400)
      .json(
        generateResponse(
          `Internal server error`,
          400,
          "error"
        )
      );
  }
}


export async function getDivShift(req: Request, res: Response) {
  
  const { id } = req.params;
  info.info(`getDivShift divId:${id} initiated`);
  try {

      const projection = {
        _id: 1,
        divName:1,
        shift:1,
      };

      const division = await collection.findOne({ _id: id }, { projection });
      
      if (division) {
        if(!division.isDeleted)
        {
          info.info(`getDivShift divId:${id} data fecthed`);
          res.status(200).json(division);
        }
        else{
          error.error(`getDivShift divId:${id} error: division deleted`);
          const response = generateResponse('Branch not found', 404, 'Failed')
          res.status(404).json(response);
        }
      } else {
        error.error(`getDivShift divId:${id} error: div not found`)
        const response = generateResponse('Branch not found', 404, 'Failed')
        res.status(404).json(response);
      }

  } catch (err: any) {
    error.error(`getDivShift divId:${id} error:${err.message}`);
    res.status(500).json(generateResponse("Internal server error", 500, "Failed"));
  }
}


export const deleteAllDiv = async (orgId:any) => {
    info.info(`deleteAllDiv orgId:${orgId} initiated`);
  try {           
    const result =await collection.updateMany({ orgId}, { $set: {'isDeleted': true, 'updatedAt': new Date() } });
    const numDocumentsUpdated = result.modifiedCount;
    info.info(`deleteAllDiv orgId:${orgId} numDocumentsUpdated:${numDocumentsUpdated}`);
    return {
      success: true,
      message: `${numDocumentsUpdated} documents updated. All divisions for orgId ${orgId} marked as deleted.`,
    };
  } catch (err: any) {
      error.error(`deleteAllDiv orgId:${orgId} error:${err.message}`); 
      return; 
  }
};


export const divNameList = async(req: Request, res: Response)=>{
  const {divIds} = req.body;
  info.info(`divNameList initiated for divIds:${JSON.stringify(divIds)}`);
  try {
    const divNames = await collection.find(
      { _id: { $in: divIds }, isDeleted: false }, 
      { projection: { _id: 0, divId: 1, divName: 1 } } 
    ).toArray();
    info.info(`divNameList data fetched`);
    res.status(200).json(generateResponse('Division names fetched..',200,'success',divNames))
  } catch (err:any) {
    error.error(`divNameList error:${err.message}`);
    res.status(500).json(generateResponse('Internal server error..',500,'failed'));
  }
} 

export async function checkMainDiv (req: Request, res: Response) {
  const {id} = req.query;
  info.info(`checkMainDiv divId:${id} initiated`);
  try{
    info.info(`checkMainDiv divId:${id} initiated`);
    const divData = await collection.findOne({_id: id}, {projection: {isMain: 1}});
    info.info(`checkMainDiv divId:${id} divData:${JSON.stringify(divData)}`);
    res.status(200).send({divData});
  }
  catch(err: any)
  {
    error.error(`checkMainDiv error:${err.message}`);
    res.status(500).send({
      message: "Internal server error"
    });
  }
}