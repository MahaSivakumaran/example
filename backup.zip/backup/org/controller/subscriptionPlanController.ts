import { Request, Response } from "express";
import { info, error } from "../config/loggerConfig";
import { subscriptionPlan } from "../model/subscriptionPlanModel";
import { generateResponse } from "../utils/responseGenerate";
import { searchAndPaginate } from "../utils/apiFeatures";
import { addSubsId } from "../utils/subsIdgenerate";

let collection: any;
export const subscriptionInstance = async () => {
  collection = await subscriptionPlan();
};

export async function createSubscription(req: Request, res: Response) {
  info.info(`createSubscription initiated`);
  info.info(`createSubscription req body:${JSON.stringify(req.body)}`);

  try {
    const { planName, features, type, period } = req.body;
    if(!planName || !features || !type || !period)
    {
      error.error(`createSubscription error: missing arguments`);
      return res.status(400).json(generateResponse("Invalid arguments", 400, "failed"));
    }
    let amount = req.body.amount ? req.body.amount : null;

    const isAllowedType = ["Free", "Paid"];
    const isAllowedPeriod = ["Monthly", "Yearly"];

    const subsDetail = await collection.findOne({planName});
    if(subsDetail)
    {
      error.error(`createSubscription error: planName already exist`);
      return res.status(400).json(generateResponse("Plan name already exist", 400, "failed"));
    }

    if (!isAllowedType.includes(type)) {
      error.error(`createSubscription error: invalid subscription type`);
      const response = generateResponse(
        "Invalid subscription type",
        400,
        "failed"
      );
      res.status(400).json(response);
      return;
    }

    if (!isAllowedPeriod.includes(period)) {
      error.error(`createSubscription error: invalid period`);
      const response = generateResponse(
        "Invalid subscription period",
        400,
        "failed"
      );
      res.status(400).json(response);
      return;
    }
    const subId = await addSubsId();
    if(type == "Free") { amount = null;}

    const subsData = {
      _id: subId, //planId,
      planName,
      features,
      type,
      period,
      ...(amount && {amount: amount}),
      isDeleted: false,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    await collection.insertOne(subsData);

    info.info(`createSubscription created data:${JSON.stringify(subsData)}`);
    const response = generateResponse(
      "Subscription plan created successfully",
      200,
      "success"
    );
    res.status(200).json(response);
  } catch (err: any) {
    error.error(`createSubscription err.message:${err.message}`);
    const response = generateResponse("Internal server error", 500, "failed");
    res.status(500).json(response);
  }
}

export async function editSubscription(req: Request, res: Response) {
  const { id } = req.params;
  info.info(`editSubscription initiated _id:${id}`);
  info.info(`editSubscription req body:${JSON.stringify(req.body)}`);
  try {
    const { planName, features, type, period } = req.body;
    let amount = req.body.amount ? req.body.amount : null;
    if(!planName || !features || !type || !period)
    {
      error.error(`createSubscription error: missing arguments`);
      return res.status(400).json(generateResponse("Invalid arguments", 400, "failed"));
    }

    const isAllowedType = ["Free", "Paid"];
    const isAllowedPeriod = ["Monthly", "Yearly"];

    const subsDetail = await collection.findOne({ _id: {$ne: id}, planName});
    if(subsDetail)
    {
      error.error(`createSubscription error: planName already exist`);
      return res.status(400).json(generateResponse("Plan name already exist", 400, "failed"));
    }

    if(!planName){
      error.error(`editSubscription error: missing planName`);
      return res.status(400).json(generateResponse("Missing Plan name", 400, "failed"));
    }
    else if(!features){
      error.error(`editSubscription error: missing features`);
      return res.status(400).json(generateResponse("Missing features", 400, "failed"));
    }

    if (!isAllowedType.includes(type)) {
      error.error(`editSubscription _id:${id} error: invalid subscription type`);
      const response = generateResponse(
        "Invalid subscription type",
        400,
        "failed"
      );
      return res.status(400).json(response);
    }

    if (!isAllowedPeriod.includes(period)) {
      error.error(`editSubscription _id:${id} error: invalid period`);
      const response = generateResponse(
        "Invalid subscription period",
        400,
        "failed"
      );
      return res.status(400).json(response);
    }

    if(type == "Free") { amount = null;}

    const updatedData = {
      planName,
      features,
      type,
      period,
      amount,
      updatedAt: new Date(),
    };
    
    const result = await collection.findOneAndUpdate(
      { _id: id },
      {
        $set: updatedData,
      },
      {
        new: true,
      }
      );
      if (result) {
      info.info(`editSubscription _id:${id} updatedData:${JSON.stringify(updatedData)}`);
      const response = generateResponse(
        "Subscription plan updated successfully",
        200,
        "success"
      );
      res.status(200).json(response);
    } else {
      error.error(`editSubscription _id:${id} error: plan not found`);
      const response = generateResponse(
        "Subscription plan not found",
        404,
        "failed"
      );
      res.status(404).json(response);
    }
  } catch (err: any) {
    error.error(`editSubscription _id:${id} err.message:${err.message}`);
    const response = generateResponse("Internal server error", 500, "failed");
    res.status(500).json(response);
  }
}

export async function deleteSubscription(req: Request, res: Response) {

  const { id } = req.params;
  info.info(`deleteSubscription initiated _id:${id}`);

  try {
    const updatedData = {
      isDeleted: true,
      updatedAt: new Date(),
    };
    
    const result = await collection.findOneAndUpdate(
      { _id: id },
      {
        $set: updatedData,
      },
      {
        new: true,
      }
      );
      
      if (result) {
      info.info(`deleteSubscription updatedData: ${JSON.stringify(updatedData)}`);

      const response = generateResponse(
        "Subscription deleted successfully",
        200,
        "success"
      );
      res.status(200).json(response);
    } else {
      error.error(`deleteSubscription _id:${id} error: plan not found`);
      const response = generateResponse(
        "Subscription plan not found",
        404,
        "failed"
      );
      res.status(404).json(response);
    }
  } catch (err: any) {
    error.error(`deleteSubscription _id:${id} err.message:${err.message}`);
    const response = generateResponse("Internal server error", 500, "failed");
    res.status(500).json(response);
  }
}

export async function getAllSubscriptions(req: Request, res: Response) {
  info.info(`getAllSubscriptions initiated`);
  info.info(`getAllSubscriptions reqParams:${JSON.stringify(req.query)}`);

  try {
    if (collection) {
      const { query, page, sortBy, sortColumn, pageSize } = req.query;
      const data = await searchAndPaginate(
        collection,
        query,
        page,
        sortBy,
        sortColumn,
        pageSize
      );
      if (data) {
        info.info(`getAllSubscriptions data fetched successfully`);
        const response = generateResponse(
          "Subscription fetched successfully",
          200,
          "success",
          data
        );
        res.status(200).json(response);
      } else {
        error.error(`getAllSubscriptions error: no response from searchAndPaginate`);
        const response = generateResponse("Internal server error", 500, "failed");
        res.status(500).json(response);
      }
    }
  } catch (err: any) {
    error.error(`getAllSubscriptions err.message:${err.message}`);
    const response = generateResponse("Internal server error", 500, "failed");
    res.status(500).json(response);
  }
}

export async function getOneSubscriptionDetails(req: Request, res: Response) {
  const { id } = req.params;
  info.info(`getOneSubscriptionDetails initiated _id:${id}`);
  
  try {

    const projection = {
      _id: 1,
      planName: 1,
      type: 1,
      period: 1,
      features: 1,
      amount: 1,
    };

    const data = await collection.findOne({ _id: id, isDeleted: false }, { projection });
    if (data) {
      info.info(`getOneSubscriptionDetails _id:${id} data fetched`);
      const response = generateResponse(
        "Subscription plan found",
        200,
        "success",
        data
      );
      res.status(200).json(response);
    } else {
      error.error(`getOneSubscriptionDetails _id:${id} error: plan not found`);
      const response = generateResponse(
        "Subscription plan not found",
        404,
        "failed"
      );
      res.status(404).json(response);
    }
  } catch (err: any) {
    error.error(`getOneSubscriptionDetails err.message:${err.message}`);
    const response = generateResponse("Internal server error", 500, "failed");
    res.status(500).json(response);
  }
}

export async function getSubscriptionsByPeriod(req: Request, res: Response) {
  const { period }: any = req.query;
  info.info(`getSubscriptionsByPeriod initiated req.query:${req.query}`);
  if(!period)
  {
    error.error(`getSubscriptionsByPeriod error: period missing`);
    return res.status(400).json(generateResponse("Subscription period is missing", 400, "failed"));
  }
  try {
    const isAllowedPeriod = ["Monthly", "Yearly"];

    if (!isAllowedPeriod.includes(period)) {
      error.error(`getSubscriptionsByPeriod period:${period} error: invalid period`);
      const response = generateResponse(
        "Invalid subscription period",
        400,
        "failed"
      );
      return res.status(400).json(response);
    }
    if (collection) {
      const projection = {
        _id: 1,
        planName: 1,
        features: 1,
        type: 1,
        period: 1,
        amount: 1
      };
      const searchFilter = {
        period,
        isDeleted: false
      };
      const subscriptionData = await collection.find(searchFilter).project(projection).toArray();
      info.info(`getOneSubscriptionDetails period:${period} data fetched`);
      const response = generateResponse('Subscription List', 200, 'success', subscriptionData);
      res.status(200).send({
        response
      });
    }
  } catch (err: any) {
    error.error(`getSubscriptionsByPeriod period:${period} err.message:${err.message}`);
    const response = generateResponse("Internal server error", 500, "failed");
    res.status(400).json(response);
  }
}

export async function getSubsPlan (planId: string) {
  try{
    info.info(`getSubsPlan planId:${planId} initiated`);
    const planData = await collection.findOne({_id:planId},{projection:{
      planName: 1,
      type: 1,
      period: 1,
      amount: 1,
      features: 1
    }});
    if(!planData)
    {
      error.error(`getSubsPlan planId:${planId} error: plan not found`);
      return false;
    }
    else
    {
    info.info(`getSubsPlan planId:${planId} data fetched`);
    return planData;
    }
  }
  catch(err: any)
  {
    error.error(`getSubsPlan planId:${planId} err.message:${err.message}`);
    return false;
  }
}