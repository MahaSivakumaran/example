import express = require ("express");
import { Request, Response, NextFunction } from "express";
import { divCreate, divDelete, divTypeChange, divUpdate, getDivDetail, getDivListByOrg, createShifts, editShifts, deleteShifts, getOneShift, getAllShifts, getShiftNoList, getDivShift, getDivListAll, deleteAllDiv, divNameList, checkMainDiv, getDivNameList } from "../controller/divisionController";
import { firebaseValidation } from "../middleware/firebaseValidation";
import { divMgmt } from "../middleware/userValidation";
import { userAccess } from "../middleware/userAccessValidation";

export const divRouter = express.Router();
let accessValidation : any;
async function modifyBranchValidator(req: Request, res: Response, next: NextFunction){
    if((req as any).firebaseData.uid.includes("pa")){
        accessValidation = "ARO"; 
    }
    else if((req as any).firebaseData.uid.includes("orgAd")){
        accessValidation = "ARD";
    }
    
    userAccess(accessValidation) (req, res, next);
}

async function modifyShiftValidator(req: Request, res: Response, next: NextFunction){
    if((req as any).firebaseData.uid.includes("pa")){
        accessValidation = "ARO";
    }
    else if((req as any).firebaseData.uid.includes("orgAd")){
        accessValidation = "ARS";
    }
    userAccess(accessValidation) (req, res, next);

}
async function typeChangeValidator(req: Request, res: Response, next: NextFunction){
    if((req as any).firebaseData.uid.includes("pa")){
        accessValidation = "ARO";
    }
    else if((req as any).firebaseData.uid.includes("orgAd")){
        accessValidation = "MMD";
    }
    userAccess(accessValidation) (req, res, next);

}

divRouter.post("/create", firebaseValidation, divMgmt, modifyBranchValidator, divCreate);
divRouter.put("/update/:id", firebaseValidation, divMgmt, modifyBranchValidator, divUpdate);
divRouter.put("/delete/:id", firebaseValidation, divMgmt, modifyBranchValidator, divDelete);
divRouter.put("/typeChange/:id", firebaseValidation, divMgmt, typeChangeValidator, divTypeChange);
divRouter.get("/divisionListAll/:id", firebaseValidation, divMgmt, getDivListAll);
divRouter.get("/list/:id", firebaseValidation, divMgmt, getDivListByOrg);
divRouter.get("/getDivDetail/:id", firebaseValidation, divMgmt, getDivDetail);
divRouter.post("/shift/create/:id", firebaseValidation, divMgmt, modifyShiftValidator, createShifts);
divRouter.put("/shift/edit/:id/:shiftId", firebaseValidation, divMgmt, modifyShiftValidator, editShifts);
divRouter.delete("/shift/delete/:id/:shiftId", firebaseValidation, divMgmt, modifyShiftValidator, deleteShifts);
divRouter.get("/shift/any/:id/:shiftId", firebaseValidation, divMgmt, getOneShift);
divRouter.get("/shift/all/:id", firebaseValidation, divMgmt, getAllShifts);
divRouter.get("/shift/getShiftNo/list/:id", firebaseValidation, divMgmt, getShiftNoList);
divRouter.get("/getDivShift/:id", getDivShift); // S to S from User service
divRouter.post("/nameList", divNameList); // S to S from Orders & demand service
divRouter.get("/checkMainDiv", checkMainDiv); // S to S from User service
divRouter.get("/allList", firebaseValidation, divMgmt, getDivNameList);  // branch list for mobile/web