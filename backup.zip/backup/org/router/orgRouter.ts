import express = require ("express");
import { companyList, deleteOrg, getOrgDetail, getSubscriptionPlan, orgCreate, orgData, orgDetails, orgEdit, orgList, subscribePlan, unsubscribePlan } from "../controller/organisationController";
import { firebaseValidation } from "../middleware/firebaseValidation";
import { orgMgmt } from "../middleware/userValidation";
import { userAccess } from "../middleware/userAccessValidation";

export const orgRouter = express.Router();

orgRouter.post("/create", firebaseValidation, orgMgmt, userAccess("ARO"), orgCreate);
orgRouter.get("/getOrgDetail/:id", firebaseValidation, orgMgmt, userAccess("ARO"), getOrgDetail)
orgRouter.post("/list", firebaseValidation, orgMgmt, companyList);
orgRouter.get("/namelist", firebaseValidation, orgMgmt, orgList);
orgRouter.get("/orgDetails/:id", orgDetails);  // S to S from user service
orgRouter.post("/deleteOrg/:id", firebaseValidation, orgMgmt, userAccess("ARO"), deleteOrg);
orgRouter.post("/edit/:id", firebaseValidation, orgMgmt, userAccess("ARO"), orgEdit);
orgRouter.get("/getSubscription/:id", firebaseValidation, orgMgmt, userAccess("ARO"), getSubscriptionPlan);
orgRouter.put("/subscribe/:id", firebaseValidation, orgMgmt, userAccess("ARO"), subscribePlan);
orgRouter.put("/unsubscribe/:id", firebaseValidation, orgMgmt, userAccess("ARO"), unsubscribePlan);
orgRouter.post("/details", orgData);  // S to S from User service