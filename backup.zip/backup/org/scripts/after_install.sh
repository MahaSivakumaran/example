#!/bin/bash

# Switch to ec2-user
sudo -u ec2-user bash <<'EOF'

# Log the script execution
echo 'Run application_start.sh: ' >> /home/ec2-user/be-atvara-org-service/deploy.log

# Change directory
echo 'cd /home/ec2-user/be-atvara-org-service' >> /home/ec2-user/be-atvara-org-service/deploy.log
cd /home/ec2-user/be-atvara-org-service >> /home/ec2-user/be-atvara-org-service/deploy.log

# Source nvm
source /home/ec2-user/.nvm/nvm.sh

# Log the current PATH for troubleshooting
echo "PATH is: $PATH" >> /home/ec2-user/be-atvara-org-service/deploy.log

# Install npm dependencies
echo 'npm install' >> /home/ec2-user/be-atvara-org-service/deploy.log 
/home/ec2-user/.nvm/versions/node/v16.20.2/bin/npm install >> /home/ec2-user/be-atvara-org-service/deploy.log

# Start the application with pm2
echo 'pm2 start' >> /home/ec2-user/be-atvara-org-service/deploy.log 
/home/ec2-user/.nvm/versions/node/v16.20.2/bin/pm2 start /home/ec2-user/be-atvara-org-service/ecosystem.config.js --update-env >> /home/ec2-user/be-atvara-org-service/deploy.log

# Save the pm2 process list
echo 'pm2 save' >> /home/ec2-user/be-atvara-org-service/deploy.log 
/home/ec2-user/.nvm/versions/node/v16.20.2/bin/pm2 save >> /home/ec2-user/be-atvara-org-service/deploy.log

# Setup pm2 startup
echo 'pm2 startup' >> /home/ec2-user/be-atvara-org-service/deploy.log 
/home/ec2-user/.nvm/versions/node/v16.20.2/bin/pm2 startup >> /home/ec2-user/be-atvara-org-service/deploy.log

echo 'application_start.sh completed' >> /home/ec2-user/be-atvara-org-service/deploy.log

EOF
