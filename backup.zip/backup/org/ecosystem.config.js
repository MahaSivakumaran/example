module.exports = {
    apps: [
      {
        name: 'atvara-org-service',
        script: './app/app.ts',
        interpreter: './node_modules/.bin/ts-node',
      },
    ],
  };
  