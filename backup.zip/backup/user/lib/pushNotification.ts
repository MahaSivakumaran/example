const pack = require("firebasepackage");
import { info, error } from "../config/loggerConfig";

const admin = pack.fadmin;

export const pushNotification = async (
  FcmTokenAndDetails: {
    notification: {};
    token: string;
    data: any;
  }[]
) => {
  try {
    if (FcmTokenAndDetails.length === 0) {
      console.error("Error: Registration tokens array is empty.");
      error.error(`push Notification Registration tokens array is empty`);
      return false;
    } else {
      try {
        const res = await admin.messaging().sendAll(FcmTokenAndDetails);
        console.log("Successfully sent messages:", res);
        info.info(`push Notification:${res}`);
        return true;
      } catch (err) {
        console.error("Error sending messages:", err);
        error.error(`push Notification sendAll errorMessage:${err}`);
        return false;
      }
    }
  } catch (err: any) {
    console.log("err", err);
    error.error(`pushNotification errorMessage:${err}`);
    return false;
  }
};