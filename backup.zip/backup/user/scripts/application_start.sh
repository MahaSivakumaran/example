#!/bin/bash

# Switch to ec2-user
sudo -u ec2-user bash <<'EOF'

echo 'Run application_start.sh: ' >> /home/ec2-user/be-atvara-user-service/deploy.log
source /home/ec2-user/.nvm/nvm.sh

# Change directory
echo 'cd /home/ec2-user/be-atvara-user-service' >> /home/ec2-user/be-atvara-user-service/deploy.log
cd /home/ec2-user/be-atvara-user-service >> /home/ec2-user/be-atvara-user-service/deploy.log

# Print current working directory
echo 'Current working directory: $(pwd)' >> /home/ec2-user/be-atvara-user-service/deploy.log

# Restart the application with pm2
echo 'pm2 restart' >> /home/ec2-user/be-atvara-user-service/deploy.log
/home/ec2-user/.nvm/versions/node/v16.20.2/bin/pm2 restart /home/ec2-user/be-atvara-user-service/ecosystem.config.js --update-env >> /home/ec2-user/be-atvara-user-service/deploy.log

echo 'Finished application_start.sh: ' >> /home/ec2-user/be-atvara-user-service/deploy.log

EOF