import express = require("express");
import {
    createGodownUser,
    getAllGodownUsers,
    oneGowDownUser,
    editGodownUser,
    removeGodownUser,
    deactivateGodownUser,
    activateGodownUser,
    updateFcmToken,
    godownUserList,
    gUserDetails
} from "../controller/godownUserController";

import { userMgmt } from "../middleware/userValidation";
import { userAccess } from "../middleware/userAccessValidation";
import { firebaseValidation } from "../middleware/firebaseValidation";

export const orgGodownRouter = express.Router();

orgGodownRouter.post("/create", firebaseValidation ,userMgmt, userAccess("gUser"), createGodownUser);
orgGodownRouter.get("/all", firebaseValidation, userMgmt, userAccess("gUser"), getAllGodownUsers);
orgGodownRouter.get("/any/:id", firebaseValidation, userMgmt, userAccess("gUser"), oneGowDownUser);
orgGodownRouter.put("/edit/:id", firebaseValidation, userMgmt, userAccess("gUser"), editGodownUser);
orgGodownRouter.put("/remove/:id", firebaseValidation, userMgmt, userAccess("gUser"), removeGodownUser);
orgGodownRouter.put("/disable/:id", firebaseValidation, userMgmt, userAccess("gUser"), deactivateGodownUser);
orgGodownRouter.put("/enable/:id", firebaseValidation, userMgmt, userAccess("gUser"), activateGodownUser);
orgGodownRouter.put("/updateFcmToken/:id", firebaseValidation, updateFcmToken);
orgGodownRouter.get("/list", firebaseValidation, userMgmt, userAccess("gUser"), godownUserList);
orgGodownRouter.get("/details/:orgId", gUserDetails );
