import express = require("express");
import {
    createOrgSupervisor,
    getAllOrgSupervisor,
    oneOrgSupervisor,
    editOrgSupervisor,
    removeOrgSupervisor,
    deactivateOrgSupervisor,
    activateOrgSupervisor,
    supervisor,
    orgSupervisorDetails,
} from "../controller/orgSupervisorController";
import { userMgmt } from "../middleware/userValidation";
import { userAccess } from "../middleware/userAccessValidation";
import { firebaseValidation } from "../middleware/firebaseValidation";

export const orgSupervisor = express.Router();

orgSupervisor.post("/create",firebaseValidation, userMgmt, userAccess("divS"), createOrgSupervisor);
orgSupervisor.get("/all", firebaseValidation, userMgmt, userAccess("divS"), getAllOrgSupervisor);
orgSupervisor.get("/any/:id", firebaseValidation, userMgmt, userAccess("divS"),  oneOrgSupervisor);
orgSupervisor.put("/edit/:id", firebaseValidation, userMgmt, userAccess("divS"), editOrgSupervisor);
orgSupervisor.put("/remove/:id", firebaseValidation, userMgmt, userAccess("divS"), removeOrgSupervisor);
orgSupervisor.put("/disable/:id", firebaseValidation, userMgmt, userAccess("divS"), deactivateOrgSupervisor);
orgSupervisor.put("/enable/:id", firebaseValidation, userMgmt, userAccess("divS"), activateOrgSupervisor);
orgSupervisor.get("/list",firebaseValidation, userMgmt, userAccess("divS"), supervisor);
orgSupervisor.get("/details/:orgId",orgSupervisorDetails);