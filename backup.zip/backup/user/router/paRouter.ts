import express = require("express");
import {
    activatePa,
    createPa,
    deactivatePa,
    deletePa,
    getAllPa,
    getOnePa,
    self,
    selfEdit,
    updatePa
} from "../controller/paController";
import { userMgmt } from "../middleware/userValidation";
import { userAccess } from "../middleware/userAccessValidation";
import { firebaseValidation } from "../middleware/firebaseValidation";

export const paRouter = express.Router();

paRouter.post("/create", firebaseValidation, userMgmt, userAccess("PA"), createPa);
paRouter.get("/self", firebaseValidation, self);
paRouter.get("/all", firebaseValidation, userMgmt, userAccess("PA"), getAllPa);
paRouter.get("/any/:id", firebaseValidation, userMgmt, userAccess("PA"), getOnePa);
paRouter.put("/edit/:id", firebaseValidation, userMgmt, userAccess("PA"), updatePa);
paRouter.put("/remove/:id", firebaseValidation, userMgmt, userAccess("PA"), deletePa);
paRouter.put("/disable/:id", firebaseValidation, userMgmt, userAccess("PA"), deactivatePa);
paRouter.put("/enable/:id", firebaseValidation, userMgmt, userAccess("PA"), activatePa);
paRouter.put("/selfEdit",firebaseValidation, selfEdit);