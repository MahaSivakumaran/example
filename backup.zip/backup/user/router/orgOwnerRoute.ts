import express = require("express");
import {
    createOrgOwner,
    getAllOrgOwner,
    orgOwnerSelf,
    oneOrgOwner,
    editOrgOwner,
    removeOrgOwner,
    orgUserList,
    selfEdit,
    deactivateOrgOwner,
    activateOrgOwner,
    emailVerification,
    updateFcmToken,
    userCounts,
    inActiveUserList,
    divUserList
} from "../controller/orgOwnerController";
import { userMgmt } from "../middleware/userValidation";
import { userAccess } from "../middleware/userAccessValidation";
import { firebaseValidation } from "../middleware/firebaseValidation";
import { displayNotification, viewedNotification } from "../controller/subscriptionNotificationController";

export const orgOwnerRouter = express.Router();


orgOwnerRouter.post("/create", firebaseValidation, userMgmt, userAccess("orgOwner"), createOrgOwner);
orgOwnerRouter.get("/all", firebaseValidation, userMgmt, userAccess("orgOwner"), getAllOrgOwner);
orgOwnerRouter.get("/self", firebaseValidation, orgOwnerSelf);
orgOwnerRouter.get("/any/:id", firebaseValidation, userMgmt, userAccess("orgOwner"), oneOrgOwner);
orgOwnerRouter.put("/edit/:id", firebaseValidation, userMgmt, userAccess("orgOwner"), editOrgOwner);
orgOwnerRouter.put("/remove/:id", firebaseValidation, userMgmt, userAccess("orgOwner"), removeOrgOwner);
orgOwnerRouter.put("/disable/:id", firebaseValidation, userMgmt, userAccess("orgOwner"), deactivateOrgOwner);
orgOwnerRouter.put("/enable/:id", firebaseValidation, userMgmt, userAccess("orgOwner"), activateOrgOwner);
orgOwnerRouter.get("/orgUserList/:id", firebaseValidation, userMgmt, userAccess("orgOwner"), orgUserList);
orgOwnerRouter.get("/emailVerify", firebaseValidation, userMgmt, userAccess("orgOwner"), emailVerification);
orgOwnerRouter.put("/selfEdit",firebaseValidation, selfEdit);
orgOwnerRouter.put("/updateFcmToken", firebaseValidation, updateFcmToken);
orgOwnerRouter.put("/view/notification", viewedNotification);
orgOwnerRouter.get("/notifications", displayNotification);
orgOwnerRouter.get("/user/count", firebaseValidation, userMgmt, userCounts);
orgOwnerRouter.get("/inactive/list", firebaseValidation, userMgmt,  inActiveUserList);
orgOwnerRouter.get("/divAllUserList", firebaseValidation, userMgmt, divUserList);