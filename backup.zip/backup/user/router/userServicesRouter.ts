import express = require("express");
import { createOrgOwner, subscriptionNotification } from "../controller/orgOwnerController";
import { count, divCount, minItemAlert } from "../controller/godownUserController";
import { deleteShiftIdFromCollections } from "../controller/orgManagerController";
import { deleteNotification } from "../controller/subscriptionNotificationController";

export const userServicesRouter = express.Router();

userServicesRouter.post("/orgOwner/create", createOrgOwner); // S to S from Organisation service
userServicesRouter.post("/org/count",count); // S to S from Organisation service
userServicesRouter.post("/divCount",divCount); // S to S from Organisation service
userServicesRouter.post("/deleteShiftId", deleteShiftIdFromCollections); // S to S from Organisation service    
userServicesRouter.put("/notification/item/minQtyAlert", minItemAlert); // S to S from Product service
userServicesRouter.post("/sub/notification", subscriptionNotification); // S to S from Organisation service
userServicesRouter.put("/delete/notification", deleteNotification); // S to S from Organisation service