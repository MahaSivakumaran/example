import express = require("express");
import {
    createOrgManager,
    getAllOrgManager,
    removeOrgManager,
    editOrgManager,
    oneOrgManager,
    divUserList,
    deactivateOrgManager,
    activateOrgManager,
    deleteAllOrgUsers,
    inactiveAllDivUsers,
    managerList,
    orgManagerDetails
} from "../controller/orgManagerController";
import { userMgmt } from "../middleware/userValidation";
import { userAccess } from "../middleware/userAccessValidation";
import { firebaseValidation } from "../middleware/firebaseValidation";

export const orgManager = express.Router();

orgManager.post("/create", firebaseValidation, userMgmt, userAccess("divM"), createOrgManager);
orgManager.get("/all", firebaseValidation, userMgmt, userAccess("divM"), getAllOrgManager);
orgManager.get("/any/:id", firebaseValidation, userMgmt, userAccess("divM"), oneOrgManager);
orgManager.put("/edit/:id", firebaseValidation, userMgmt, userAccess("divM"), editOrgManager);
orgManager.put("/remove/:id", firebaseValidation, userMgmt, userAccess("divM"), removeOrgManager);
orgManager.put("/disable/:id", firebaseValidation, userMgmt, userAccess("divM"), deactivateOrgManager);
orgManager.put("/enable/:id", firebaseValidation, userMgmt, userAccess("divM"), activateOrgManager);
orgManager.get("/divUserList/:id",divUserList);
orgManager.post("/deleteAllOrgUsers/:orgId",deleteAllOrgUsers); // S to S from Organisation service
orgManager.put("/inactiveAllDivUsers/:id", inactiveAllDivUsers);  // S to S from Organisation service
orgManager.get("/list",firebaseValidation, userMgmt, userAccess("divM"), managerList);
orgManager.get("/detais/:orgId",orgManagerDetails);
