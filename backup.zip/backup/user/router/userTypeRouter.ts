import express = require("express");
import { userType } from "../controller/userTypeController";


export const userTypeRouter = express.Router();

userTypeRouter.get("/:entity", userType );