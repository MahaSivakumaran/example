import express = require("express");
import {
    createOrgAd,
    getAllOrgAdmin,
    orgAdminSelf,
    oneOrgAdmin,
    editOrgAdmin,
    removeOrgAdmin,
    selfEdit,
    deactivateOrgAdmin,
    activateOrgAdmin,
    adminList,
    orgAdminDetails
} from "../controller/orgAdminController";

import { userMgmt } from "../middleware/userValidation";
import { userAccess } from "../middleware/userAccessValidation";
import { firebaseValidation } from "../middleware/firebaseValidation";

export const orgAdmin = express.Router();

orgAdmin.post("/create", firebaseValidation, userMgmt, userAccess("orgAdmin"), createOrgAd);
orgAdmin.get("/all", firebaseValidation, userMgmt, userAccess("orgAdmin"), getAllOrgAdmin);
orgAdmin.get("/self", firebaseValidation, orgAdminSelf);
orgAdmin.get("/any/:id", firebaseValidation, userMgmt, userAccess("orgAdmin"), oneOrgAdmin);
orgAdmin.put("/edit/:id", firebaseValidation, userMgmt, userAccess("orgAdmin"), editOrgAdmin);
orgAdmin.put("/remove/:id", firebaseValidation, userMgmt, userAccess("orgAdmin"), removeOrgAdmin);
orgAdmin.put("/disable/:id", firebaseValidation, userMgmt, userAccess("orgAdmin"), deactivateOrgAdmin);
orgAdmin.put("/enable/:id", firebaseValidation, userMgmt, userAccess("orgAdmin"), activateOrgAdmin);
orgAdmin.put("/selfEdit",firebaseValidation, selfEdit);
orgAdmin.get("/list",firebaseValidation, userMgmt, userAccess("orgAdmin"), adminList);
orgAdmin.get("/details/:orgId",orgAdminDetails);

