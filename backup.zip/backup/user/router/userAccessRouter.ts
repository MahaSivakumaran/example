import express = require("express");
import { createNewUserAccess } from "../controller/userAccessController";


export const userAccessRouter = express.Router();

userAccessRouter.get("/createUserAccess/:entity/:type", createNewUserAccess);
