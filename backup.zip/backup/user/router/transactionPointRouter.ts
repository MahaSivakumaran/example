import express = require("express");
import {
    createTpUser,
    getAllTpusers,
    oneTpUser,
    editTpUser,
    removeTpUser,
    deactivateTpUser,
    activateTpUser,
    TPUserList,
    TPUsersDetails
} from "../controller/transactionPointController";
import { userMgmt } from "../middleware/userValidation";
import { userAccess } from "../middleware/userAccessValidation";
import { firebaseValidation } from "../middleware/firebaseValidation";
 
export const tpRouter = express.Router();
 
tpRouter.post("/create", firebaseValidation, userMgmt, userAccess("tUser"), createTpUser);
tpRouter.get("/all", firebaseValidation, userMgmt, userAccess("tUser"), getAllTpusers);
tpRouter.get("/any/:id", firebaseValidation, userMgmt, userAccess("tUser"), oneTpUser);
tpRouter.put("/edit/:id", firebaseValidation, userMgmt, userAccess("tUser"), editTpUser);
tpRouter.put("/remove/:id", firebaseValidation, userMgmt, userAccess("tUser"), removeTpUser);
tpRouter.put("/disable/:id", firebaseValidation, userMgmt, userAccess("tUser"), deactivateTpUser);
tpRouter.put("/enable/:id", firebaseValidation, userMgmt, userAccess("tUser"), activateTpUser);
tpRouter.get("/list", firebaseValidation, userMgmt, userAccess("tUser"), TPUserList);
tpRouter.get("/details/:orgId", TPUsersDetails);