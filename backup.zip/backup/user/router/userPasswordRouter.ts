import express = require("express");
import { Request, Response, NextFunction } from "express";
import { changePassword } from "../controller/userPasswordController";
import { passwordMgmt } from "../middleware/userValidation";
import { firebaseValidation } from "../middleware/firebaseValidation";
import { userAccess } from "../middleware/userAccessValidation";
export const userPasswordRouter = express.Router();

let userType: any;
const userTypeValidation = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  const id = req.params.id;

  if (id && id != "") {
    if (id.includes("pa")) {
      userType = "PA";
    } else if (id.includes("orgOwner")) {
      userType = "orgOwner";
    } else if (id.includes("orgAdmin")) {
      userType = "orgAdmin";
    } else if (id.includes("divM")) {
      userType = "divM";
    } else if (id.includes("divS")) {
      userType = "divS";
    } else {
      return res.send({
        status: false,
        message: "Invalid parameter",
        statusCode: 400,
      });
    }
  }
  userAccess(userType)(req, res, next);
};
userPasswordRouter.put(
  "/change/:id",
  firebaseValidation,
  userTypeValidation,
  passwordMgmt,
  changePassword
);
