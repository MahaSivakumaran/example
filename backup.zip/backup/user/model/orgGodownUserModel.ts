import { databaseConnection } from '../app/db';


export async function orgGodownUser() {
  try {
    const db = await databaseConnection();
    const collection = await db?.collection('orgGodownUser', {
      validator: {
        $jsonSchema: {
          bsonType: 'object',
          title: 'orgGodownUser',
          properties: {
            _id: {
              bsonType: 'string'
              
            },
            orgId:{
              bsonType: 'string'

            },
            divId:{
              bsonType: 'string'

            },
            name: {
              bsonType: 'string',
            },
            email: {
              bsonType: 'string',

            },
            mobileNumber: {
              bsonType: 'string',

            },
            isDeleted: {
              bsonType: 'bool',

            },
            isActive: {
              bsonType: 'bool',

            },
            shifts: {
              bsonType: 'array',
              items: {
                bsonType: 'string'
              },
            },
            fcmToken: {
              bsonType: 'string'
            },
            createdAt: {
              bsonType: 'date',
            },
            updatedAt: {
              bsonType: 'date',
            },
          },
          required: ['name', 'email', 'mobileNumber', 'shifts'],
        },
      },
    });
    return collection;
  } catch (err) {
    throw err;
  }
}