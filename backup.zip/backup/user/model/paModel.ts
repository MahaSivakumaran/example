import { databaseConnection } from '../app/db';

export async function createProductAdmin() {
    try {
      const db = await databaseConnection();
      const collection = await db?.collection('productAdmin', {
        validator: {
          $jsonSchema: {
            bsonType: 'object',
            title: 'productAdmin',
            properties: {
              _id: {
                bsonType: 'string'
                
              },
              name: {
                bsonType: 'string',
              },
              email: {
                bsonType: 'string',
                
              },
              mobileNumber: {
                bsonType: 'string',
                
              },
              isActive:{
                bsonType: 'bool',
                
              },
              isDeleted:{
                bsonType: 'bool',
                
              },
              createdAt: {
                bsonType: 'date',
              },
              updatedAt: {
                bsonType: 'date',
              },
            },
            required: ['name', 'email', 'mobileNumber'],
          },
        },
      });
      return collection;
    } catch (err) {
      throw err;
    }
  }