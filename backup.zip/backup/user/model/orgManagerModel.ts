import { databaseConnection } from '../app/db';

export async function orgManager() {
    try {
      const db = await databaseConnection();
      const collection = await db?.collection('organisationManager', {
        validator: {
          $jsonSchema: {
            bsonType: 'object',
            title: 'organisationManager',
            properties: {
              orgId:{
                bsonType: 'string'

              },
              divId:{
                bsonType: 'string'

              },
              _id: {
                bsonType: 'string'
                
              },
              name: {
                bsonType: 'string',
              },
              email: {
                bsonType: 'string',
                
              },
              mobileNumber: {
                bsonType: 'string',
                
              },
              isDeleted:{
                bsonType: 'bool',
                
              },
              isActive:{
                bsonType: 'bool',
                
              },
              shifts: {
                bsonType: 'array',
                items: {
                  bsonType: 'string'  
                },
              },
              createdAt: {
                bsonType: 'date',
              },
              updatedAt: {
                bsonType: 'date',
              },
            },
            required: ['name', 'email', 'mobileNumber','shifts',],
          },
        },
      });
      return collection;
    } catch (err) {
      throw err;
    }
  }
  