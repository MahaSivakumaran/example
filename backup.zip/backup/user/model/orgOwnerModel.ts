import { databaseConnection } from '../app/db';

export async function orgOwner() {
    try {
      const db = await databaseConnection();
      const collection = await db?.collection('organisationOwner', {
        validator: {
          $jsonSchema: {
            bsonType: 'object',
            title: 'organisationOwer',
            properties: {
              _id: {
                bsonType: 'string'
                
              },
              orgId:{
                bsonType: 'string'

              },
              name: {
                bsonType: 'string',
              },
              email: {
                bsonType: 'string',
                
              },
              mobileNumber: {
                bsonType: 'string',
                
              },
              isDeleted:{
                bsonType: 'bool',
                
              },
              isActive:{
                bsonType: 'bool'

              },
              fcmToken: {
                bsonType: 'string'
              },
              createdAt: {
                bsonType: 'date',
              },
              updatedAt: {
                bsonType: 'date',
              },
            },
            required: ['orgId','name', 'email', 'mobileNumber'],
          },
        },
      });
      return collection;
    } catch (err) {
      throw err;
    }
  }