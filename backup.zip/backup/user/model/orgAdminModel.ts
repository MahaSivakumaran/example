import { databaseConnection } from '../app/db';

export async function orgAdmin() {
    try {
      const db = await databaseConnection();
      const collection = await db?.collection('organisationAdmin', {
        validator: {
          $jsonSchema: {
            bsonType: 'object',
            title: 'organisationAdmin',
            properties: {
              _id: {
                bsonType: 'string'
                
              },
              orgId:{
                bsonType: 'string'

              },
              name: {
                bsonType: 'string',
              },
              email: {
                bsonType: 'string',
                
              },
              mobileNumber: {
                bsonType: 'string',
                
              },
              isDeleted:{
                bsonType: 'bool',
                
              },
              isActive:{
                bsonType: 'bool'
                
              },
              createdAt: {
                bsonType: 'date',
              },
              updatedAt: {
                bsonType: 'date',
              },
            },
            required: ['name', 'email', 'mobileNumber',],
          },
        },
      });
      return collection;
    } catch (err) {
      throw err;
    }
  }