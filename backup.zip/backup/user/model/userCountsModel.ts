import { databaseConnection } from "../app/db";

export async function createUserCounts() 
{
  try {
    const db = await databaseConnection();
    const collection = await db?.collection('userCounts', {
      validator: {
        $jsonSchema: {
          bsonType: 'object',
          title: 'UserCounts',
          properties: {
            pa: {
              bsonType: 'int',
            },
            orgOwner: {
              bsonType: 'int',
            },
            orgAd: {
              bsonType: 'int'
            },
            divM: {
                bsonType: 'int'
              },
            divS: {
                bsonType: 'int'
              },
            tUser: {
                bsonType: 'int'
              },
            gUser: {
                bsonType: 'int'
              },
          },
        },
      },
    });
    return collection;
  } catch (err) {
    console.log(err)
  }
}