import { databaseConnection } from "../app/db";

export async function subNotification() {
  try {
    const db = await databaseConnection();
    const collection = await db?.collection("subscriptionNotification", {
      validator: {
        $jsonSchema: {
          bsonType: "object",
          title: "subscriptionNotification",
          properties: {
            _id: {
              bsonType: "string",
            },
            userId: {
              bsonType: "string",
            },
            orgId: {
              bsonType: "string",
            },
            isExpired: {
              bsonType: "bool",
            },
            isViewed: {
              bsonType: "bool",
            },
            isDeleted: {
              bsonType: "bool",
            },
            createdAt: {
              bsonType: "date",
            },
            updatedAt: {
              bsonType: "date",
            },
          },
          required: ["userId", "orgId", "isExpired"],
        },
      },
    });
    return collection;
  } catch (err) {
    console.log(err);
  }
}