import { convertAccessToGeneral } from "./controller/userAccessController";
import { handleAuthError, handleSetCustomUserClaimsError } from "./handler/errorHandlers";
const pack = require('firebasepackage');

const admin = pack.fadmin;
export async function createUser(req: any) {

    const email = req.body.email ? req.body.email : null ;
    const mobileNumber = req.body.mobileNumber ? req.body.mobileNumber : null ;
    const password = req.body.password ? req.body.password : null;
    const isMain = typeof req.body.isMain ==='boolean' ? req.body.isMain : null;
    const credentials = {
        uid: req.body.uid,
        displayName: req.body.name,
        ...(email && {email: email}),
        ...(mobileNumber && {mobileNumber: mobileNumber}),
        ...(password && {password: password}),
        ...(typeof isMain === 'boolean' ? { isMain: isMain } : {})
    };
    let access;
    if(req.body.access){
        access = await convertAccessToGeneral(req.body.access);
    };
    let userType = req.body.userType;
    var customClaims =
    {
        access,
        orgId: req.body.orgId,
        userType
    };
    return new Promise(async(resolve, reject)=>
    {
     admin
    .auth()
    .createUser(credentials)
    .then((userRecord:any) =>{
        admin
        .auth()
        .setCustomUserClaims(userRecord.uid, {customClaims:customClaims})
        .then(()=>{
            var fResponse = {uid:userRecord.uid ,message:"success"};
            resolve(fResponse)
        })
        .catch((err:any)=>{
            var handledError = handleSetCustomUserClaimsError(err)
            reject(handledError)
        })
    })
    .catch((err:any)=>{
        var handledError = handleAuthError(err)
        reject(handledError)
    })
    })
}

export async function updateUser (uid:any, userData:any)
{
    const displayName = userData.name ? userData.name : null;
    const email = userData.email ? userData.email : null ;
    const mobileNumber = userData.mobileNumber ? userData.mobileNumber : null ;
    const credentials = {
        ...(email && {email: email}),
        ...(mobileNumber && {mobileNumber: mobileNumber}),
        ...(displayName && {displayName: displayName})
    };
    let access;
    if(userData.access){
        access = await convertAccessToGeneral(userData.access);
    };
    const userType = userData.userType;
    var customClaims = 
        {
        ...(access && {access: access}),
        orgId: userData.orgId,
        userType
        };
    return new Promise(async (resolve, reject) =>{
    admin
    .auth()
    .updateUser(uid, credentials)
    .then (()=>{ 
        admin
        .auth()
            .setCustomUserClaims(uid, {customClaims: customClaims})
            .then(()=>{
                var fResponse = {uid:uid ,message:"success"};
                resolve(fResponse)
            })
            .catch((err:any) => {
                var handledError = handleSetCustomUserClaimsError(err)
                reject(handledError) 
            })
        })
        .catch((err:any) =>{
            var handledError = handleAuthError(err);
            reject(handledError);
        })
        })
 
}

export async function deleteUser (uid:any){
 return new Promise(async (resolve, reject)=>{
    admin.
    auth()
    .deleteUser(uid)
    .then(() =>{
        resolve(true);
    })
    .catch((err:any)=>{
        reject(err);
    })
    })
}


export async function updatePassword(uid: any, newPassword: string) {
  return new Promise(async (resolve, reject) => {
    try {
      const userRecord = await admin.auth().updateUser(uid, {
        password: newPassword,
      });
      resolve(true);
    } catch (err: any) {
      console.error("Error:", err.message);
      reject(err);
    }
  });
}

export async function updateUserSelf (uid:any, userData:any)
{
    const displayName = userData.name ? userData.name : null;
    const email = userData.email ? userData.email : null ;
    const mobileNumber = userData.mobileNumber ? userData.mobileNumber : null ;
    const credentials = {
        ...(email && {email: email}),
        ...(mobileNumber && {mobileNumber: mobileNumber}),
        ...(displayName && {displayName: displayName})
    };
    return new Promise(async (resolve, reject) =>{
    admin
    .auth()
    .updateUser(uid, credentials)
    .then (()=>{ 
        resolve("success");
     })
    .catch((err:any) =>{
        var handledError = handleAuthError(err);
        reject(handledError);
    })
    })
 
}

export async function getUserAccess (uid : any) {
    return new Promise(async(resolve, reject)=>
    {
        admin.auth().getUser(uid)
        .then((userRecord : any) => {
            resolve(userRecord.customClaims.customClaims.access)
        })
        .catch((error: any) => {
            const err = handleAuthError(error);
            reject(err);
        });
    });
}

export async function disableUser (uid: any) {
    return new Promise(async(resolve, reject)=>
    {
        await admin.auth().updateUser(uid, {
                disabled: true
            })
            .then(() => {
                resolve(true);
            })
            .catch((error: any) => {
                const err = handleAuthError(error);
                reject(err);
            });
    });
}

export async function enableUser (uid: any) {
    return new Promise(async(resolve, reject)=>{
        await admin.auth().updateUser(uid, {
            disabled: false
        })
        .then((res: any) => {
            resolve(true);
        })
        .catch((error: any) => {
            const err = handleAuthError(error);
            reject(err);
        });
    })
}

export async function existingEmailCheck(email: any) {
    return new Promise((resolve, reject) => {
        admin
          .auth()
          .getUserByEmail(email)
          .then((userRecord: any) => {
            resolve(!!userRecord);
          })
          .catch((error: any) => {
            if (error.code === 'auth/user-not-found') {
              resolve(false);
            } else {
              reject(error);
            }
          });
      });
  }