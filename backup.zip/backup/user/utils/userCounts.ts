import { info, error } from "../config/loggerConfig";
import { createUserCounts } from "../model/userCountsModel";


export async function createusercount() {
    try {
        var coll = await createUserCounts();
        let data = await coll.findOne();
        if (data === null) {
            const collection = await createUserCounts();
            await collection.insertOne({
                pa: 1000,
                orgOwner:1000,
                orgAd:1000,
                divM:1000,
                divS:1000,
                tUser:1000,
                gUser:1000

            });
            info.info(`createPA document created successfully`);
        }
    }
    catch (err: any) {
        error.error(`createPA errorMessage:${err}`);
    }
}

export async function addUser(user: any) {

    try {
        let collection = await createUserCounts();
        let list = await collection.find({}).toArray();
        let id = list[0]._id;
        switch (user) {
            case "pa":
                let pa = list[0].pa + 1;
                await collection.findOneAndUpdate({ _id: id }, {
                    $set: { pa: pa }
                },
                    {
                        new: true
                    });
                pa = "pa_" + pa;
                return pa;

            case "orgOwner":
                let orgOwner = list[0].orgOwner + 1;
                await collection.findOneAndUpdate({ _id: id }, {
                    $set: { orgOwner: orgOwner }
                },
                    {
                        new: true
                    });
                    orgOwner = "orgOwner_" + orgOwner;
                return orgOwner;

            case "orgAd":
                let orgAd = list[0].orgAd + 1;
                await collection.findOneAndUpdate({ _id: id }, {
                    $set: { orgAd: orgAd }
                },
                    {
                        new: true
                    });
                    orgAd = "orgAd_" + orgAd;
                return orgAd;
                
            case "divM":
                let divM = list[0].divM+1;
                await collection.findOneAndUpdate({_id: id},{
                    $set : {divM:divM}
                  },
                  {
                    new : true
                  });
                  divM = "divM_"+divM;
                return divM;
            
            case "divS":
                let divS = list[0].divS+1;
                await collection.findOneAndUpdate({_id: id},{
                    $set : {divS:divS}
                  },
                  {
                    new : true
                  });
                  divS = "divS_"+divS;
                return divS;

            case "tUser":
                let tUser = list[0].tUser+1;
                await collection.findOneAndUpdate({_id: id},{
                    $set : {tUser:tUser}
                  },
                  {
                    new : true
                  });
                  tUser = "tUser_"+tUser;
                return tUser;

            case "gUser":
                let gUser = list[0].gUser+1;
                await collection.findOneAndUpdate({_id: id},{
                    $set : {gUser:gUser}
                  },
                  {
                    new : true
                  });
                  gUser = "gUser_" + gUser;
                return gUser;

            default:
                return false;
        }
    }
    catch (err) {
        error.error(`createID error:${err}`);
        return false;
    }
}

export async function deleteCount(user: any) {

    try {
        let collection = await createUserCounts();
        let list = await collection.find({}).toArray();
        let id = list[0]._id;
        switch (user) {
            case "pa":
                let pa = list[0].pa;
                pa--;
                await collection.findOneAndUpdate({ _id: id }, {
                    $set: { pa: pa }
                },
                    {
                        new: true
                    });
                pa = "pa_" + pa;
                return pa;

            case "orgOwner":
                let orgOwner = list[0].orgOwner;
                orgOwner--;
                await collection.findOneAndUpdate({ _id: id }, {
                    $set: { orgOwner: orgOwner }
                },
                    {
                        new: true
                    });
                    orgOwner = "orgOwner_" + orgOwner;
                return orgOwner;

            case "orgAd":
                let orgAd = list[0].orgAd;
                orgAd--;
                await collection.findOneAndUpdate({ _id: id }, {
                    $set: { orgAd: orgAd }
                },
                    {
                        new: true
                    });
                    orgAd = "orgAd_" + orgAd;
                return orgAd;
                
            case "divM":
                let divM = list[0].divM;
                divM--;
                await collection.findOneAndUpdate({_id: id},{
                    $set : {divM:divM}
                  },
                  {
                    new : true
                  });
                  divM = "divM_"+divM;
                return divM;
            
            case "divS":
                let divS = list[0].divS;
                divS--;
                await collection.findOneAndUpdate({_id: id},{
                    $set : {divS:divS}
                  },
                  {
                    new : true
                  });
                  divS = "divS_"+divS;
                return divS;

            case "tUser":
                let tUser = list[0].tUser;
                tUser--;
                await collection.findOneAndUpdate({_id: id},{
                    $set : {tUser:tUser}
                  },
                  {
                    new : true
                  });
                  tUser = "tUser_"+tUser;
                return tUser;

            case "gUser":
                let gUser = list[0].gUser;
                gUser--;
                await collection.findOneAndUpdate({_id: id},{
                    $set : {gUser:gUser}
                  },
                  {
                    new : true
                  });
                  gUser = "gUser_" + gUser;
                return gUser;

            default:
                return false;
        }
    }
    catch (err) {
        error.error(`DeleteID error:${err}`);
        return false;
    }
}