export class ApiFeatures {
    collection: any;
    query: any;
    page: any;
    sort: any;
    sortBy: any;
    pageSize: any;
    constructor(collection: any, query: any, page: any, sort: any, sortBy: any = 'desc', pageSize: any) {
        this.collection = collection;
        this.query = query;
        this.page = page;
        this.sort = sort;
        this.sortBy = sortBy;
        this.pageSize = pageSize;
    }
    async searchAndPaginate() {
        const { query, page, sort, sortBy, pageSize } = this;

        const searchFilter: any = {
            isDeleted: false,
            ...(query
                ? {
                      $or: [
                          {
                              name: {
                                  $regex: query,
                                  $options: 'i',
                              },
                          },
                          {
                              email: {
                                  $regex: query,
                                  $options: 'i',
                              },
                          },
                          {
                              mobileNumber: {
                                  $regex: query,
                                  $options: 'i',
                              },
                          },
                      ],
                  }
                : {}),
        };
        const currentPage = parseInt(page as string, 10) || 1;
        const page_Size = parseInt(pageSize as string, 10) || 10;
       const sortOptions: any = {};
         if (sort && (sort === 'name' || sort === 'email' || sort === 'mobileNumber' || sort === 'orgName')) {
            sortOptions[sort] = sortBy === 'desc' ? -1 : 1;
        } else {
            sortOptions['_id'] = -1;
        }
        const projection = {
            _id: 1,
            name: 1,
            email: 1,
            mobileNumber: 1,
            divisionCount: 1,
            usersCount: 1,
            godownCount: 1,
            shifts: 1,
            orgId: 1,
            isActive: 1,
        };
        const aggregatePipeline = [
            { $match: searchFilter },
            { $sort: sortOptions },
            {
                $facet: {
                    metadata: [
                        { $skip: (currentPage - 1) * page_Size },
                        { $limit: page_Size },
                        { $project: projection },
                    ],
                    totalCount: [
                        { $count: 'value' },
                    ],
                },
            },
            { $unwind: '$totalCount' },
        ];
        const results = await this.collection.aggregate(aggregatePipeline).toArray();
        const list = results[0].metadata || [];
        const count = results[0].totalCount ? results[0].totalCount.value : 0;
        return {
            totalCount: count,
            list,
        };
    }
}