import {MongoClient} from 'mongodb';
import { info, error } from "../config/loggerConfig";

let data: any ;


export async function databaseConnection() {
    
    if(data) return data

    info.info(`Database connectivity called`);

    try {        
        const dbUserName = process.env.DATABASE_USERNAME;
        const dbPassword = process.env.DATABASE_PASSWORD;
        const baseURL = process.env.BASE_URL;
        const port = process.env.DATABASE_PORT;
        const database = process.env.DATABASE_NAME;
        const authSource = process.env.DATABASE_SOURCE
        const url = `mongodb://${dbUserName}:${dbPassword}@${baseURL}:${port}/?authSource=${authSource}`;
        const client = new MongoClient(url);
        await client.connect();
        data = client.db(database);
        
        if(data)
        { 
            info.info(`Database connected`);
            console.log('Data base connected');
        }
        return data;
        
    } catch (err) {
        error.error(`Database not connected error:${err}`);
        console.log('Internal server error');
   }
    
}