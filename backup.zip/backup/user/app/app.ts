import dotenv from 'dotenv';
import bodyParser from 'body-parser';
import { databaseConnection } from './db';
import express, { Application } from 'express';
import swaggerUi from 'swagger-ui-express';
import * as YAML from 'yamljs';
import path from 'path';
var cors = require("cors");
import { createusercount } from '../utils/userCounts';
dotenv.config();
import { paRouter } from '../router/paRouter';
import {  orgOwnerRouter } from '../router/orgOwnerRoute';
import { orgAdmin } from '../router/orgAdminRouter';
import { orgManager } from '../router/orgManagerRouter';
import { orgSupervisor } from '../router/orgSupervisorRouter';
import { tpRouter } from '../router/transactionPointRouter';
import { orgGodownRouter } from '../router/godownRouter';
import { osInstance } from '../controller/orgSupervisorController';
import { tpInstance } from '../controller/transactionPointController';
import { paInstance } from '../controller/paController';
import { ownerInstance } from '../controller/orgOwnerController';
import { omInstance } from '../controller/orgManagerController';
import { oaInstance } from '../controller/orgAdminController';
import { ogInstance } from '../controller/godownUserController';
import httpContext from 'express-http-context';
import { userServicesRouter } from '../router/userServicesRouter';
import { userTypeRouter } from '../router/userTypeRouter';
import { userPasswordRouter } from '../router/userPasswordRouter';
import { userAccessRouter } from '../router/userAccessRouter';
import { subNotificationInstance } from '../controller/subscriptionNotificationController';

const swaggerDocument = YAML.load(path.join(__dirname, '../config/swagger.yaml'));
export const app: Application = express();
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument));
databaseConnection()
.then(()=>{
    createusercount();
    paInstance();
    ownerInstance();
    osInstance();
    tpInstance();
    omInstance();
    oaInstance();
    ogInstance();
    subNotificationInstance();
})
.catch((err)=>{
    console.log(err)
})

const {PORT} = process.env

app.use(express.json());
app.use(bodyParser.json());
app.use(httpContext.middleware);
app.use(cors());


app.use("/api/userServices",userServicesRouter);
app.use("/api/password",userPasswordRouter);
app.use("/api/pa",paRouter);
app.use("/api/orgOwner",orgOwnerRouter);
app.use("/api/oa",orgAdmin);
app.use("/api/om",orgManager);
app.use("/api/os",orgSupervisor);
app.use("/api/og",orgGodownRouter);
app.use("/api/tp",tpRouter);
app.use("/api/userType",userTypeRouter);
app.use("/api/userAccess", userAccessRouter);


app.listen(PORT,()=>{
    console.log(`Server connected to the PORT : ${PORT}`)
})

