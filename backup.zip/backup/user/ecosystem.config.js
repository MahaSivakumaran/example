module.exports = {
    apps: [
      {
        name: 'atvara-user-service',
        script: './app/app.ts',
        interpreter: './node_modules/.bin/ts-node',
      },
    ],
};       
  