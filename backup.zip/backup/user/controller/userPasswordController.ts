import { Request, Response } from "express";
import { info, error } from "../config/loggerConfig";
import { generateResponse } from "../utils/responseGenerate";
import { updatePassword } from "../firebase";

export async function changePassword(req: Request, res: Response) {
  info.info(`user password update initiated`);
  info.info(`user password update req.body:${JSON.stringify(req.body)}`);

  try {
    const { id } = req.params;
    if (!id) {
      error.error(`changePassword error: id missing`)
      return res.status(404).json(generateResponse("Id is missing",404,"failed"))
    }
    const newPassword: string = req.body.newPassword;

    if (!id || id === "") {
      error.error(`User id is missing..!`);
      return res.status(404).send({
        success: false,
        message: "User id is missing..!",
      });
    }

    await updatePassword(id, newPassword)
      .then(async () => {
        info.info(`user password updated successfully`);
        const response = generateResponse(
          "user password updated successfully",
          200,
          "success"
        );
        res.status(200).json(response);
      })
      .catch((err: any) => {
        error.error(`user update password error:${err}`);
        res.status(500).send({
          success: false,
          message: err.message,
        });
        return;
      });
  } catch (err: any) {
    error.error(`user update password errorMessage:${err}`);
    res.status(500).json({ success: false, error: "Internal Server Error" });
  }
}
