import { Request, Response } from "express";

export async function userType(req: Request, res: Response) {
    const {entity} = req.params;
    let uTypes = [];
    let userMgmt = req.body.userMgmt;
    // let userMgmt = (req as any).firebaseData.customClaims.access.userMgmt;
    switch(entity){
        case "hotel":
            if(userMgmt) {
                for(let userTypes in userMgmt){
                    console.log("userTypes", userTypes)
                    switch(userTypes){
                        case "pa":
                            if(userMgmt[userTypes]){
                            uTypes.push({
                                name: "Product Admin",
                                accessEndpoint: "/pa",
                                submitEndPoint: "pa"    
                            });  
                                }
                            break;
                        case "orgOwner":
                            if(userMgmt[userTypes]){
                            uTypes.push({
                                name: "Hotel Owner",
                                accessEndPoint: "/orgOwner",
                                submitEndPoint: "orgOwner"
                            });
                                }
                            break;
                        case "orgAdmin":
                            if(userMgmt[userTypes]){
                            uTypes.push({
                                name: "Hotel Admin",
                                accessEndpoint: "/orgAdmin",
                                submitEndPoint: "orgAdmin"    
                            });
                                }
                            break;
                        case "divM":
                            if(userMgmt[userTypes]){
                            uTypes.push({
                                name: "Branch Manager",
                                accessEndpoint: "/divM",
                                submitEndPoint: "divM"    
                            });
                                }
                            break;
                        case "divS":
                            if(userMgmt[userTypes]){
                            uTypes.push({
                                name: "Branch Supervisor",
                                accessEndpoint: "/divS",
                                submitEndPoint: "divS"    
                            });
                                }
                            break;
                    }
                }
            }
            else {
                res.status(403).send({
                    message:"Forbidden"
                });
                return;
            }
    }
    res.status(200).send({
        success: true,
        userType: uTypes
    })
}