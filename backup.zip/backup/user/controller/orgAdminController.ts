import { Request, Response, NextFunction } from "express";
import { info, error } from "../config/loggerConfig";
import { ApiFeatures } from "../utils/apiFeatures";
import { addUser } from "../utils/userCounts";
import { orgAdmin } from "../model/orgAdminModel";
import { generateResponse } from "../utils/responseGenerate";
import { createUser, deleteUser, disableUser, enableUser, getUserAccess, updateUser, updateUserSelf } from "../firebase";
import axios from 'axios';
import { convertAccessForHotel } from "./userAccessController";
const baseURL = process.env.BASE_URL;
const orgPort = process.env.ORG_PORT;


let collection: any;
export const oaInstance = async () => {
  collection = await orgAdmin();
}

export async function createOrgAd(req: Request, res: Response,) {

  info.info(`createOrgAd initiated`);
  info.info(`createOrgAd reqParams:${JSON.stringify(req.body)}`);

  try {
    const { name, email, mobileNumber, orgId } = req.body;
    const id = await addUser('orgAd');
    req.body.uid = id;
    req.body.userType = "orgAd";
    const insertData ={
      _id: id,
      orgId,
      name,
      email,
      mobileNumber,
      isActive: true,
      isDeleted: false,
      createdAt: new Date(),
      updatedAt: new Date()
    }

    await createUser(req)
      .then(async () => {
        info.info("Firebase user created");
        await collection.insertOne(insertData);
        const response = generateResponse('userDocument created successfully', 200, 'success')
        res.status(200).json(response);
        info.info(`createOrgAd insertData ${JSON.stringify(insertData)}`);32
      })
      .catch((err) => {
        error.error(`firebase user not created error:${err.message}`);
        res.status(err.status).send({ message: err.message });
        return;
      });

  } catch (err: any) {
    error.error(`createOrgAd errorMessage:${err}`);
    res.status(500).json(generateResponse("Internal server error",500,"failed"));
    
  }
}


// // Get All Orgnization Admin

export async function getAllOrgAdmin(req: Request, res: Response) {

  info.info(`getAllOrgAdmin initiated`);
  info.info(`getAllOrgAdmin reqParams:${JSON.stringify(req.query)}`);

  try {
    if (collection) {
      const { query, page, sort, sortBy, pageSize } = req.query;
      const queryHandler = new ApiFeatures(collection, query, page, sort, sortBy, pageSize);
      const userList = await queryHandler.searchAndPaginate();

      if (userList && userList.list && Array.isArray(userList.list)) {
        const ids  = userList.list.map((user: any) => user.orgId);    
        
        const orgDetailsResponse = await axios.post(`http://${baseURL}:${orgPort}/api/org/details`,{ids})        
        const orgDetailsMap = new Map(orgDetailsResponse.data.map((org: any) => [org._id, org]));
        const enrichedUserList = userList.list.map((user, index) => ({
          ...user,
          orgDetails: orgDetailsMap.get(user.orgId)
        }));

        const response = generateResponse('userDocument fetched successfully', 200, 'success', {
          ...userList,
          list: enrichedUserList,
        });

        info.info(`getAllOrgAdmin document created successfully`);
        res.status(200).json(response);
      } else {
        const response = generateResponse('invalid request', 404, 'error', userList);
        res.status(400).json(response);
      }
    }
  } catch (err: any) {
    error.error(`getAllOrgAdmin errorMessage:${err.message}`);
    res.status(500).json(generateResponse("Internal server error",500,"failed"));
  }
}


// Org Admin Self

export async function orgAdminSelf(req: Request, res: Response) {

  info.info(`orgAdminSelf initiated`);
  info.info(`orgAdminSelf reqParams:${JSON.stringify(req.headers)}`);

  try {
    if (collection) {

      const userAgent = JSON.parse((req as any).headers['x-user-agent']);
      const id = userAgent.userId
      if (!id) {
        error.error(`orgAdminSelf error: id missing`)
        return res.status(404).json(generateResponse("Id is missing",404,"failed"))
      }
      const projection = {
        _id: 1,
        name: 1,
        email: 1,
        mobileNumber: 1,
        orgId: 1
      };

      info.info(`orgAdminSelf fetched for id : ${id}`);
      const data = await collection.findOne({ _id: id }, { projection });
      const axiosResponse = await axios.get(`http://${baseURL}:${orgPort}/api/org/orgDetails/${data.orgId}`);
      const userData = {
        data, ...axiosResponse.data
      }
      const response = generateResponse('userDocument found successfully', 200, 'success', userData)
      res.status(200).json(response);

    }
  } catch (err: any) {
    error.error(`getOrgAdminSelf errorMessage:${err.message}`);
    res.status(500).json(generateResponse("Internal server error",500,"failed"));

  }
}

// Get One Org Admin

export async function oneOrgAdmin(req: Request, res: Response) {

  info.info(`oneOrgAdmin initiated`);
  info.info(`oneOrgAdmin reqParams:${JSON.stringify(req.params)}`);

  try {
    if (collection) {
      const { id } = req.params;
      if (!id) {
        error.error(`oneOrgAdmin error: id is missing`)
        return res.status(404).json(generateResponse("Id is missing", 404, "failed"))
      }

      const projection = {
        _id: 1,
        name: 1,
        email: 1,
        mobileNumber: 1,
        orgId: 1,
        isActive:1
      };

      const user = await collection.findOne({ _id: id }, { projection });
      if (user) {
        const axiosResponse = await axios.get(`http://${baseURL}:${orgPort}/api/org/orgDetails/${user.orgId}`);
        const userData = {
        user,
        orgDetails: axiosResponse.data,
        };

      await getUserAccess(id)
      .then(async(access) =>{
        (userData as any).access  = await convertAccessForHotel(access);
      })
      .catch((err) =>{
        error.error(`getUserById access error:${err}`);
      });

        const response = generateResponse('userDocument found', 200, 'success', userData)
        res.status(200).json(response);
        info.info(`oneOrgAdmin data:${JSON.stringify(userData)}`)
      } else {
        const response = generateResponse('user not found', 404, 'error')
        res.status(404).json(response);
      }

    }
  } catch (err: any) {
    error.error(`getUserById errorMessage:${err.message}`);
    res.status(500).json(generateResponse("Internal server error",500,"failed"));
  }
}


// //update Org Admin details

export async function editOrgAdmin(req: Request, res: Response, next: NextFunction) {

  info.info(`editOrgAdmin  edit initiated`);
  info.info(`editOrgAdmin reqParams:${JSON.stringify(req.params)}`);
  info.info(`editOrgAdmin req.body: ${JSON.stringify(req.body)}`);

  const { id } = req.params;
  if (!id) {
    error.error(`editOrgAdmin error: id is missing`)
    return res.status(404).json(generateResponse("Id is missing", 404, "failed"))
  }
  const data = req.body
  const name = data.name;
  const email = data.email;
  const mobileNumber = data.mobileNumber;
  data.userType = "orgAd";
  const updatedData = {
    name,
    mobileNumber,
    email,
    updatedAt: new Date()
  };
  try {
    await updateUser(id, data)
      .then(async () => {
        await collection.findOneAndUpdate({ _id: id }, {
          $set: updatedData
        },
          {
            new: true
          })
        info.info(`editOrgAdmin edited successfully for id : ${id} and updatedData:${updatedData}`)
        const response = generateResponse('userDocument updated successfully', 200, 'success')
        res.status(200).json(response);
      })
      .catch((err) => {
        res.status(500).send({
          message: "Something went wrong",
          error: err
        });
      });

  } catch (err: any) {
    error.error(`editOrgAdmin errorMessage:${err.message}`);
    res.status(500).json({ success: false, error: 'Internal Server Error' });

  }
}

//delete Org Admin

export async function removeOrgAdmin(req: Request, res: Response, next: NextFunction) {
  info.info(`removeOrgAdmin initiated`);
  info.info(`removeOrgAdmin reqParams:${JSON.stringify(req.params)}`);

  const { id } = req.params;
  if (!id) {
    error.error(`removeOrgAdmin error: id is missing`)
    return res.status(404).json(generateResponse("Id is missing", 404, "failed"))
  }
    try {
    await deleteUser(id)
      .then(async () => {
        info.info(`firebase user deleted`);
        await collection.findOneAndUpdate({ _id: id }, {
          $set: {
            isDeleted: true,
            updatedAt: new Date()
          }
        }, { new: true });
        info.info(`orgAdmin sucessfuly deleted for id : ${id}`);
        const response = generateResponse('userDocument deleted successfully', 200, 'success')
        res.status(200).json(response);
      })
      .catch((err) => {
        error.error(`removeOrgAdmin firebase error:${err}`)
        res.status(500).send({
          success: false,
          message: "Something went wrong"
        });
      })

  } catch (err: any) {
    error.error(`removeOrgAdmin error : ${err.message}`)
    res.status(500).json({ success: false, error: 'Internal Server Error' });

  }
}

export async function selfEdit (req: Request, res: Response){
  
  try {
    info.info(`selfEdit initiated`);
    info.info(`selfEdit req.body: ${JSON.stringify(req.body)}`);
    
    const userAgent = JSON.parse((req as any).headers['x-user-agent']);
    const id = userAgent.userId
    const data = req.body
    const name = data.name;
    const email = data.email;
    const mobileNumber = data.mobileNumber
    const updatedData = {
      name,
      mobileNumber,
      email,
      updatedAt: new Date()
    }
    await updateUserSelf(id, updatedData)
    .then(async ()=>{
      await collection.findOneAndUpdate({_id:id},{
        $set : updatedData
      },
      {
        new: true
      });
    })
    .catch((err) =>{
      error.error(`OrgAdmin selfEdit firebase error:${err}`);
      res.status(err.status).send({
        message: err.message
      });
      throw err;
    })
    
    info.info(`selfEdit completed Id:${id} updatedData:${JSON.stringify(updatedData)}`);
    const response  = generateResponse("Edited successfully..",200,"success");
    res.status(200).json(response)
  } catch (err:any) {
    error.error(`selfEdit Error : ${err.message}`);
    const response  = generateResponse("Internal server error",500,"failed");
    res.status(500).json(response)
  }
}

export async function deactivateOrgAdmin (req: Request, res: Response) {
  const id = req.params.id;
  try{
    info.info(`deactivateOrgAdmin initiated userId:${id}`);
    if(!id){
      error.error(`deactivateOrgAdmin error: Id missing`)
      return res.status(400).send({
        success: false,
        message: "User id is missing"
      });
    }
    await disableUser(id)
    .then(async()=>{
      await collection.findOneAndUpdate({_id:id}, {
        $set: {
          isActive: false,
          updatedAt: new Date()
        }
      },
      {
        new: true
      });
      info.info(`deactivateOrgAdmin id:${id} completed`);
      res.status(200).send({
        success: true,
        message: "Hotel Admin Disabled successfully"
      })
    })
    .catch((err: any)=>{
      error.error(`deactivateOrgAdmin id:${id} firebase error:${JSON.stringify(err)}`);
      res.status(err.status).send({message: err.message});
    })
  }
  catch(err: any){
    error.error(`deactivateOrgAdmin id:${id} error:${err.message}`);
    res.status(400).send({
      success: false,
      message: err.message
    });
  }
}

export async function activateOrgAdmin (req: Request, res: Response) {
  const id = req.params.id;
  try{
    info.info(`activateOrgAdmin initiated userId:${id}`);
  
    await enableUser(id)
    .then(async()=>{
      await collection.findOneAndUpdate({_id:id}, {
        $set: {
          isActive: true,
          updatedAt: new Date()
        }
      },
      {
        new: true
      });
      info.info(`activateOrgAdmin id:${id} completed`);
      res.status(200).send({
        success: true,
        message: "Hotel Admin enabled successfully"
      })
    })
    .catch((err: any)=>{
      error.error(`activateOrgAdmin id:${id} firebase error:${JSON.stringify(err)}`);
      res.status(err.status).send({message: err.message});
    })
  }
  catch(err: any){
    error.error(`activateOrgAdmin id:${id} error:${err.message}`);
    res.status(400).send({
      success: false,
      message: err.message
    });
  }
}


export const adminList = async (req: Request, res: Response) => {
  info.info(`adminList initiated`);
  info.info(`adminList queryParams: ${JSON.stringify(req.query)}`);
  
  const {orgId,page,pageSize, query}= req.query
  const currentPage = parseInt(page as string, 10) || 1;
  const page_Size = parseInt(pageSize as string, 10) || 10;
  const filter: {
    orgId: any ;
    isDeleted: boolean;
    isActive: boolean;
    name?: RegExp; 
  } = {
    orgId,
    isDeleted: false,
    isActive: true
  };

  if (query) {
    filter.name = new RegExp(query as string, 'i');
  }

  try {
    const pipeline = [
      { $match: filter }, 
      {
        $facet: {
          totalCount: [ 
            { $count: "count" }
          ],
          data: [ 
            { $skip: (currentPage - 1) * page_Size },
            { $limit: page_Size },
            { $project: { name: 1, mobileNumber: 1 } } 
          ]
        }
      },
      {
        $project: {
          count: { $arrayElemAt: ["$totalCount.count", 0] }, 
          data: 1 
        }
      }
    ];
    info.info(`adminList pipeLine: ${JSON.stringify(pipeline)}`)
    const result = await collection.aggregate(pipeline).toArray();

    if (result.length > 0) {
      const responseData = {
        count: result[0].count, 
        list: result[0].data
      };

      if (responseData.list.length === 0) {
        res.status(404).json(generateResponse(`No data found.`, 404, "not found"));
        error.error(`adminList error: No data found`);
      } else {
      info.info(`adminList data fetching completed`);
        res.status(200).json(generateResponse(`Data fetched.`, 200, "success", [responseData]));
      }
    } else {
      res.status(404).json(generateResponse(`No data found.`, 404, "not found"));
    }
  } catch (err: any) {
    error.error(`adminList error: ${err.message}`)
    res.status(500).json(generateResponse(`Internal server error.`, 500, "failed"));
  }
};



export async function orgAdminDetails(req: Request, res: Response) {

  info.info(`orgAdminDetails initiated`);
  info.info(`orgAdminDetails reqParams:${JSON.stringify(req.params)}`);

  try {
    if (collection) {
      const { orgId } = req.params;
      const page = parseInt(req.query.page as string) || 1; 
      const limit = parseInt(req.query.limit as string) || 10; 
      const query = req.query.query || '';
      const searchFilter = {
        orgId,
        isDeleted: false,
        isActive: true,
        $or: [
          { name: { $regex: query, $options: 'i' } },
          { email: { $regex: query, $options: 'i' } },
          { mobileNumber: { $regex: query, $options: 'i' } }
        ]
      };

      const projection = {
        _id: 1,
        name: 1,
        email: 1,
        mobileNumber: 1,
        orgId: 1,
      };

      const skip = (page - 1) * limit;

      const users = await collection.find(searchFilter, { projection })
      .skip(skip)
      .limit(limit)
      .toArray();

      const response = generateResponse('userDocument found', 200, 'success', users);
      res.status(200).json(response);
      info.info(`orgAdminDetails data:${JSON.stringify(users)}`)
    }
  } catch (err: any) {
    error.error(`getUserById errorMessage:${err.message}`);
    res.status(500).json(generateResponse("Internal server error",500,"failed"));
  }
}

