import { NextFunction, Request, Response } from "express";
import { info, error } from "../config/loggerConfig";
import { ApiFeatures } from "../utils/apiFeatures";
import { addUser } from "../utils/userCounts";
import { orgManager } from "../model/orgManagerModel";
import { generateResponse } from "../utils/responseGenerate";
import { createUser, deleteUser, disableUser, enableUser, getUserAccess, updateUser } from "../firebase";
import axios from "axios";
import { convertAccessForHotel } from "./userAccessController";
import { databaseConnection } from "../app/db";
const baseURL = process.env.BASE_URL;
const orgPort = process.env.ORG_PORT;


let collection: any;
export const omInstance = async () => {
  collection = await orgManager()

}


export async function createOrgManager(req: Request, res: Response,) {

  info.info(`createOrgManager initiated`);
  info.info(`createOrgManager reqParams:${JSON.stringify(req.body)}`);

  try {
    const { name, email, mobileNumber, shifts, orgId, divId} = req.body;
    const id = await addUser('divM');
    req.body.uid = id;
    req.body.userType = "divM";
    const userData = {
      _id: id,
      orgId,
      divId,
      name,
      email,
      mobileNumber,
      shifts,
      isActive: true,
      isDeleted: false,
      createdAt: new Date(),
      updatedAt: new Date()

    }
    await createUser(req)
    .then(async()=>{
      info.info("Firebase user created");
      await collection.insertOne(userData);
      info.info(`createOrgManager data ${JSON.stringify(userData)}`);
      const response = generateResponse('userDocument created successfully', 200, 'success')
      res.status(200).json(response);
    })
    .catch((err:any)=>{
      error.error(`firebase user not created error:${err.message}`);
      res.status(err.status).send({message: err.message});
     return;
      });
    
  } catch (err: any) {
    error.error(`createOrgManager errorMessage:${err}`);
    res.status(500).json(generateResponse("Internal server error",500,"failed"));


  }
}


// // Get All Orgnization Manager


export async function getAllOrgManager(req: Request, res: Response) {

  info.info(`getAllOrgManager initiated`);
  info.info(`getAllOrgManager req.query:${JSON.stringify(req.query)}`);

  try {
    if (collection) {
      const { query, page, sort, sortBy, pageSize } = req.query;
      const queryHandler = new ApiFeatures(collection, query, page, sort, sortBy, pageSize);
      const userList = await queryHandler.searchAndPaginate();

      if (userList && userList.list && Array.isArray(userList.list)) {
        const ids  = userList.list.map((user: any) => user.orgId);    
        
        const orgDetailsResponse = await axios.post(`http://${baseURL}:${orgPort}/api/org/details`,{ids})        
        const orgDetailsMap = new Map(orgDetailsResponse.data.map((org: any) => [org._id, org]));
          
        const enrichedUserList = userList.list.map((user, index) => ({
          ...user,
          orgDetails: orgDetailsMap.get(user.orgId)
        }));

        const response = generateResponse('userDocument fetched successfully', 200, 'success', {
          ...userList,
          list: enrichedUserList,
        });

        info.info(`getAllOrgManager ${JSON.stringify(userList)}`);
        res.status(200).json(response);
      } else {
        const response = generateResponse('invalid request', 404, 'failed', userList);
        res.status(400).json(response);
      }
    }
  } catch (err: any) {
    error.error(`getAllOrgManager errorMessage:${err.message}`);
    res.status(500).json(generateResponse("Internal server error",500,"failed"));

  }
}

// Get One Org Manager

export async function oneOrgManager(req: Request, res: Response) {

  info.info(`oneOrgManager initiated`);
  info.info(`oneOrgManager reqParams:${JSON.stringify(req.params)}`);

  try {
    const { id } = req.params;
    if (collection) {

      const projection = {
        _id:1,
        name: 1,
        email: 1,
        mobileNumber: 1,
        shifts: 1,
        divId:1,
        orgId:1 ,
        isActive:1,
      };

      const user = await collection.findOne({ _id: id }, { projection });
      let userData: any;

      if (user) {
        const axiosOrgResponse = await axios.get(`http://${baseURL}:${orgPort}/api/org/orgDetails/${user.orgId}`);
        if(user.isActive == true)
        {
        const divData = await axios.get(`http://${baseURL}:${orgPort}/api/div/getDivShift/${user.divId}`);
        let filteredShifts;
        if(user.shifts){
          filteredShifts = divData.data.shift.filter((divShift:any) => user.shifts.includes(divShift.shiftId));
        }
        else{
          filteredShifts = null;
        }
        userData = {
          user,
          orgDetails: axiosOrgResponse.data,
          divDetails: {
            divName: divData.data.divName,
            shifts: filteredShifts,
          },
          };
        }
        else{
        userData = {
          user,
          orgDetails: axiosOrgResponse.data, 
        };
        }

      await getUserAccess(id)
      .then(async (access) =>{
        (userData as any).access  = await convertAccessForHotel(access);
      })
      .catch((err) =>{
        error.error(`oneOrgManager access error:${err}`);
      });

      info.info(`oneOrgManager document found for id : ${id}`);
      const response = generateResponse('User Document Fetched..!', 200, 'success', userData)
      res.status(200).json(response);
      } else {
        const response = generateResponse('user not found', 404, 'failed')
        res.status(404).json(response);
      }

    }
  } catch (err: any) {
    error.error(`getUserById errorMessage:${err.message}`);
    res.status(500).json(generateResponse("Internal server error",500,"failed"));
  }
}


// //update Org Manager details

export async function editOrgManager(req: Request, res: Response, next: NextFunction) {
  info.info(`editOrgManager initiated`);
  info.info(`editOrgManager reqParams:${JSON.stringify(req.params)}`);

  const { id } = req.params;
  const data = req.body
  const name = data.name;
  const mobileNumber = data.mobileNumber;
  const shifts = data.shifts;
  const divId = data.divId;
  data.userType = "divM";

  const updatedData = {
    name,
    mobileNumber,
    shifts,
    divId,
    updatedAt: new Date()
  };
  try {
    await updateUser(id,data)
      .then(async()=>{
        await collection.findOneAndUpdate({ _id: id }, {
          $set: updatedData
        },
          {
            new: true
          })
      info.info(`editOrgManager work completed for id : ${id} data:${JSON.stringify(updatedData)}`);
        const response = generateResponse('user updated successfully', 200, 'success')
        res.status(200).json(response);
      })
      .catch((err)=>{
        res.status(500).send({
          message: "Something went wrong",
          error: err
        });
        });
    
  } catch (err: any) {
    error.error(`editOrgAdmin errorMessage:${err.message}`);   
    res.status(500).json(generateResponse("Internal server error",500,"failed"));


  }
}

//delete Org Manager

export async function removeOrgManager(req: Request, res: Response) {
  info.info(`removeOrgManager  initiated`);
  info.info(`removeOrgManager reqParams:${JSON.stringify(req.params)}`);
  const { id } = req.params;
  try {
    await deleteUser(id)
    .then(async()=>{
      info.info(`firebase user deleted`);
      await collection.findOneAndUpdate({ _id: id }, {
        $set: {
          isDeleted: true,
          updatedAt: new Date()
        }
      }, { new: true })
    info.info(`removeOrgManager deleted id:${id} `);
      const response = generateResponse('user deleted successfully', 200, 'success')
      res.status(200).json(response);
    })
    .catch((err)=>{
      error.error(`deletePa firebase error:${err}`)
      res.status(500).send({
        success: false,
        message: "Something went wrong"
      });
    })
    
  } catch (err: any) {
    error.error(`removeOrgManager error : ${err.message}`)
    res.status(500).json(generateResponse("Internal server error",500,"failed"));


  }
}

export async function deactivateOrgManager (req: Request, res: Response) {
  const id = req.params.id;
  try{
    info.info(`deactivateOrgManager initiated userId:${id}`);
    
    await disableUser(id)
    .then(async()=>{
      await collection.findOneAndUpdate({_id:id}, {
        $set: {
          isActive: false,
          updatedAt: new Date()
        }
      },
      {
        new: true
      });
      info.info(`deactivateOrgManager id:${id} completed`);
      res.status(200).send({
        success: true,
        message: "Branch Manager Disabled successfully"
      })
    })
    .catch((err: any)=>{
      error.error(`deactivateOrgManager id:${id} firebase error:${JSON.stringify(err)}`);
      res.status(err.status).send({message: err.message});
    })
  }
  catch(err: any){
    error.error(`deactivateOrgManager id:${id} error:${err.message}`);
    res.status(400).send({
      success: false,
      message: err.message
    });
  }
}

export async function activateOrgManager (req: Request, res: Response) {
  const id = req.params.id;
  try{
    info.info(`activateOrgManager initiated userId:${id}`);
  
    await enableUser(id)
    .then(async()=>{
      await collection.findOneAndUpdate({_id:id}, {
        $set: {
          isActive: true,
          updatedAt: new Date()
        }
      },
      {
        new: true
      });
      info.info(`activateOrgManager id:${id} completed`);
      res.status(200).send({
        success: true,
        message: "Branch Manager enabled successfully"
      })
    })
    .catch((err: any)=>{
      error.error(`activateOrgManager id:${id} firebase error:${JSON.stringify(err)}`);
      res.status(err.status).send({message: err.message});
    })
  }
  catch(err: any){
    error.error(`activateOrgManager id:${id} error:${err.message}`);
    res.status(400).send({
      success: false,
      message: err.message
    });
  }
}

export const divUserList = async (req: Request, res: Response, next: NextFunction) => {
  try {
    info.info(`divUserList fetching initiated `);
    info.info(`divUserList req.params  ${JSON.stringify(req.params)}`);

    const divId = req.params.id;
    const searchCriteria = req.query.query as string;
    let page = parseInt(req.query.page as string, 10) || 1;
    const pageSize = parseInt(req.query.pageSize as string, 10) || 10;
    let skip = (page - 1) * pageSize;
    const sortField = req.query.sortField ? req.query.sortField.toString() : 'orgName';
    const sortOrder = req.query.sortOrder === 'desc' ? -1 : 1;
    skip = (page - 1) * pageSize;

    const pipeline =[

      {
        $addFields: {
          'userType': 'manager',
        }
      },
      {
        $match: {
          'divId': divId,
          'isDeleted': false,
          $or: [
            { 'name': { $regex: new RegExp(searchCriteria, 'i') } },
            { 'email': { $regex: new RegExp(searchCriteria, 'i') } },
            { 'mobileNumber': { $regex: new RegExp(searchCriteria, 'i') } },
            { 'userType': { $regex: new RegExp(searchCriteria, 'i') } },
          ]
        }
      },
      {
        $unionWith: {
          coll: 'organisationSupervisor',
          pipeline: [

            {
              $addFields: {
                'userType': 'supervisor',
              }
            },
            {
              $match: {
                'divId': divId, 
                'isDeleted': false,
                $or: [
                  { 'name': { $regex: new RegExp(searchCriteria, 'i') } },
                  { 'email': { $regex: new RegExp(searchCriteria, 'i') } },
                  { 'mobileNumber': { $regex: new RegExp(searchCriteria, 'i') } },
                  { 'userType': { $regex: new RegExp(searchCriteria, 'i') } },
                ]
              }
            },
          ]
        }
      },
      {
        $unionWith: {
          coll: 'orgGodownUser',
          pipeline: [

            {
              $addFields: {
                'userType': 'storeUser',
              }
            },
            {
              $match: {
                'divId': divId,
                'isDeleted': false,
                $or: [
                  { 'name': { $regex: new RegExp(searchCriteria, 'i') } },
                  { 'email': { $regex: new RegExp(searchCriteria, 'i') } },
                  { 'mobileNumber': { $regex: new RegExp(searchCriteria, 'i') } },
                  { 'userType': { $regex: new RegExp(searchCriteria, 'i') } },

                ]
              }
            },
          ]
        }
      },
      {
        $unionWith: {
          coll: 'transactionPointUser',
          pipeline: [

            {
              $addFields: {
                'userType': 'pickupCounterUser',
              }
            },
            {
              $match: {
                'divId': divId,
                'isDeleted': false,
                $or: [
                  { 'name': { $regex: new RegExp(searchCriteria, 'i') } },
                  { 'email': { $regex: new RegExp(searchCriteria, 'i') } },
                  { 'mobileNumber': { $regex: new RegExp(searchCriteria, 'i') } },
                  { 'userType': { $regex: new RegExp(searchCriteria, 'i') } },
                ]
              }
            },
          ]
        }
      },
      {
        $sort: {  [sortField]: sortOrder, }
      },
      {
        $facet: {
          result: [
            { $skip: skip },
            { $limit: pageSize },
            {
              $project: {
                _id: 1,
                orgId: 1,
                name: 1,
                email: 1,
                mobileNumber: 1,
                shifts: 1,
                userType: 1,
                isActive:1,
              }
            }
          ],
          totalCount: [
            {
              $count: 'value'
            }
          ]
        }
      },
      {
        $project: {
          page: 1,
          pageSize: 1,
          totalCount: { $arrayElemAt: ['$totalCount.value', 0] },
          data: '$result',
        }
      }
    ]
    info.info(`divUserList pipeLine: ${JSON.stringify(pipeline)}`)
    const result = await collection.aggregate(pipeline).toArray();
    const shiftResponse = await axios.get(`http://${baseURL}:${orgPort}/api/div/getDivShift/${divId}`);
    const shifts = shiftResponse.data.shift;
    const resultData = result[0].data || [];
    const updatedResult = resultData.map((user: any) => {
      const userShifts = user.shifts.map((shiftId: any) => {
        const correspondingShift = shifts.find((shift: any) => shift.shiftId === shiftId);
        return {
          shiftId,
          shiftNo: correspondingShift ? correspondingShift.shiftNo : null,
        };
      });

      return {
        ...user,
        shifts: userShifts,
      };
    });

    const data = {
      page,
      pageSize,
      totalCount: result[0]?.totalCount || 0,
      list: updatedResult || [],
    };
    const response = generateResponse('userDocument fetched', 200, 'success', data)
    res.status(200).json(response);
    info.info(`divUserList completed`)
  } catch (err: any) {
    error.error(`divUserList error: ${err.message}`)
    res.status(500).json(generateResponse("Internal server error",500,"failed"));
  }
};

export const deleteShiftIdFromCollections = async (req: Request, res: Response) => {
  info.info(`deleteShiftIdFromCollections initiated`)
  info.info(`deleteShiftIdFromCollections req.body ${JSON.stringify(req.body)}`)
  try {
    const shiftId = req.body.shiftId;
    const collections = ['organisationSupervisor', 'transactionPointUser', 'orgGodownUser', 'organisationManager'];

    const db = await databaseConnection();
    const filter = { 'shifts': shiftId };

    await Promise.all(collections.map(async (coll) => {
      await db.collection(coll).updateMany(filter, { $pull: { 'shifts': shiftId } });

    }));

    res.status(200).json('Operation completed successfully');
    info.info(`deleteShiftIdFromCollections completed`)

  } catch (err:any) {
    error.error(`deleteShiftIdsFromCollections error : ${err.message}`)
    res.status(500).json(generateResponse("Internal server error",500,"failed"));
  }
};

export const deleteAllOrgUsers = async (req: Request, res: Response) => {
  info.info(`deleteAllOrgUsers initiated`);
  info.info(`deleteAllOrgUsers req.params: ${JSON.stringify(req.params)}`);
  try {
      const orgId = req.params.orgId;
      const collections = ['organisationOwner', 'organisationAdmin', 'organisationSupervisor', 'transactionPointUser', 'orgGodownUser', 'organisationManager'];

      const db = await databaseConnection();

      const deletedIds: Record<string, any[]> = {};

      await Promise.all(collections.map(async (coll) => {
          await db.collection(coll).updateMany({ orgId }, { $set: { 'isDeleted': true, updatedAt: new Date() } });
          
           const deletedDocuments = await db.collection(coll).find({ orgId, 'isDeleted': true }).toArray();
          deletedIds[coll] = deletedDocuments.map((doc :any) => doc._id);
      for(const id of deletedIds[coll]){
        await deleteUser(id)
        .then(()=> info.info(`Given id's are deleted in firebase`))
        .catch((err:any)=> error.error(`firebase delete id's error ${err.message}`) )
      }
    }));
      res.status(200).json({ message: 'Operation completed successfully', deletedIds });
      info.info(`deleteAllOrgUsers completed`);

  } catch (err: any) {
      error.error(`deleteAllOrgUsers error : ${err.message}`);
      res.status(500).json(generateResponse("Internal server error", 500, "failed"));
  }
};

export const inactiveAllDivUsers = async (req: Request, res: Response) => {
  info.info(`inactiveAllDivUsers req.params: ${JSON.stringify(req.params)}`)
  const divId = req.params.id;
  info.info(`inactiveAllDivUsers initiated divId:${divId}`);
  try {
      const collections = ['organisationSupervisor', 'transactionPointUser', 'orgGodownUser', 'organisationManager'];

      const db = await databaseConnection();

      await Promise.all(collections.map(async (coll) => {
          await db.collection(coll).updateMany({ divId }, { $set: { 'isActive': false, 'updatedAt': new Date() } });
    }));
      info.info(`inactiveAllDivUsers divId:${divId} completed`);
      res.status(200).json({ message: 'Operation completed successfully' });

  } catch (err: any) {
      error.error(`inactiveAllDivUsers divId:${divId} error:${err.message}`);
      res.status(500).json(generateResponse(err.message, 500, "failed"));
  }
};


export const managerList = async (req: Request, res: Response) => {
  info.info(`managerList initiated`);
  info.info(`managerList queryParams: ${JSON.stringify(req.query)}`);
  
  const {orgId,page,pageSize, query}= req.query
  if(!orgId || orgId === ""){
    error.error(`managerList error: orgId missing`);
    return res.status(400).json(generateResponse(`orgId is missing`,400,`failed`))
  }
  const currentPage = parseInt(page as string, 10) || 1;
  const page_Size = parseInt(pageSize as string, 10) || 10;
  const filter: {
    orgId: any ;
    isDeleted: boolean;
    isActive: boolean;
    name?: RegExp; 
  } = {
    orgId,
    isDeleted: false,
    isActive: true
  };

  if (query) {
    filter.name = new RegExp(query as string, 'i');
  }
  try {
    const pipeline = [
      { $match: filter }, 
      {
        $facet: {
          totalCount: [ 
            { $count: "count" }
          ],
          data: [ 
            { $skip: (currentPage - 1) * page_Size },
            { $limit: page_Size },
            { $project: { name: 1, mobileNumber: 1 } } 
          ]
        }
      },
      {
        $project: {
          count: { $arrayElemAt: ["$totalCount.count", 0] }, 
          data: 1 
        }
      }
    ];
    info.info(`managerList pipeLine :${JSON.stringify(pipeline)}`)
    const result = await collection.aggregate(pipeline).toArray();

    if (result.length > 0) {
      const responseData = {
        count: result[0].count, 
        list: result[0].data
      };

      if (responseData.list.length === 0) {
        res.status(404).json(generateResponse(`No data found.`, 404, "not found"));
      } else {
      info.info(`managerList data fetching completed`);
        res.status(200).json(generateResponse(`Data fetched.`, 200, "success", [responseData]));
      }
    } else {
      res.status(404).json(generateResponse(`No data found.`, 404, "not found"));
    }
  } catch (err: any) {
    error.error(`managerList error: ${err.message}`)
    res.status(500).json(generateResponse(`Internal server error.`, 500, "failed"));
  }
};



export async function orgManagerDetails(req: Request, res: Response) {

  info.info(`orgManagerDetails initiated`);
  info.info(`orgManagerDetails reqParams:${JSON.stringify(req.params)}`);

  try {
    if (collection) {
      const { orgId } = req.params;
      const page = parseInt(req.query.page as string) || 1; 
      const limit = parseInt(req.query.limit as string) || 10; 
      const query = req.query.query || '';
      const searchFilter = {
        orgId,
        isDeleted: false,
        isActive: true,
        $or: [
          { name: { $regex: query, $options: 'i' } },
          { email: { $regex: query, $options: 'i' } },
          { mobileNumber: { $regex: query, $options: 'i' } }
        ]
      };

      const projection = {
        _id: 1,
        name: 1,
        email: 1,
        mobileNumber: 1,
        orgId: 1,
      };

      const skip = (page - 1) * limit;

      const users = await collection.find(searchFilter, { projection })
      .skip(skip)
      .limit(limit)
      .toArray();

      const response = generateResponse('userDocument found', 200, 'success',  users);
      res.status(200).json(response);
      info.info(`orgManagerDetails data:${JSON.stringify(users)}`)
    }
  } catch (err: any) {
    error.error(`getUserById errorMessage:${err.message}`);
    res.status(500).json(generateResponse("Internal server error",500,"failed"));
  }
}