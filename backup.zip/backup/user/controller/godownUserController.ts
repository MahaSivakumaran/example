import { NextFunction, Request, Response } from "express";
import { info, error } from "../config/loggerConfig";
import { ApiFeatures } from "../utils/apiFeatures";
import { addUser } from "../utils/userCounts";
import { orgGodownUser } from "../model/orgGodownUserModel";
import { generateResponse } from "../utils/responseGenerate";
import { createUser, deleteUser, disableUser, enableUser, getUserAccess, updateUser } from "../firebase";
import axios from "axios";
import { convertAccessForHotel } from "./userAccessController";
import { pushNotification } from "../lib/pushNotification";
const baseURL = process.env.BASE_URL;
const orgPort = process.env.ORG_PORT;

let collection: any;
export const ogInstance = async () => {
  collection = await orgGodownUser();
}

export async function createGodownUser(req: Request, res: Response,) {
  info.info(`createGodownUser initiated`);
  info.info(`createGodownUser reqBody:${JSON.stringify(req.body)}`);

  try {
    const { name, email, mobileNumber, shifts, orgId, divId } = req.body
    let id = await addUser('gUser');
    req.body.uid = id;
    req.body.userType = "gUser";

    await createUser(req)
      .then(async () => {
        info.info("Firebase user created");
        const insertData = {
          _id: id,
          orgId,
          divId,
          name,
          email,
          mobileNumber,
          shifts,
          isActive: true,
          isDeleted: false,
          createdAt: new Date(),
          updatedAt: new Date()
        }
        await collection.insertOne(insertData);
        const response = generateResponse('userDocument created successfully', 200, 'success')
        info.info(` createGodownUser insertData:${JSON.stringify(insertData)}`);
        res.status(200).json(response);
      })
      .catch((err) => {
        error.error(`firebase user not created error:${err.message}`);
        res.status(err.status).send({ message: err.message });
        return;
      });

  } catch (err: any) {
    error.error(`createGodownUser errorMessage : ${err.message}`)
    res.status(500).json(generateResponse("Internal server error", 500, "failed"));

  }
};

export async function getAllGodownUsers(req: Request, res: Response) {
  info.info(`getAllGodownUsers initiated`);
  info.info(`getAllGodownUsers reqParams:${JSON.stringify(req.query)}`);

  try {
    if (collection) {
      const { query, page, sort, sortBy, pageSize } = req.query;
      const queryHandler = new ApiFeatures(collection, query, page, sort, sortBy, pageSize);
      const userList = await queryHandler.searchAndPaginate();          

      if (userList && userList.list && Array.isArray(userList.list)) {
        const ids  = userList.list.map((user: any) => user.orgId);    
        
        const orgDetailsResponse = await axios.post(`http://${baseURL}:${orgPort}/api/org/details`,{ids})        
        const orgDetailsMap = new Map(orgDetailsResponse.data.map((org: any) => [org._id, org]));
          const enrichedUserList = userList.list.map((user: any) => ({
          ...user,
          orgDetails: orgDetailsMap.get(user.orgId)
        }));

        const response = generateResponse('userDocument fetched successfully', 200, 'success', {
          ...userList,
          list: enrichedUserList,
        });
        info.info(`getAllGodownUsers completed`);
        res.status(200).json(response);
      } else {
        res.status(500).json({ success: false, error: 'Internal Server Error' });
      }
    }
  } catch (err: any) {
    error.error(`getAllGodownUsers errorMessage:${err.message}`);
    res.status(500).json(generateResponse('Internal server error', 500, 'failed'));
  }
}

export async function oneGowDownUser(req: Request, res: Response) {

  info.info(`oneGowDownUser initiated`);
  info.info(`oneGowDownUser reqParams:${JSON.stringify(req.params)}`);

  try {
    if (collection) {
      const { id } = req.params;
      const projection = {
        _id: 1,
        name: 1,
        mobileNumber: 1,
        shifts: 1,
        orgId: 1,
        divId: 1,
        isActive: 1
      };

      const user = await collection.findOne({ _id: id }, { projection });
      let userData: any;

      if (user) {
        const axiosOrgResponse = await axios.get(`http://${baseURL}:${orgPort}/api/org/orgDetails/${user.orgId}`);
        if(user.isActive == true)
        {
        const divData = await axios.get(`http://${baseURL}:${orgPort}/api/div/getDivShift/${user.divId}`);
        let filteredShifts;
        if (user.shifts) {
          filteredShifts = divData.data.shift.filter((divShift: any) => user.shifts.includes(divShift.shiftId));
        }
        else {
          filteredShifts = null;
        }

        userData = {
          user,
          orgDetails: axiosOrgResponse.data,
          divDetails: {
            divId: divData.data._id,
            divName: divData.data.divName,
            shifts: filteredShifts,
          },
        };
        }
        else{
          userData = {
            user,
            orgDetails: axiosOrgResponse.data,
          };
        }

        await getUserAccess(id)
          .then(async (access) => {
            (userData as any).access = await convertAccessForHotel(access);
          })
          .catch((err) => {
            error.error(`getUserById access error:${err}`);
          });

        const response = generateResponse('userDocument found', 200, 'success', userData)
        res.status(200).json(response);
        info.info(`oneGowDownUser completed for id: ${id}`)
      } else {
        const response = generateResponse('user not found', 404, 'failed')
        res.status(404).json(response);
      }

    }
  } catch (err: any) {
    error.error(`getUserById errorMessage:${err.message}`);
    res.status(500).json(generateResponse("Internal server error", 500, "failed"));
  }
}

export async function editGodownUser(req: Request, res: Response) {

  info.info(`editGodownUser initiated`);
  info.info(`editGodownUser req.params:${JSON.stringify(req.params)}`);
  info.info(`editGodownUser req.body:${JSON.stringify(req.body)}`);

  const { id } = req.params;
  const data = req.body
  const name = data.name;
  const shifts = data.shifts;
  const mobileNumber = data.mobileNumber;
  const divId = data.divId;
  data.userType = "gUser";
  const updatedData = {
    name,
    mobileNumber,
    divId,
    shifts,
    updatedAt: new Date()
  };
  try {
    await updateUser(id, data)
      .then(async () => {
        await collection.findOneAndUpdate({ _id: id }, {
          $set: updatedData
        },
          {
            new: true
          })
        info.info(`editGodownUser edited for id : ${id}`);
        const response = generateResponse('userDocument updated successfully', 200, 'success')
        res.status(200).json(response);
        info.info(`editGodownUser updated for id : ${id} and updatedData ${JSON.stringify(updatedData)}` );
      })
      .catch((err) => {
        res.status(500).send({
          message: "Something went wrong",
          error: err
        });
      });

  } catch (err: any) {
    error.error(`editGodownUser error : ${err.message}`)
    res.status(500).json(generateResponse("Internal server error", 500, "failed"));

  }
}

export async function removeGodownUser(req: Request, res: Response, next: NextFunction) {
  info.info(`removeGodownUser initiated`);
  info.info(`removeGodownUser req.params:${JSON.stringify(req.params)}`);

  const { id } = req.params;
  try {
    await deleteUser(id)
      .then(async () => {
        info.info(`firebase user deleted`);
        await collection.findOneAndUpdate({ _id: id }, {
          $set: {
            isDeleted: true,
            updatedAt: new Date()
          }
        }, { new: true })
        info.info(`GodownUser deleted for id : ${id}`)
        const response = generateResponse('userDocument deleted successfully', 200, 'success')
        res.status(200).json(response);
      })
      .catch((err) => {
        error.error(`deletePa firebase error:${err}`)
        res.status(500).send({
          success: false,
          message: "Something went wrong"
        });
      })


  } catch (err: any) {
    error.error(`removeGodownUser error : ${err.message}`)
    res.status(500).json(generateResponse("Internal server error", 500, "failed"));
  }
}

export async function activateGodownUser(req: Request, res: Response) {
  const id = req.params.id;
  try {
    info.info(`activateGodownUser initiated userId:${id}`);
    await enableUser(id)
      .then(async () => {
        await collection.findOneAndUpdate({ _id: id }, {
          $set: {
            isActive: true,
            updatedAt: new Date()
          }
        });
        info.info(`activateGodownUser id:${id} completed`);
        res.status(200).send({
          success: true,
          message: "Store user enabled successfully"
        })
      })
      .catch((err: any) => {
        error.error(`activateGodownUser id:${id} firebase error:${JSON.stringify(err)}`);
        res.status(err.status).send({ message: err.message });
      })
  }
  catch (err: any) {
    error.error(`activateGodownUser id:${id} error:${err.message}`);
    res.status(400).send({
      success: false,
      message: err.message
    });
  }
}

export async function deactivateGodownUser(req: Request, res: Response) {
  const id = req.params.id;
  try {
    info.info(`deactivateGodownUser initiated userId:${id}`);
    
    await disableUser(id)
      .then(async () => {
        await collection.findOneAndUpdate({ _id: id }, {
          $set: {
            isActive: false,
            updatedAt: new Date()
          }
        },
          {
            new: true
          });
        info.info(`deactivateGodownUser id:${id} completed`);
        res.status(200).send({
          success: true,
          message: "Store user Disabled successfully"
        })
      })
      .catch((err: any) => {
        error.error(`deactivateGodownUser id:${id} firebase error:${JSON.stringify(err)}`);
        res.status(err.status).send({ message: err.message });
      })
  }
  catch (err: any) {
    error.error(`deactivateGodownUser id:${id} error:${err.message}`);
    res.status(400).send({
      success: false,
      message: err.message
    });
  }
}


//get all users count with an [ids ]from all collections 

export const count = async (req: Request, res: Response) => {
  info.info(`count initialized`)
  info.info(`count reqbody: ${JSON.stringify(req.body)}`)

  try {
    const orgIds = req.body.orgIds
    if (!orgIds) {
      error.error(`count error: orgIds missing`)
      return res.status(404).json(generateResponse("Ids are missing", 404, "failed"))
    }
    const counts = [];
    for (const orgId of orgIds) {
      const result = await collection.aggregate([
        {
          $match: { "orgId": orgId, "isDeleted": { $ne: true } }
        },
        {
          $count: "orgGodownUser"
        },
        {
          $unionWith: {
            coll: "organisationAdmin",
            pipeline: [
              { $match: { "orgId": orgId, "isDeleted": { $ne: true } } },
              { $count: "organisationAdminCount" }
            ]
          }
        },
        {
          $unionWith: {
            coll: "organisationManager",
            pipeline: [
              { $match: { "orgId": orgId, "isDeleted": { $ne: true } } },
              { $count: "organisationManagerCount" }
            ]
          }
        },
        {
          $unionWith: {
            coll: "organisationOwner",
            pipeline: [
              { $match: { "orgId": orgId, "isDeleted": { $ne: true } } },
              { $count: "organisationOwnerCount" }
            ]
          }
        },
        {
          $unionWith: {
            coll: "organisationSupervisor",
            pipeline: [
              { $match: { "orgId": orgId, "isDeleted": { $ne: true } } },
              { $count: "organisationSupervisorCount" }
            ]
          }
        },
        {
          $unionWith: {
            coll: "transactionPointUser",
            pipeline: [
              { $match: { "orgId": orgId, "isDeleted": { $ne: true } } },
              { $count: "transactionPointUserCount" }
            ]
          }
        },
        {
          $group: {
            _id: null,
            total: {
              $sum: {
                $sum: [
                  "$orgGodownUser",
                  "$organisationAdminCount",
                  "$organisationManagerCount",
                  "$organisationOwnerCount",
                  "$organisationSupervisorCount",
                  "$transactionPointUserCount"
                ]
              }
            }
          }
        },
        {
          $project: {
            _id: 0,
            totalUsers: "$total"
          }
        }
      ]).toArray();
      const count = result.length > 0 ? result[0] : { totalUsers: 0 };
      counts.push({ orgId, ...count });
    }
    res.status(200).json(counts)
    info.info(`userCount ${JSON.stringify(count)}`)

  } catch (err: any) {
    error.error(`userCount fetched error : ${err.message} `)
    res.status(500).json(generateResponse("Internal server error", 500, "failed"));
  }
};

export const divCount = async (req: Request, res: Response) => {
  info.info(`divCount initiated `)
  info.info(`divCount req.body ${JSON.stringify(req.body)} `)

  try {

    const divIds = req.body.divIds
    if (!divIds) {
      error.error(`divCount ids are missing`)
      return res.status(404).json(generateResponse("Ids are missing", 404, "failed"))
    }

    const counts = [];
    for (const divId of divIds) {
      const result = await collection.aggregate([
        {
          $match: { "divId": divId, "isDeleted": { $ne: true } }
        },
        {
          $count: "orgGodownUser"
        },
        {
          $unionWith: {
            coll: "organisationManager",
            pipeline: [
              { $match: { "divId": divId, "isDeleted": { $ne: true } } },
              { $count: "organisationManagerCount" }
            ]
          }
        },
        {
          $unionWith: {
            coll: "organisationSupervisor",
            pipeline: [
              { $match: { "divId": divId, "isDeleted": { $ne: true } } },
              { $count: "organisationSupervisorCount" }
            ]
          }
        },
        {
          $unionWith: {
            coll: "transactionPointUser",
            pipeline: [
              { $match: { "divId": divId } },
              { $count: "transactionPointUserCount" }
            ]
          }
        },
        {
          $group: {
            _id: null,
            total: {
              $sum: {
                $sum: [
                  "$orgGodownUser",
                  "$organisationManagerCount",
                  "$organisationSupervisorCount",
                  "$transactionPointUserCount"
                ]
              }
            }
          }
        },
        {
          $project: {
            _id: 0,
            totalUsers: "$total"
          }
        }
      ]).toArray();

      const count = result.length > 0 ? result[0] : { totalUsers: 0 };
      counts.push({ divId, ...count });
    }
    info.info(`divcount fetched completed ${JSON.stringify(count)}`)
    res.status(200).json(counts)
  } catch (err: any) {
    info.error(`divCount fetch error: ${err.message}`)
    res.status(500).json(generateResponse(err.message, 500, "failed"));
  }
};

export async function updateFcmToken (req: Request, res: Response) {
  info.info(`updateFcmToken req.body ${JSON.stringify(req.body)}`)
  const {id} = req.params;
  try{
    info.info(`updateFcmToken id:${id} initiated`);
    const userData = await collection.find({_id: id, isDeleted: false});
    if(userData.length < 1)
    {
      error.error(`updateFcmToken id:${id} user not found`);
      res.status(404).json(generateResponse("User not found", 404, "Failed"));
    }
    const {fcmToken} = req.body;
    await collection.findOneAndUpdate({_id: id},
      {
        $set: {fcmToken}
      },
      {
        new: true
      });
      info.info(`updateFcmToken updated id:${id} fcmToken:${fcmToken}`);
      res.status(200).json(generateResponse("FCM updated successfully", 200, "Success"));
  }
  catch(err: any) {
    error.error(`updateFcmToken error:${err.message}`);
    res.status(500).json(generateResponse("Internal server error", 500, "Failed"));
  }
}

export async function minItemAlert(req: Request, res: Response) {
  const { itemData, isAdminSend } = req.body;
  const { orgId } = req.query;
  try {
    info.info(
      `minItemAlert orgId:${orgId} itemIds:${JSON.stringify(
        itemData
      )} initiated`
    );
    const ownerData = await collection.findOne(
      { orgId, isDeleted: false },
      { projection: { fcmToken: 1 } }
    );
    const fcmToken = ownerData.fcmToken;
    if (itemData.length > 0) {
      var notification = {};
      if (isAdminSend) {
        notification = {
          title: "Alert From Admin",
          body: "An item had reached its minimum limit.",
        };
      } else {
        notification = {
          title: "Minimum Limit Alert",
          body: "An item had reached its minimum limit.",
        };
      }
      var FcmTokenAndSubDetails: {
        notification: {};
        token: string;
        data: any;
      }[] = [];
      itemData.forEach(
        (item: any) => {  
          const min = item.minQty;
          item.minQty = `${min}`;
          const cur = item.currentQty;
          item.currentQty = `${cur}`;
          FcmTokenAndSubDetails.push({
            notification,
            token: fcmToken,
            data: item,
          });
        }
      );
      let result = await pushNotification(FcmTokenAndSubDetails);
      if (result) {
        console.log("message sent to success");
      } else {
        console.log("No message sent to user");
      }
      res.status(200).json(generateResponse("Success", 200, "success"));
    } else {
      error.error(`minItemAlert itemData is empty`);
      return res
        .status(500)
        .json(
          generateResponse("minItemAlert itemData is empty", 500, "Failed")
        );
    }
  } catch (err: any) {
    error.error(`minItemAlert orgId:${orgId} error:${err.message}`);
    res
      .status(500)
      .json(generateResponse("Internal server error", 500, "Failed"));
  }
}

export const godownUserList = async (req: Request, res: Response) => {
  info.info(`godownUserList initiated`);
  info.info(`godownUserList queryParams: ${JSON.stringify(req.query)}`);
  
  const {orgId,page,pageSize, query}= req.query

  if(!orgId){
    error.error(`godownUserList error: orgId missing`);
    return res.status(400).json(generateResponse(`orgId missing`,400,`failed`))
  }
  const currentPage = parseInt(page as string, 10) || 1;
  const page_Size = parseInt(pageSize as string, 10) || 10;
  const filter: {
    orgId: any ;
    isDeleted: boolean;
    isActive: boolean;
    name?: RegExp; 
  } = {
    orgId,
    isDeleted: false,
    isActive: true
  };

  if (query) {
    filter.name = new RegExp(query as string, 'i');
  }
  try {
    const pipeline = [
      { $match: filter }, 
      {
        $facet: {
          totalCount: [ 
            { $count: "count" }
          ],
          data: [ 
            { $skip: (currentPage - 1) * page_Size },
            { $limit: page_Size },
            { $project: { name: 1, mobileNumber: 1 } } 
          ]
        }
      },
      {
        $project: {
          count: { $arrayElemAt: ["$totalCount.count", 0] }, 
          data: 1 
        }
      }
    ];
    info.info(`godownUserList pipeLine: ${JSON.stringify(pipeline)}`)
    const result = await collection.aggregate(pipeline).toArray();

    if (result.length > 0) {
      const responseData = {
        count: result[0].count, 
        list: result[0].data
      };

      if (responseData.list.length === 0) {
        res.status(404).json(generateResponse(`No data found.`, 404, "not found"));
      } else {
      info.info(`godownUserList data fetching completed`);
        res.status(200).json(generateResponse(`Data fetched.`, 200, "success", [responseData]));
      }
    } else {
      res.status(404).json(generateResponse(`No data found.`, 404, "not found"));
    }
  } catch (err: any) {
    error.error(`godownUserList error: ${err.message}`)
    res.status(500).json(generateResponse(`Internal server error.`, 500, "failed"));
  }
};


export async function gUserDetails(req: Request, res: Response) {

  info.info(`gUserDetails initiated`);
  info.info(`gUserDetails reqParams:${JSON.stringify(req.params)}`);

  try {
    if (collection) {
      const { orgId } = req.params;
      const page = parseInt(req.query.page as string) || 1; 
      const limit = parseInt(req.query.limit as string) || 10; 
      const query = req.query.query || '';
      const searchFilter = {
        orgId,
        isDeleted: false,
        isActive: true,
        $or: [
          { name: { $regex: query, $options: 'i' } },
          { email: { $regex: query, $options: 'i' } },
          { mobileNumber: { $regex: query, $options: 'i' } }
        ]
      };

      const projection = {
        _id: 1,
        name: 1,
        email: 1,
        mobileNumber: 1,
        orgId: 1,
      };

      const skip = (page - 1) * limit;

      const users = await collection.find(searchFilter, { projection })
      .skip(skip)
      .limit(limit)
      .toArray();
      const response = generateResponse('userDocument found', 200, 'success', users);
      res.status(200).json(response);
      info.info(`gUserDetails data:${JSON.stringify(users)}`)
    }
  } catch (err: any) {
    error.error(`getUserById errorMessage:${err.message}`);
    res.status(500).json(generateResponse("Internal server error",500,"failed"));
  }
}