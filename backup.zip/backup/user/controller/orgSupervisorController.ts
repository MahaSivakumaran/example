import { Request, Response } from "express";
import { info, error } from "../config/loggerConfig";
import { ApiFeatures } from "../utils/apiFeatures";
import { orgSupervisor } from "../model/orgSupervisorModel";
import { addUser } from "../utils/userCounts";
import { generateResponse } from "../utils/responseGenerate";
import { createUser, deleteUser, disableUser, enableUser, getUserAccess, updateUser } from "../firebase";
import axios from "axios";
import { convertAccessForHotel } from "./userAccessController";
const baseURL = process.env.BASE_URL;
const orgPort = process.env.ORG_PORT;


let collection: any;
export const osInstance = async () => {
  collection = await orgSupervisor();
}

export async function createOrgSupervisor(req: Request, res: Response,) {

  info.info(`createOrgSupervisor initiated`);
  info.info(`createOrgSupervisor req.body:${JSON.stringify(req.body)}`);

  try {
    const { name, email, mobileNumber, shifts, orgId, divId } = req.body;
    const id = await addUser('divS');
    req.body.uid = id;
    req.body.userType = "divS";
    const userData = {
      _id: id,
      orgId,
      divId,
      name,
      email,
      mobileNumber,
      shifts,
      isActive: true,
      isDeleted: false,
      createdAt: new Date(),
      updatedAt: new Date()

    }
    await createUser(req)
    .then(async()=>{
      info.info("Firebase user created");
      await collection.insertOne(userData);
      info.info(`createOrgSupervisor insertedData :${JSON.stringify(userData)}`);
      const response = generateResponse('userDocument created successfully', 200, 'success')
      res.status(200).json(response);
    })
    .catch((err)=>{
      error.error(`firebase user not created error:${err}`);
      res.status(err.status).send({message: err.message});
     return;
      });
    
  } catch (err: any) {
    error.error(`createOrgSupervisor errorMessage:${err}`);
    res.status(500).json(generateResponse("Internal server error",500,"failed"));

}
}

export async function getAllOrgSupervisor(req: Request, res: Response) {

  info.info(`getAllOrgSupervisor initiated`);
  info.info(`getAllOrgSupervisor reqParams:${JSON.stringify(req.query)}`);

  try {
    if (collection) {
      const { query, page, sort, sortBy, pageSize } = req.query;
      const queryHandler = new ApiFeatures(collection, query, page, sort, sortBy, pageSize);
      const userList = await queryHandler.searchAndPaginate();

      if (userList && userList.list && Array.isArray(userList.list)) {
        const ids  = userList.list.map((user: any) => user.orgId);    
        
        const orgDetailsResponse = await axios.post(`http://${baseURL}:${orgPort}/api/org/details`,{ids})        
        const orgDetailsMap = new Map(orgDetailsResponse.data.map((org: any) => [org._id, org]));
        const enrichedUserList = userList.list.map((user) => ({
          ...user,
          orgDetails: orgDetailsMap.get(user.orgId)
        }));
        if (userList) {
          info.info(`getAllOrgSupervisor data fetched`);
          const response = generateResponse('userDocument fetched successfully', 200, 'success', {
            ...userList,
            list: enrichedUserList,
          });
          res.status(200).json(response);
        } else {
          const response = generateResponse('invalid request', 404, 'error', userList);
          res.status(400).json(response);
        }
      }
    }
  } catch (err: any) {
    error.error(`getAllOrgSupervisor errorMessage:${err.message}`);
    res.status(500).json(generateResponse("Internal server error",500,"failed"));

  }
}

export async function oneOrgSupervisor(req: Request, res: Response) {

  info.info(`oneOrgSupervisor initiated`);
  info.info(`oneOrgSupervisor reqParams:${JSON.stringify(req.params)}`);

  try {
    if (collection) {
    const { id } = req.params;

      const projection = {
        _id: 1,
        name: 1,
        email: 1,
        mobileNumber: 1,
        shifts: 1,
        orgId:1,
        divId: 1,
        isActive:1,
      };

      const user = await collection.findOne({ _id: id }, { projection });
      let userData: any;
      if (user) {
        const axiosOrgResponse = await axios.get(`http://${baseURL}:${orgPort}/api/org/orgDetails/${user.orgId}`);
        if(user.isActive == false)
        {
        const divData = await axios.get(`http://${baseURL}:${orgPort}/api/div/getDivShift/${user.divId}`);
        let filteredShifts;
        if(user.shifts){
          filteredShifts = divData.data.shift.filter((divShift:any) => user.shifts.includes(divShift.shiftId));
        }
        else{
          filteredShifts = null;
        }
        userData = {
          user,
          orgDetails: axiosOrgResponse.data,
          divDetails: {
            divName: divData.data.divName,
            shifts: filteredShifts,
          },
      };
    }
    else{
      userData = {
        user,
        orgDetails: axiosOrgResponse.data
    };
    }

      await getUserAccess(id)
      .then(async (access) =>{
        (userData as any).access  = await convertAccessForHotel(access);
      })
      .catch((err) =>{
        error.error(`getUserById access error:${err}`);
      });
     
        info.info(`getUserById document found successfully`);
        const response = generateResponse('userDocument found', 200, 'success', userData)
        res.status(200).json(response);
      } else {
        const response = generateResponse('user not found', 404, 'error')
        res.status(404).json(response);
        error.error(`oneOrgSupervisor error: user not found`)
      }

    }
  } catch (err: any) {
    error.error(`getUserById errorMessage:${err.message}`);
    res.status(500).json(generateResponse("Internal server error",500,"failed"));

  }
}


export async function editOrgSupervisor(req: Request, res: Response) {

  info.info(`editOrgSupervisor initiated`);
  info.info(`editOrgSupervisor reqParams:${JSON.stringify(req.params)}`);

  const { id } = req.params;
  const data = req.body
  const name = data.name;
  const mobileNumber = data.mobileNumber
  const shifts = data.shifts
  const email = data.email;
  const divId = data.divId;
  data.userType = "divS";
  const updatedData = {
    name,
    divId,
    mobileNumber,
    shifts,
    email,
    updatedAt: new Date()
  };
  try {

    await updateUser(id,data)
      .then(async()=>{
        await collection.findOneAndUpdate({ _id: id }, {
          $set: updatedData
        },
          {
            new: true
          });
    info.info(`editOrgSupervisor edited id:${id} updatedData:${JSON.stringify(updatedData)}` );
        const response = generateResponse('userDocument updated successfully', 200, 'success')
        res.status(200).json(response);
      })
      .catch((err)=>{
        res.status(500).send({
          message: "Something went wrong",
          error: err
        });
        });
   
  } catch (err: any) {
    error.error(`editOrgSupervisor error : ${err.message}`)
    res.status(500).json(generateResponse("Internal server error",500,"failed"));

  }
}

export async function removeOrgSupervisor(req: Request, res: Response) {
  info.info(`removeOrgSupervisor initiated`);
  info.info(`removeOrgSupervisor reqParams:${JSON.stringify(req.params)}`);

  const { id } = req.params;
  try {

    await deleteUser(id)
    .then(async()=>{
      info.info(`firebase user deleted`);
      await collection.findOneAndUpdate({ _id: id }, {
        $set: {
          isDeleted: true,
          updatedAt: new Date()
        }
      }, { new: true });
      info.info(`removeOrgSupervisor completed for id : ${id}`);
      const response = generateResponse('userDocument deleted successfully', 200, 'success')
      res.status(200).json(response);
    })
    .catch((err)=>{
      error.error(`deletePa firebase error:${err}`)
      res.status(500).send({
        success: false,
        message: "Something went wrong"
      });
    })

    
  } catch (err: any) {
    error.error(`removeOrgSupervisor error : ${err.message}`)
    res.status(500).json(generateResponse("Internal server error",500,"failed"));

  }
}

export async function deactivateOrgSupervisor (req: Request, res: Response) {
  const id = req.params.id;
  try{
    info.info(`deactivateOrgSupervisor initiated userId:${id}`);
    
    await disableUser(id)
    .then(async()=>{
      await collection.findOneAndUpdate({_id:id}, {
        $set: {
          isActive: false,
          updatedAt: new Date()
        }
      },
      {
        new: true
      });
      info.info(`deactivateOrgSupervisor id:${id} completed`);
      res.status(200).send({
        success: true,
        message: "Branch Supervisor Disabled successfully"
      })
    })
    .catch((err: any)=>{
      error.error(`deactivateOrgSupervisor id:${id} firebase error:${JSON.stringify(err)}`);
      res.status(err.status).send({message: err.message});
    })
  }
  catch(err: any){
    error.error(`deactivateOrgSupervisor id:${id} error:${err.message}`);
    res.status(400).send({
      success: false,
      message: err.message
    });
  }
}

export async function activateOrgSupervisor (req: Request, res: Response) {
  const id = req.params.id;
  try{
    info.info(`activateOrgSupervisor initiated userId:${id}`);
    
    await enableUser(id)
    .then(async()=>{
      await collection.findOneAndUpdate({_id:id}, {
        $set: {
          isActive: true,
          updatedAt: new Date()
        }
      },
      {
        new: true
      });
      info.info(`activateOrgSupervisor id:${id} completed`);
      res.status(200).send({
        success: true,
        message: "Branch Supervisor enabled successfully"
      })
    })
    .catch((err: any)=>{
      error.error(`activateOrgSupervisor id:${id} firebase error:${JSON.stringify(err)}`);
      res.status(err.status).send({message: err.message});
    })
  }
  catch(err: any){
    error.error(`activateOrgSupervisor id:${id} error:${err.message}`);
    res.status(400).send({
      success: false,
      message: err.message
    });
  }
}

export const supervisor = async (req: Request, res: Response) => {
  info.info(`supervisor initiated`);
  info.info(`supervisor queryParams: ${JSON.stringify(req.query)}`);
  
  const {orgId,page,pageSize, query}= req.query
  if(!orgId || orgId === ""){
    error.error(`supervisor error: orgId missing`);
    return res.status(400).json(generateResponse(`orgId missing`,400,`failed`))
  }
  const currentPage = parseInt(page as string, 10) || 1;
  const page_Size = parseInt(pageSize as string, 10) || 10;
  const filter: {
    orgId: any ;
    isDeleted: boolean;
    isActive: boolean;
    name?: RegExp; 
  } = {
    orgId,
    isDeleted: false,
    isActive: true
  };

  if (query) {
    filter.name = new RegExp(query as string, 'i');
  }

  try {
    const pipeline = [
      { $match: filter }, 
      {
        $facet: {
          totalCount: [ 
            { $count: "count" }
          ],
          data: [ 
            { $skip: (currentPage - 1) * page_Size },
            { $limit: page_Size },
            { $project: { name: 1, mobileNumber: 1 } } 
          ]
        }
      },
      {
        $project: {
          count: { $arrayElemAt: ["$totalCount.count", 0] }, 
          data: 1 
        }
      }
    ];
    info.info(`supervisor pipeLine :${JSON.stringify(pipeline)}`)
    const result = await collection.aggregate(pipeline).toArray();

    if (result.length > 0) {
      const responseData = {
        count: result[0].count, 
        data: result[0].data  
      };

      if (responseData.data.length === 0) {
        res.status(404).json(generateResponse(`No data found.`, 404, "not found"));
      } else {
      info.info(`supervisor data fetching completed`);
        res.status(200).json(generateResponse(`Data fetched.`, 200, "success", [responseData]));
      }
    } else {
      res.status(404).json(generateResponse(`No data found.`, 404, "not found"));
    }
  } catch (err: any) {
    error.error(`supervisor error: ${err.message}`)
    res.status(500).json(generateResponse(`Internal server error.`, 500, "failed"));
  }
};

export async function orgSupervisorDetails(req: Request, res: Response) {

  info.info(`orgSupervisorDetails initiated`);
  info.info(`orgSupervisorDetails reqParams:${JSON.stringify(req.params)}`);

  try {
    if (collection) {
      const { orgId } = req.params;
      const page = parseInt(req.query.page as string) || 1; 
      const limit = parseInt(req.query.limit as string) || 10; 
      const query = req.query.query || '';
      const searchFilter = {
        orgId,
        isDeleted: false,
        isActive: true,
        $or: [
          { name: { $regex: query, $options: 'i' } },
          { email: { $regex: query, $options: 'i' } },
          { mobileNumber: { $regex: query, $options: 'i' } }
        ]
      };

      const projection = {
        _id: 1,
        name: 1,
        email: 1,
        mobileNumber: 1,
        orgId: 1,
      };

      const skip = (page - 1) * limit;

      const users = await collection.find(searchFilter, { projection })
      .skip(skip)
      .limit(limit)
      .toArray();

      const response = generateResponse('userDocument found', 200, 'success',  users);
      res.status(200).json(response);
      info.info(`orgSupervisorDetails data:${JSON.stringify(users)}`)
    }
  } catch (err: any) {
    error.error(`getUserById errorMessage:${err.message}`);
    res.status(500).json(generateResponse("Internal server error",500,"failed"));
  }
}