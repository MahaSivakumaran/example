import { NextFunction, Request, Response } from "express";
import { info, error } from "../config/loggerConfig";
import { ApiFeatures } from "../utils/apiFeatures";
import { orgOwner } from "../model/orgOwnerModel";
import { addUser } from "../utils/userCounts";
import { generateResponse } from "../utils/responseGenerate";
import { createUser, deleteUser, disableUser, enableUser, existingEmailCheck, updateUser } from "../firebase";
import axios from "axios";
import { updateExpiredSubscription, verifyAndCreateNotification } from "./subscriptionNotificationController";
import { pushNotification } from "../lib/pushNotification";
const baseURL = process.env.BASE_URL;
const orgPort = process.env.ORG_PORT;


let collection: any;
export const ownerInstance = async () => {
  collection = await orgOwner();
}


export async function createOrgOwner(req: Request, res: Response) {

  info.info(`createOrgOwner initiated`);
  info.info(`createOrgOwner payload:${JSON.stringify(req.body)}`);

  try {
    const { name, email, mobileNumber, orgId } = req.body;
    const id = await addUser('orgOwner');
    req.body.uid = id;
    req.body.userType = "orgOwner";
    const userData ={   
      _id: id,
      orgId: orgId,
      name,
      email,
      mobileNumber,
      fcmToken: "",
      isActive: true,
      isDeleted: false,
      createdAt: new Date(),
      updatedAt: new Date()

    }

    await createUser(req) 
    .then(async()=>{
      info.info("Firebase user created");
      await collection.insertOne(userData);
      info.info(`createOrgOwner created data:${JSON.stringify(userData)}`);
      const response = generateResponse('user created successfully', 200, 'success')
      res.status(200).json(response);
    })
    .catch((err)=>{
      error.error(`firebase user not created error:${err.message}`);
      res.status(err.status).send({message: err.message});
     return;
      });
  } catch (err: any) {
    error.error(`createOrgAdmin errorMessage:${err.message}`);
    res.status(500).send({message: err.message});
  }

}


// Get All Orgnization owner


export async function getAllOrgOwner(req: Request, res: Response) {
  info.info(`getAllOrgOwner initiated`);
  info.info(`getAllOrgOwner reqParams:${JSON.stringify(req.query)}`);

  try {
    if (collection) {
      const { query, page, sort, sortBy, pageSize} = req.query;
      const queryHandler = new ApiFeatures(collection, query, page, sort, sortBy, pageSize);
      const userList = await queryHandler.searchAndPaginate();

      if (userList && userList.list && Array.isArray(userList.list)) {
        const ids  = userList.list.map((user: any) => user.orgId);    
        
        const orgDetailsResponse = await axios.post(`http://${baseURL}:${orgPort}/api/org/details`,{ids})        
        const orgDetailsMap = new Map(orgDetailsResponse.data.map((org: any) => [org._id, org]));
        const enrichedUserList = userList.list.map((user, index) => ({
          ...user,
          orgDetails: orgDetailsMap.get(user.orgId)
        }));

        if (userList) {
          const response = generateResponse('userDocument fetched successfully', 200, 'success', {
            ...userList,
            list: enrichedUserList,
          });
          res.status(200).json(response);
          info.info(`getAllOrgOwner data: ${ JSON.stringify({
            ...userList,
            list: enrichedUserList,
          })}`);
        } else {
          const response = generateResponse('invalid request', 404, 'error', userList);
          res.status(400).json(response);
        }
      }
    }
  } catch (err: any) {
    error.error(`OrganizationOwnerDocument errorMessage:${err.message}`);
    res.status(500).json(generateResponse("Internal server error",500,"failed"));
  }
}


// Org Owner Self

export async function orgOwnerSelf(req: Request, res: Response) {

  info.info(`orgOwnerSelf initiated`);
  info.info(`orgOwnerSelf req.headers:${JSON.stringify(req.headers)}`);

  try {
    const userAgent = JSON.parse((req as any).headers['x-user-agent']);
    const id = userAgent.userId
    if (!id) {
      error.error(`orgOwnerSelf error: id missing`)
      return res.status(404).json(generateResponse("Id is missing",404,"failed"))
    }
    if (collection) {

      const projection = {
        _id: 1,
        name: 1,
        email: 1,
        mobileNumber: 1
      };

      const user = await collection.findOne({ _id: id }, { projection });
      if (user) {
        const axiosResponse = await axios.get(`http://${baseURL}:${orgPort}/api/org/orgDetails/${user.orgId}`);
        const userData = {
        user, ...axiosResponse.data        
      };
        info.info(`get Self document id:${id} userData:${JSON.stringify(userData)}`);
        const response = generateResponse('userDocument created successfully', 200, 'success', userData)
        res.status(200).json(response);
      } else {
        const response = generateResponse('user not found', 404, 'error')
        res.status(404).json(response);
        error.error(`orgOwnerSelf error: user not found`)
      }

    }
  } catch (err: any) {
    error.error(`getUserById errorMessage:${err.message}`);
    res.status(500).json({ success: false, error: 'Internal Server Error' });

  }
}

export async function oneOrgOwner(req: Request, res: Response) {

  info.info(`oneOrgOwner initiated`);
  info.info(`oneOrgOwner reqParams:${JSON.stringify(req.params)}`);

  try {
    const { id } = req.params;
      if (collection) {

      const projection = {
        _id: 1,
        name: 1,
        email: 1,
        mobileNumber: 1,
        isActive:1,
        orgId: 1
      };

      const user = await collection.findOne({ _id: id }, { projection });
      if (user) {
        const axiosResponse = await axios.get(`http://${baseURL}:${orgPort}/api/org/orgDetails/${user.orgId}`);
        const userData = {
        user,
        orgDetails: axiosResponse.data
      };
        info.info(`getUserById document found for id : ${id} `);
        const response = generateResponse('userDocument found', 200, 'success', userData)
        res.status(200).json(response);
      } else {
        const response = generateResponse('user not found', 404, 'error')
        res.status(404).json(response);
        error.error(`oneOrgOwner error: user not found`)
      }

    }
  } catch (err: any) {
    error.error(`oneOrgOwner errorMessage:${err.message}`);
    res.status(500).json(generateResponse("Internal server error",500,"failed"));    
  }
}


//update Org Owner details

export async function editOrgOwner(req: Request, res: Response) {
  info.info(`editOrgOwner initiated`);
  info.info(`editOrgOwner reqParams:${JSON.stringify(req.params)}`);

  const { id } = req.params;
  const data = req.body
  const name = data.name;
  const email = data.email;
  const mobileNumber = data.mobileNumber;
  data.userType = "orgOwner";
  const updatedData = {
    name,
    mobileNumber,
    email,
    updatedAt: new Date()
  };
  try {
    await updateUser(id,data)
      .then(async()=>{
        await collection.findOneAndUpdate({ _id: id }, {
          $set: updatedData
        },
          {
            new: true
          });
      info.info(`editOrgOwner work completed for id : ${id}updatedData:${JSON.stringify(updatedData)}`);
          const response = generateResponse('user updated successfully', 200, 'success')
          res.status(200).json(response);
      })
      .catch((err)=>{
        res.status(500).send({
          message: "Something went wrong",
          error: err
        });
        });
  } catch (err: any) {
    error.error(`editOrgOwner errorMessage:${err.message}`);
    res.status(500).json(generateResponse("Internal server error",500,"failed"));


  }
}

//delete Org Owner

export async function removeOrgOwner(req: Request, res: Response) {
  info.info(`removeOrgOwner delete initiated`);
  info.info(`removeOrgOwner reqParams:${JSON.stringify(req.params)}`);
  
  const { id } = req.params;
  try {
    await deleteUser(id)
    .then(async()=>{
      info.info(`firebase user deleted`);
      await collection.findOneAndUpdate({ _id: id }, {
        $set: {
          isDeleted: true,
          updatedAt: new Date()
        }
      }, { new: true });
        info.info(`orgOwner sucessfuly deleted for id : ${id}`);
        const response = generateResponse('userDocument deleted successfully', 200, 'success')
        res.status(200).json(response);
    })
    .catch((err)=>{
      error.error(`deleteOrgOwner firebase error:${err}`)
      res.status(500).send({
        success: false,
        message: "Something went wrong"
      });
    })
    
  } catch (err: any) {
    error.error(`removeOrgOwner error : ${err.message}`)
    res.status(500).json(generateResponse("Internal server error",500,"failed"));
  }
}

export async function deactivateOrgOwner (req: Request, res: Response) {
  const id = req.params.id;
  try{
    info.info(`deactivateOrgOwner initiated userId:${id}`);
    await disableUser(id)
    .then(async()=>{
      await collection.findOneAndUpdate({_id:id}, {
        $set: {
          isActive: false,
          updatedAt: new Date()
        }
      },
      {
        new: true
      });
      info.info(`deactivateOrgOwner id:${id} completed`);
      res.status(200).send({
        success: true,
        message: "Hotel Owner Disabled successfully"
      })
    })
    .catch((err: any)=>{
      error.error(`deactivateOrgOwner id:${id} firebase error:${JSON.stringify(err)}`);
      res.status(err.status).send({message: err.message});
    })
  }
  catch(err: any){
    error.error(`deactivateOrgOwner id:${id} error:${err.message}`);
    res.status(400).send({
      success: false,
      message: err.message
    });
  }
}

export async function activateOrgOwner (req: Request, res: Response) {
  const id = req.params.id;
  try{
    info.info(`activateOrgOwner initiated userId:${id}`);
    await enableUser(id)
    .then(async()=>{
      await collection.findOneAndUpdate({_id:id}, {
        $set: {
          isActive: true,
          updatedAt: new Date()
        }
      },
      {
        new: true
      });
      info.info(`activateOrgOwner id:${id} completed`);
      res.status(200).send({
        success: true,
        message: "Hotel Owner enabled successfully"
      })
    })
    .catch((err: any)=>{
      error.error(`activateOrgOwner id:${id} firebase error:${JSON.stringify(err)}`);
      res.status(err.status).send({message: err.message});
    })
  }
  catch(err: any){
    error.error(`activateOrgOwner id:${id} error:${err.message}`);
    res.status(400).send({
      success: false,
      message: err.message
    });
  }
}

export const orgUserList = async (req: Request, res: Response) => {  
  try {
    info.info(`orgUserList fetching initiated `);
    info.info(`orgUserList req.params ${JSON.stringify(req.params)}`);
    info.info(`orgUserList req.query ${JSON.stringify(req.query)}`);
    const  orgId  = req.params.id;    
    const query = req.query
    const searchCriteria = query.query as string;
    let page = parseInt(query.page as string, 10) || 1;
    const pageSize = parseInt(query.pageSize as string, 10) || 10;
    let skip = (page - 1) * pageSize;
    const sortField = query.sortField ? query.sortField.toString() : 'orgName';
    const sortOrder = query.sortOrder === 'desc' ? -1 : 1;
    skip = (page - 1) * pageSize;
    
    const result = await collection.aggregate([
      {
        $addFields: {
          'userType': 'Owner',
        }
      },
      {
        $match: {
          'orgId': orgId,
          'isDeleted':false,
          $or: [
            { 'name': { $regex: new RegExp(searchCriteria, 'i') } },
            { 'email': { $regex: new RegExp(searchCriteria, 'i') } },
            { 'mobileNumber': { $regex: new RegExp(searchCriteria, 'i') } },
            { 'userType': { $regex: new RegExp(searchCriteria, 'i') } },
          ]
        }
      },
      {
        $unionWith: {
          coll: 'organisationSupervisor',
          pipeline: [
            {
              $addFields: {
                'userType': 'Supervisor',
              }
            },
            {
              $match: {
                'orgId': orgId,
                'isDeleted':false,
    
                $or: [
                  { 'name': { $regex: new RegExp(searchCriteria, 'i') } },
                  { 'email': { $regex: new RegExp(searchCriteria, 'i') } },
                  { 'mobileNumber': { $regex: new RegExp(searchCriteria, 'i') } },
                  { 'userType': { $regex: new RegExp(searchCriteria, 'i') } },
                ]
              }
            },
          ]
        }
      },
      {
        $unionWith: {
          coll: 'organisationManager',
          pipeline: [
            {
              $addFields: {
                'userType': 'Manager',
              }
            },
            {
              $match: {
                'orgId': orgId,
                'isDeleted':false,
    
                $or: [
                  { 'name': { $regex: new RegExp(searchCriteria, 'i') } },
                  { 'email': { $regex: new RegExp(searchCriteria, 'i') } },
                  { 'mobileNumber': { $regex: new RegExp(searchCriteria, 'i') } },
                  { 'userType': { $regex: new RegExp(searchCriteria, 'i') } },
                ]
              }
            },
          ]
        }
      },
      {
        $unionWith: {
          coll: 'organisationAdmin',
          pipeline: [
            {
              $addFields: {
                'userType': 'Admin',
              }
            },
            {
              $match: {
                'orgId': orgId,
                'isDeleted':false,
    
                $or: [
                  { 'name': { $regex: new RegExp(searchCriteria, 'i') } },
                  { 'email': { $regex: new RegExp(searchCriteria, 'i') } },
                  { 'mobileNumber': { $regex: new RegExp(searchCriteria, 'i') } },
                  { 'userType': { $regex: new RegExp(searchCriteria, 'i') } },
                ]
              }
            },
          ]
        }
      },
      {
        $unionWith: {
          coll: 'transactionPointUser',
          pipeline: [
            {
              $addFields: {
                'userType': 'Pickup Counter User',
              }
            },
            {
              $match: {
                'orgId': orgId,
                'isDeleted':false,
    
                $or: [
                  { 'name': { $regex: new RegExp(searchCriteria, 'i') } },
                  { 'email': { $regex: new RegExp(searchCriteria, 'i') } },
                  { 'mobileNumber': { $regex: new RegExp(searchCriteria, 'i') } },
                  { 'userType': { $regex: new RegExp(searchCriteria, 'i') } },
                ]
              }
            },
          ]
        }
      },
      {
        $unionWith: {
          coll: 'orgGodownUser',
          pipeline: [
            {
              $addFields: {
                'userType': 'Store User',
              }
            },
            {
              $match: {
                'orgId': orgId,
                'isDeleted':false,
    
                $or: [
                  { 'name': { $regex: new RegExp(searchCriteria, 'i') } },
                  { 'email': { $regex: new RegExp(searchCriteria, 'i') } },
                  { 'mobileNumber': { $regex: new RegExp(searchCriteria, 'i') } },
                  { 'userType': { $regex: new RegExp(searchCriteria, 'i') } },
                ]
              }
            },
          ]
        }
      },
      {
        $sort: {
          
          [sortField === 'name' ? 'name' : 'userType']: sortOrder,
        },
      },
      {
        $facet: {
         result: [
            { $skip: skip },
            { $limit: pageSize },
            {
              $project: {
                _id: 1,
                orgId: 1,
                name: 1,
                email: 1,
                mobileNumber: 1,
                userType: 1,
                isActive:1
              }
            }
          ],
          totalCount: [
            {
              $count: 'value'
            }
          ]
        }
      },
      {
        $project: {
          page: 1,
          pageSize: 1,
          totalCount: { $arrayElemAt: ['$totalCount.value', 0] },
          data: '$result',
        }
      }
    ]).toArray();
    const userTypeOrder = ['Owner', 'Admin', 'Manager', 'Supervisor', 'Store User', 'Pickup Counter User'];
    result[0]?.data.sort((a: any, b: any) => {
  if (sortField === 'name') {
    return a.name.localeCompare(b.name) * sortOrder;
  } else {
    const userTypeA = userTypeOrder.indexOf(a.userType);
    const userTypeB = userTypeOrder.indexOf(b.userType);

    if (userTypeA !== userTypeB) {
      return userTypeA - userTypeB; 
    } else {
     
      return a.name.localeCompare(b.name) * sortOrder;
    }
  }
});
    const data = {
      totalCount: result[0]?.totalCount || 0,
      list: result[0]?.data || [],
    };
    const response = generateResponse('userDocument fetched', 200, 'success', data)
    res.status(200).json(response);
    info.info(`orgUserList data:${JSON.stringify(data)}  `);
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Internal Server Error' });
    error.error(`orgUser fetching error ${err.message}`)
  }
 
};
 
export async function selfEdit (req: Request, res: Response){
  
  try {
    info.info(`selfEdit initiated`);
    info.info(`selfEdit req.body: ${JSON.stringify(req.body)}`);
    
    const userAgent = JSON.parse((req as any).headers['x-user-agent']);
    const id = userAgent.userId
    const data = req.body
    const name = data.name;
    const email = data.email;
    const mobileNumber = data.mobileNumber
    const updatedData = {
      name,
      mobileNumber,
      email,
      updatedAt: new Date()
    }
    await collection.findOneAndUpdate({_id:id},{
      $set : updatedData
    },
    {
      new: true
    });
    info.info(`selfEdit completed for the Id : ${id}`);
    const response  = generateResponse("Edited successfully..",200,"success");
    res.status(200).json(response)
  } catch (err:any) {
    error.error(`selfEdit Error : ${err.message}`);
    const response  = generateResponse("Internal server error",500,"failed");
    res.status(500).json(response)
  }
}

export async function emailVerification(req: Request, res: Response) {
  const {email} = req.query;
  info.info(`emailVerification initiated email:${email}`);
  try {
    existingEmailCheck(email)
      .then((exists) => {
        if (exists) {
          info.info(`emailVerification email:${email} already exists.`);
          res.status(200).send({
            emailExists: true
          });
        } else {
          info.info(`emailVerification email:${email} not exists.`);
          res.status(200).send({
            emailExists: false
          });
        }
      })
      .catch((err: any) => {
        console.error('Error checking email existence:', error);
        error.error(`emailVerification email:${email} error:${err.message}`);
        res.status(500).send({
          message: "Internal server error"
        });
      });
  }
  catch(err: any){
    error.error(`emailVerification email:${email} error:${err.message}`);
    res.status(500).json(generateResponse("Internal server error", 500, "Failed"));
  }
}

export async function getOwnerDetailsByOrgID ( orgIds: any ) {
  // for subscription notification function
  info.info(`getOwnerDetailsByOrgID orgIds:${JSON.stringify(orgIds)} initiated`);
  try{
    const ownerData = await collection.find({orgId: {$in : orgIds}}, { projection: {orgId: 1, fcmToken: 1, _id: 1}}).toArray();
    if(ownerData)
    {
      return ownerData;
    }
    else{
      return false;
    }
  }
  catch(err: any)
  {
    error.error(`getOwnerDetailsByOrgID orgIds:${JSON.stringify(orgIds)} error:${err.message}`);
    return false;
  }
}

export async function updateFcmToken (req: Request, res: Response) {
  const {id} = req.params;
  try{
    info.info(`updateFcmToken id:${id} initiated`);
    const userData = await collection.find({_id: id, isDeleted: false});
    if(userData.length < 1)
    {
      error.error(`updateFcmToken id:${id} user not found`);
      res.status(404).json(generateResponse("User not found", 404, "Failed"));
    }
    const {fcmToken} = req.body;
    await collection.findOneAndUpdate({_id: id},
      {
        $set: {fcmToken}
      },
      {
        new: true
      });
      info.info(`updateFcmToken updated id:${id} fcmToken:${fcmToken}`);
      res.status(200).json(generateResponse("FCM updated successfully", 200, "Success"));
  }
  catch(err: any) {
    error.error(`updateFcmToken error:${err.message}`);
    res.status(500).json(generateResponse("Internal server error", 500, "Failed"));
  }
}

export const subscriptionNotification = async (req: Request, res: Response) => {
  try {
    info.info(`subscriptionNotification initiated`);
    info.info(`subscriptionNotification req.body:${req.body}`);

    const { isExpired, orgData } = req.body;

    const orgId = orgData.map((org: { orgId: string }) => {
      return org.orgId;
    });
    if (orgId.length > 0) {
      const query = { orgId: { $in: orgId } };
      const projection = {
        _id: 1,
        orgId: 1,
        fcmToken: 1,
      };
      const userDetails = await collection
        .find(query, { projection })
        .toArray();

      if (userDetails.length > 0) {
        var notification = {};
        if (!isExpired) {
          var check: any = await verifyAndCreateNotification(orgId, isExpired);
          if (!check) {
            error.error(
              `subscriptionNotification verifyAndCreateNotification error`
            );
            return res
              .status(500)
              .json(
                generateResponse(
                  "verifyAndCreateNotification Failed",
                  500,
                  "Failed"
                )
              );
          }
          notification = {
            title: "Subscription Ending Soon",
            body: "Renew now for uninterrupted access to premium features.",
          };
        } else {
          var check: any = await updateExpiredSubscription(orgId, isExpired);
          if (!check) {
            error.error(
              `subscriptionNotification updateExpiredSubscription error`
            );
            return res
              .status(500)
              .json(
                generateResponse(
                  "updateExpiredSubscription Failed",
                  500,
                  "Failed"
                )
              );
          }
          notification = {
            title: "Subscription Ended",
            body: "Reactivate now to enjoy uninterrupted access to premium features.",
          };
        }
        var FcmTokenAndSubDetails: {
          notification: {};
          token: string;
          data: any;
        }[] = [];

        check.forEach((fcmItem: { orgId: string; fcmToken: string }) => {
          const matchingOrg = orgData.find(
            (orgDetails: { orgId: string }) =>
              orgDetails.orgId === fcmItem.orgId
          );

          if (matchingOrg) {
            // notification allow only strings
            matchingOrg.features = matchingOrg.features.toString();
            matchingOrg.amount = matchingOrg.amount.toString();
            matchingOrg.isExpired = matchingOrg.isExpired.toString();
            matchingOrg.isUnSubscribed = matchingOrg.isUnSubscribed.toString();
            FcmTokenAndSubDetails.push({
              notification,
              token: fcmItem.fcmToken,
              data: matchingOrg,
            });
          }
        });

        let result = await pushNotification(FcmTokenAndSubDetails);

        if (result) {
          console.log("message sent to success");
        } else {
          console.log("No message sent to user");
        }
      } else {
        error.error(`subscriptionNotification orgId:${orgId} no user found`);
        return res
          .status(404)
          .json(generateResponse("No data found", 404, "Failed"));
      }
    } else {
      return res.status(400).json(`subscriptionNotification orgId missing`);
    }
  } catch (err: any) {
    error.error(`subscriptionNotification error:${err.message}`);
  }
};

export const userCounts = async (req: Request, res: Response) => {

  info.info(`userCounts initiated`);
  info.info(`userCounts queryParams: ${JSON.stringify(req.query)}`);
  const { orgId , divId} = req.query;
  if(!orgId || orgId === ""){
    error.error(`userCounts orgId:${orgId} error: OrgId missing`);
    return res.status(400).json(generateResponse(`orgId is missing..`,400,`failed`))
  }
  try {
    const filter = ((req as any).firebaseData.uid.includes("orgOwner") || (req as any).firebaseData.uid.includes("orgAd")) ? {
      orgId,
      isDeleted: false,
      isActive: true,
    } : {
      divId,
      isDeleted: false,
      isActive: true,
    };
    const inactiveFilter = ((req as any).firebaseData.uid.includes("orgOwner") || (req as any).firebaseData.uid.includes("orgAd")) ? {
      orgId,
      isDeleted: false,
      isActive: false,
    } :
    {
      divId,
      isDeleted: false,
      isActive: false,
    };
    let managerAccess: any = 0, supervisorAccess: any = 0, adminAccess: any = 0, gUserAccess: any = 0, tUserAccess: any = 0;
    let inactiveManager: any = 0, inactiveSupervisor: any = 0, inactiveAdmin: any = 0, inactiveGUser: any = 0, inactiveTUser: any = 0;
    let orgAdmin: any = 0, divM: any = 0, divS: any = 0, gUser: any = 0, tUser: any = 0;
    if ((req as any).firebaseData.uid.includes("orgOwner")) {
      managerAccess = {
        from: 'organisationManager',
        pipeline: [
          {
            $match: filter,
          },
          {
            $count: 'managerCount',
          },
        ],
        as: 'managerCounts',
      };
      supervisorAccess = {
        from: 'organisationSupervisor',
        pipeline: [
          {
            $match: filter,
          },
          {
            $count: 'supervisorCount',
          },
        ],
        as: 'supervisorCounts',
      };
      gUserAccess = {
        from: 'orgGodownUser',
        pipeline: [
          {
            $match: filter,
          },
          {
            $count: 'storeUserCount',
          },
        ],
        as: 'storeUsers',
      };
      adminAccess = {
        from: 'organisationAdmin',
        pipeline: [
          {
            $match: filter,
          },
          {
            $count: 'adminCount',
          },
        ],
        as: 'adminCounts',
      };
      tUserAccess = {
        from: 'transactionPointUser',
        pipeline: [
          {
            $match: filter,
          },
          {
            $count: 'pickupCounterUserCount',
          },
        ],
        as: 'pickupCounterUsers',
      };
      inactiveManager = {
        from: 'organisationManager',
        pipeline: [
          {
            $match: inactiveFilter,
          },
          {
            $count: 'totalInactiveCount',
          },
        ],
        as: 'totalInactiveManagerCount',
      };
      inactiveSupervisor = {
        from: 'organisationSupervisor',
        pipeline: [
          {
            $match: inactiveFilter,
          },
          {
            $count: 'totalInactiveCount',
          },
        ],
        as: 'totalInactiveSupervisorCount',
      };
      inactiveAdmin = {
        from: 'organisationAdmin',
        pipeline: [
          {
            $match: inactiveFilter,
          },
          {
            $count: 'totalInactiveCount',
          },
        ],
        as: 'totalInactiveAdminCount',
      };
      inactiveGUser = {
        from: 'orgGodownUser',
        pipeline: [
          {
            $match: inactiveFilter,
          },
          {
            $count: 'totalInactiveCount',
          },
        ],
        as: 'totalInactiveStoreUserCount',
      };
      inactiveTUser = {
        from: 'transactionPointUser',
        pipeline: [
          {
            $match: inactiveFilter,
          },
          {
            $count: 'totalInactiveCount',
          },
        ],
        as: 'totalInactivePickupCounterUserCount',
      }
    }
    else {
      const accessObj = (req as any).firebaseData.customClaims.access;
      for (let outerObj of accessObj) {
        if (outerObj.access) {
          for (let innerObj of outerObj.access) {
            if (outerObj.title == "UM" && innerObj.isAllowed == true) {
              switch (innerObj.title) {
                case "orgAdmin":
                  orgAdmin = 1;
                  break;
                case "divM":
                  divM = 1;
                  break;
                case "divS":
                  divS = 1;
                  break;
                case "gUser":
                  gUser = 1;
                  break;
                case "tUser":
                  tUser = 1;
                  break;
                default:
                  break;
              }
            }
          }
        }
      }
      if (orgAdmin) {
        adminAccess = {
          from: 'organisationAdmin',
          pipeline: [
            {
              $match: filter,
            },
            {
              $count: 'adminCount',
            },
          ],
          as: 'adminCounts',
        };
        inactiveAdmin = {
          from: 'organisationAdmin',
          pipeline: [
            {
              $match: inactiveFilter,
            },
            {
              $count: 'totalInactiveCount',
            },
          ],
          as: 'totalInactiveAdminCount',
        };
      }
      if (divM) {
        managerAccess = {
          from: 'organisationManager',
          pipeline: [
            {
              $match: filter,
            },
            {
              $count: 'managerCount',
            },
          ],
          as: 'managerCounts',
        };
        inactiveManager = {
          from: 'organisationManager',
          pipeline: [
            {
              $match: inactiveFilter,
            },
            {
              $count: 'totalInactiveCount',
            },
          ],
          as: 'totalInactiveManagerCount',
        };
      }
      if (divS) {
        supervisorAccess = {
          from: 'organisationSupervisor',
          pipeline: [
            {
              $match: filter,
            },
            {
              $count: 'supervisorCount',
            },
          ],
          as: 'supervisorCounts',
        };
        inactiveSupervisor = {
          from: 'organisationSupervisor',
          pipeline: [
            {
              $match: inactiveFilter,
            },
            {
              $count: 'totalInactiveCount',
            },
          ],
          as: 'totalInactiveSupervisorCount',
        };
      }
      if (gUser) {
        gUserAccess = {
          from: 'orgGodownUser',
          pipeline: [
            {
              $match: filter,
            },
            {
              $count: 'storeUserCount',
            },
          ],
          as: 'storeUsers',
        };
        inactiveGUser = {
          from: 'orgGodownUser',
          pipeline: [
            {
              $match: inactiveFilter,
            },
            {
              $count: 'totalInactiveCount',
            },
          ],
          as: 'totalInactiveStoreUserCount',
        };
      }
      if (tUser) {
        tUserAccess = {
          from: 'transactionPointUser',
          pipeline: [
            {
              $match: filter,
            },
            {
              $count: 'pickupCounterUserCount',
            },
          ],
          as: 'pickupCounterUsers',
        };
        inactiveTUser = {
          from: 'transactionPointUser',
          pipeline: [
            {
              $match: inactiveFilter,
            },
            {
              $count: 'totalInactiveCount',
            },
          ],
          as: 'totalInactivePickupCounterUserCount',
        }
      }
    }

    let pipeline = [];
    let add = [];

    if (adminAccess) {
      pipeline.push({ $lookup: adminAccess });
      pipeline.push({ $lookup: inactiveAdmin });
      add.push({ $ifNull: [{ $arrayElemAt: ['$totalInactiveAdminCount.totalInactiveCount', 0] }, 0] })
    }

    if (managerAccess) {
      pipeline.push({ $lookup: managerAccess });
      pipeline.push({ $lookup: inactiveManager });
      add.push({ $ifNull: [{ $arrayElemAt: ['$totalInactiveManagerCount.totalInactiveCount', 0] }, 0] });
    }

    if (supervisorAccess) {
      pipeline.push({ $lookup: supervisorAccess });
      pipeline.push({ $lookup: inactiveSupervisor });
      add.push({ $ifNull: [{ $arrayElemAt: ['$totalInactiveSupervisorCount.totalInactiveCount', 0] }, 0] })
    }

    if (gUserAccess) {
      pipeline.push({ $lookup: gUserAccess });
      pipeline.push({ $lookup: inactiveGUser });
      add.push({ $ifNull: [{ $arrayElemAt: ['$totalInactiveStoreUserCount.totalInactiveCount', 0] }, 0] })
    }

    if (tUserAccess) {
      pipeline.push({ $lookup: tUserAccess });
      pipeline.push({ $lookup: inactiveTUser });
      add.push({ $ifNull: [{ $arrayElemAt: ['$totalInactivePickupCounterUserCount.totalInactiveCount', 0] }, 0] })
    }

    let check: any;

    if (add.length > 0) {
      check = { $add: add }
    }
    else {
      check = 0;
    }

    pipeline.push({
      $project: {
        ...(adminAccess && { adminCount: { $ifNull: [{ $arrayElemAt: ['$adminCounts.adminCount', 0] }, 0] } }),
        ...(managerAccess && { managerCount: { $ifNull: [{ $arrayElemAt: ['$managerCounts.managerCount', 0] }, 0] } }),
        ...(supervisorAccess && { supervisorCount: { $ifNull: [{ $arrayElemAt: ['$supervisorCounts.supervisorCount', 0] }, 0] } }),
        ...(gUserAccess && { storeUserCount: { $ifNull: [{ $arrayElemAt: ['$storeUsers.storeUserCount', 0] }, 0] } }),
        ...(tUserAccess && { pickupCounterUserCount: { $ifNull: [{ $arrayElemAt: ['$pickupCounterUsers.pickupCounterUserCount', 0] }, 0] } }),
        totalInactiveCount: check,
      },
    });
    info.info(`userCounts orgId:${orgId} pipeLine:${JSON.stringify(pipeline)}`)
    const result = await collection.aggregate(pipeline).toArray();
    if (result.length > 0) {
      const {
        managerCount,
        supervisorCount,
        adminCount,
        storeUserCount,
        pickupCounterUserCount,
        totalInactiveCount,
      } = result[0];
      info.info(`userCounts orgId:${orgId} data fetched`)
      res.status(200).json(generateResponse(`Data fetched.`, 200, `success`, {
        managerCount,
        supervisorCount,
        adminCount,
        storeUserCount,
        pickupCounterUserCount,
        totalInactiveCount,
      }));
    } else {
      error.error(`userCounts orgId:${orgId} error: no data found`);
      res.status(200).json(generateResponse(`No data found.`, 200, `success`, {
        managerCount: 0,
        supervisorCount: 0,
        adminCount: 0,
        storeUserCount: 0,
        pickupCounterUserCount: 0,
        totalInactiveCount: 0,
      }));
    }
  } catch (err: any) {
    res.status(500).json(generateResponse(`Internal server error`, 500, `failed`));
    error.error(`userCounts orgId:${orgId} error: ${err.message}`)
  }
};

export const inActiveUserList = async (req: Request, res: Response) => {
  info.info(`inActiveUserList fetching initiated `);
  info.info(`inActiveUserList req.query ${JSON.stringify(req.query)}`);
  const { orgId } = req.query;
  if (!orgId) {
    error.error(`inActiveUserList error: orgId missing`)
    return res.status(404).json(generateResponse("orgId is missing", 404, "failed"))
  }
  try {
    const searchCriteria = req.query.query as string;
    let page = parseInt(req.query.page as string, 10) || 1;
    const pageSize = parseInt(req.query.pageSize as string, 10) || 10;
    let skip = (page - 1) * pageSize;
    skip = (page - 1) * pageSize;

    let managerAccess: any = 0, supervisorAccess: any = 0, adminAccess: any = 0, gUserAccess: any = 0, tUserAccess: any = 0;
    let orgAdmin: any = 0, divM: any = 0, divS: any = 0, gUser: any = 0, tUser: any = 0;

    if ((req as any).firebaseData.uid.includes("orgOwner")) {
      managerAccess = {
        coll: 'organisationManager',
        pipeline: [
          {
            $addFields: {
              'userType': 'Manager',
            }
          },
          {
            $match: {
              'orgId': orgId,
              'isDeleted': false,
              'isActive': false,
              $or: [
                { 'name': { $regex: new RegExp(searchCriteria, 'i') } },

              ]
            }
          },
        ]
      };
      supervisorAccess = {
        coll: 'organisationSupervisor',
        pipeline: [
          {
            $addFields: {
              'userType': 'Supervisor',
            }
          },
          {
            $match: {
              'orgId': orgId,
              'isDeleted': false,
              'isActive': false,
              $or: [
                { 'name': { $regex: new RegExp(searchCriteria, 'i') } },

              ]
            }
          },
        ]
      };
      gUserAccess = {
        coll: 'orgGodownUser',
        pipeline: [
          {
            $addFields: {
              'userType': 'Store',
            }
          },
          {
            $match: {
              'orgId': orgId,
              'isDeleted': false,
              'isActive': false,
              $or: [
                { 'name': { $regex: new RegExp(searchCriteria, 'i') } },

              ]
            }
          },
        ]
      };
      adminAccess = {
        coll: 'organisationAdmin',
        pipeline: [
          {
            $addFields: {
              'userType': 'Admin',
            }
          },
          {
            $match: {
              'orgId': orgId,
              'isDeleted': false,
              'isActive': false,
              $or: [
                { 'name': { $regex: new RegExp(searchCriteria, 'i') } },

              ]
            }
          },
        ]
      };
      tUserAccess = {
        coll: 'transactionPointUser',
        pipeline: [
          {
            $addFields: {
              'userType': 'Pickup Counter',
            }
          },
          {
            $match: {
              'orgId': orgId,
              'isDeleted': false,
              'isActive': false,
              $or: [
                { 'name': { $regex: new RegExp(searchCriteria, 'i') } },

              ]
            }
          },
        ]
      };
    }
    else {
      const accessObj = (req as any).firebaseData.customClaims.access;
      for (let outerObj of accessObj) {
        if (outerObj.access) {
          for (let innerObj of outerObj.access) {
            if (outerObj.title == "UM" && innerObj.isAllowed == true) {
              switch (innerObj.title) {
                case "orgAdmin":
                  orgAdmin = 1;
                  break;
                case "divM":
                  divM = 1;
                  break;
                case "divS":
                  divS = 1;
                  break;
                case "gUser":
                  gUser = 1;
                  break;
                case "tUser":
                  tUser = 1;
                  break;
                default:
                  break;
              }
            }
          }
        }
      }
      if (orgAdmin) {
        adminAccess = {
          coll: 'organisationAdmin',
          pipeline: [
            {
              $addFields: {
                'userType': 'Admin',
              }
            },
            {
              $match: {
                'orgId': orgId,
                'isDeleted': false,
                'isActive': false,
                $or: [
                  { 'name': { $regex: new RegExp(searchCriteria, 'i') } },

                ]
              }
            },
          ]
        };
      }
      if (divM) {
        managerAccess = {
          coll: 'organisationManager',
          pipeline: [
            {
              $addFields: {
                'userType': 'Manager',
              }
            },
            {
              $match: {
                'orgId': orgId,
                'isDeleted': false,
                'isActive': false,
                $or: [
                  { 'name': { $regex: new RegExp(searchCriteria, 'i') } },

                ]
              }
            },
          ]
        };
      }
      if (divS) {
        supervisorAccess = {
          coll: 'organisationSupervisor',
          pipeline: [
            {
              $addFields: {
                'userType': 'Supervisor',
              }
            },
            {
              $match: {
                'orgId': orgId,
                'isDeleted': false,
                'isActive': false,
                $or: [
                  { 'name': { $regex: new RegExp(searchCriteria, 'i') } },

                ]
              }
            },
          ]
        };
      }
      if (gUser) {
        gUserAccess = {
          coll: 'orgGodownUser',
          pipeline: [
            {
              $addFields: {
                'userType': 'Store',
              }
            },
            {
              $match: {
                'orgId': orgId,
                'isDeleted': false,
                'isActive': false,
                $or: [
                  { 'name': { $regex: new RegExp(searchCriteria, 'i') } },

                ]
              }
            },
          ]
        };
      }
      if (tUser) {
        tUserAccess = {
          coll: 'transactionPointUser',
          pipeline: [
            {
              $addFields: {
                'userType': 'Pickup Counter',
              }
            },
            {
              $match: {
                'orgId': orgId,
                'isDeleted': false,
                'isActive': false,
                $or: [
                  { 'name': { $regex: new RegExp(searchCriteria, 'i') } },

                ]
              }
            },
          ]
        };
      }
    }

    let pipeline = [];
    pipeline.push({
      $match: {
        _id: null
      }
    });

    if (adminAccess) {
      pipeline.push({ $unionWith: adminAccess });
    }

    if (managerAccess) {
      pipeline.push({ $unionWith: managerAccess });
    }

    if (supervisorAccess) {
      pipeline.push({ $unionWith: supervisorAccess });
    }

    if (gUserAccess) {
      pipeline.push({ $unionWith: gUserAccess });
    }

    if (tUserAccess) {
      pipeline.push({ $unionWith: tUserAccess });
    }

    pipeline.push({
      $facet: {
        result: [
          { $skip: skip },
          { $limit: pageSize },
          {
            $project: {
              _id: 1,
              orgId: 1,
              name: 1,
              email: 1,
              mobileNumber: 1,
              userType: 1,
              isActive: 1
            }
          }
        ],
        totalCount: [
          {
            $count: 'value'
          }
        ]
      }
    });

    pipeline.push({
      $project: {
        page: 1,
        pageSize: 1,
        totalCount: { $arrayElemAt: ['$totalCount.value', 0] },
        data: '$result',
      }
    })

    info.info(`inActiveUserList orgId:${orgId} pipeline:${JSON.stringify(pipeline)}`);

    const result = await collection.aggregate(pipeline).toArray();

    const data = {
      totalCount: result[0]?.totalCount || 0,
      list: result[0]?.data || [],
    };
    const response = generateResponse('userDocument fetched', 200, 'success', data)
    res.status(200).json(response);
    info.info(`inActiveUserList orgId:${orgId} data fetched`);
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Internal Server Error' });
    error.error(`inActiveUserList orgId:${orgId} fetching error ${err.message}`)
  }

};

export const divUserList = async (req: Request, res: Response) => {
  info.info(`divUserList fetching initiated `);
  info.info(`divUserList req.query ${JSON.stringify(req.query)}`);
  const { orgId } = req.query;
  if (!orgId) {
    error.error(`divUserList error: orgId missing`)
    return res.status(404).json(generateResponse("Id is missing", 404, "failed"))
  }
  try {
    const searchCriteria = req.query.query as string;

    let managerAccess: any = 0, supervisorAccess: any = 0, gUserAccess: any = 0, tUserAccess: any = 0;
    let divM: any = 0, divS: any = 0, gUser: any = 0, tUser: any = 0;

    if ((req as any).firebaseData.uid.includes("orgOwner")) {
      managerAccess = {
        coll: 'organisationManager',
        pipeline: [
          {
            $addFields: {
              'userType': 'Manager',
            }
          },
          {
            $match: {
              'orgId': orgId,
              'isDeleted': false,
              'isActive': true,
              $or: [
                { 'name': { $regex: new RegExp(searchCriteria, 'i') } },
              ]
            }
          },
        ]
      };
      supervisorAccess = {
        coll: 'organisationSupervisor',
        pipeline: [
          {
            $addFields: {
              'userType': 'Supervisor',
            }
          },
          {
            $match: {
              'orgId': orgId,
              'isDeleted': false,
              'isActive': true,
              $or: [
                { 'name': { $regex: new RegExp(searchCriteria, 'i') } },
              ]
            }
          },
        ]
      };
      gUserAccess = {
        coll: 'orgGodownUser',
        pipeline: [
          {
            $addFields: {
              'userType': 'Store',
            }
          },
          {
            $match: {
              'orgId': orgId,
              'isDeleted': false,
              'isActive': true,
              $or: [
                { 'name': { $regex: new RegExp(searchCriteria, 'i') } },
              ]
            }
          },
        ]
      };
      tUserAccess = {
        coll: 'transactionPointUser',
        pipeline: [
          {
            $addFields: {
              'userType': 'Pickup Counter',
            }
          },
          {
            $match: {
              'orgId': orgId,
              'isDeleted': false,
              'isActive': true,
              $or: [
                { 'name': { $regex: new RegExp(searchCriteria, 'i') } },
              ]
            }
          },
        ]
      };
    }
    else {
      const accessObj = (req as any).firebaseData.customClaims.access;
      for (let outerObj of accessObj) {
        if (outerObj.access) {
          for (let innerObj of outerObj.access) {
            if (outerObj.title == "UM" && innerObj.isAllowed == true) {
              switch (innerObj.title) {
                case "divM":
                  divM = 1;
                  break;
                case "divS":
                  divS = 1;
                  break;
                case "gUser":
                  gUser = 1;
                  break;
                case "tUser":
                  tUser = 1;
                  break;
                default:
                  break;
              }
            }
          }
        }
      }
      if (divM) {
        managerAccess = {
          coll: 'organisationManager',
          pipeline: [
            {
              $addFields: {
                'userType': 'Manager',
              }
            },
            {
              $match: {
                'orgId': orgId,
                'isDeleted': false,
                'isActive': true,
                $or: [
                  { 'name': { $regex: new RegExp(searchCriteria, 'i') } },
                ]
              }
            },
          ]
        };
      }
      if (divS) {
        supervisorAccess = {
          coll: 'organisationSupervisor',
          pipeline: [
            {
              $addFields: {
                'userType': 'Supervisor',
              }
            },
            {
              $match: {
                'orgId': orgId,
                'isDeleted': false,
                'isActive': true,
                $or: [
                  { 'name': { $regex: new RegExp(searchCriteria, 'i') } },
                ]
              }
            },
          ]
        };
      }
      if (gUser) {
        gUserAccess = {
          coll: 'orgGodownUser',
          pipeline: [
            {
              $addFields: {
                'userType': 'Store',
              }
            },
            {
              $match: {
                'orgId': orgId,
                'isDeleted': false,
                'isActive': true,
                $or: [
                  { 'name': { $regex: new RegExp(searchCriteria, 'i') } },
                ]
              }
            },
          ]
        };
      }
      if (tUser) {
        tUserAccess = {
          coll: 'transactionPointUser',
          pipeline: [
            {
              $addFields: {
                'userType': 'Pickup Counter',
              }
            },
            {
              $match: {
                'orgId': orgId,
                'isDeleted': false,
                'isActive': true,
                $or: [
                  { 'name': { $regex: new RegExp(searchCriteria, 'i') } },
                ]
              }
            },
          ]
        };
      }
    }

    let pipeline = [];
    pipeline.push({
      $match: {
        _id: null
      }
    });

    if (managerAccess) {
      pipeline.push({ $unionWith: managerAccess });
    }

    if (supervisorAccess) {
      pipeline.push({ $unionWith: supervisorAccess });
    }

    if (gUserAccess) {
      pipeline.push({ $unionWith: gUserAccess });
    }

    if (tUserAccess) {
      pipeline.push({ $unionWith: tUserAccess });
    }

    pipeline.push({
      $facet: {
        result: [
          {
            $project: {
              _id: 1,
              name: 1,
              mobileNumber: 1,
              email:1,
              userType: 1,
            }
          }
        ],
        totalCount: [
          {
            $count: 'value'
          }
        ]
      }
    });

    pipeline.push({
      $project: {
        data: '$result',
      }
    })

    info.info(`divUser orgId:${orgId} pipeline:${JSON.stringify(pipeline)}`);

    const result = await collection.aggregate(pipeline).toArray();

    const data = {
      totalCount: result[0]?.totalCount || 0,
      list: result[0]?.data || [],
    };
    info.info(`divUserList orgId:${orgId} data fetched`);
    const response = generateResponse('Data fetched...', 200, 'success', data)
    res.status(200).json(response);
  } catch (err: any) {
    error.error(`divUserList orgId:${orgId} fetching error:${err.message}`);
    res.status(500).json(generateResponse("Internal server error", 500, "failed"));
  }

};