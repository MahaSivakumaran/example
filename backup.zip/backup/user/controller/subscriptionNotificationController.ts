import { Request, Response } from "express";
import { info, error } from "../config/loggerConfig";
import { ApiFeatures } from "../utils/apiFeatures";
import { subNotification } from "../model/subscriptionNotificationModel";
import { getOwnerDetailsByOrgID } from "./orgOwnerController";
import { generateResponse } from "../utils/responseGenerate";
import { ObjectId } from "mongodb";


let collection: any;
export const subNotificationInstance = async () => {
  collection = await subNotification();
}

export async function verifyAndCreateNotification(orgId: any, isExpired: any) {
  info.info(
    `verifyAndCreateNotification initiated orgId:${JSON.stringify(
      orgId
    )} isExpired:${isExpired}`
  );
  try {
    const orgData = await collection
      .find(
        { orgId: { $in: orgId }, isExpired, isDeleted: false },
        { projection: { orgId: 1 } }
      )
      .toArray();
    let orgIds = orgData.map((id: any) => id.orgId);

    const userDetail = await getOwnerDetailsByOrgID(orgId);
    console.log("userDetail", userDetail);

    if (userDetail) {
      // if(newOrgIds.length != userDetail.length){
      //   error.error(`verifyAndCreateNotification initiated orgId:${JSON.stringify(orgId)} isExpired:${isExpired} error: newOrgIds.length != userDetail.length`);
      //   return false;
      // }
      let notificationData: {
        userId: string;
        orgId: string;
        isExpired: any;
        isViewed: boolean;
        isDeleted: boolean;
        createdAt: Date;
        updatedAt: Date;
      }[] = [];
      let newDataToInsert = userDetail.map(
        (data: { _id: string; orgId: string }) => {
          if (!orgIds.includes(data.orgId)) {
            notificationData.push({
              userId: data._id,
              orgId: data.orgId,
              isExpired: isExpired,
              isViewed: false,
              isDeleted: false,
              createdAt: new Date(),
              updatedAt: new Date(),
            });
          }
        }
      );

      try {
        if (notificationData.length > 0) {
          await collection.insertMany(notificationData);
        }

        info.info(
          `verifyAndCreateNotification isExpired:${isExpired} NewlyInsertedData:${JSON.stringify(
            newDataToInsert
          )}`
        );
        return userDetail;
      } catch (err: any) {
        error.error(
          `verifyAndCreateNotification userDetail:${JSON.stringify(
            userDetail
          )} isExpired:${isExpired} error:${err.message}`
        );
        return false;
      }
    } else {
      error.error(
        `getOwnerDetailsByOrgID orgId:${JSON.stringify(
          orgId
        )} isExpired:${isExpired} getOwnerDetailsByOrgID error`
      );
      return false;
    }
  } catch (err: any) {
    error.error(
      `verifyAndCreateNotification orgId:${JSON.stringify(
        orgId
      )} isExpired:${isExpired} error:${err.message}`
    );
    return false;
  }
}

export async function updateExpiredSubscription(orgId: any, isExpired: any) {
  info.info(
    `updateExpiredSubscription orgId:${JSON.stringify(orgId)} initiated`
  );
  try {
    const notificationData = await collection.find({
      orgId: { $in: orgId },
      isDeleted: false,
      isExpired: false,
    });
    if (!notificationData) {
      error.error(
        `updateExpiredSubscription orgId:${JSON.stringify(
          orgId
        )} error: No data found`
      );
      return false;
    }
    await collection.findOneAndUpdate(
      { orgId: { $in: orgId }, isDeleted: false, isExpired: false },
      {
        $set: {
          isExpired: true,
          updatedAt: new Date(),
        },
      }
    );
    info.info(
      `updateExpiredSubscription orgId:${JSON.stringify(orgId)} updated`
    );
    const userDetail = await getOwnerDetailsByOrgID(orgId);
    return userDetail;
  } catch (err: any) {
    error.error(
      `updateExpiredSubscription orgId:${JSON.stringify(orgId)} error:${
        err.message
      }`
    );
    return false;
  }
}

export async function displayNotification(req: Request, res: Response) {
  const {orgId} = req.query;
  if(!orgId){
    error.error(`displayNotification error: orgId missing`)
    res.status(404).json(generateResponse(`Org id is missing`,404,"failed"))
  }
  info.info(`displayNotification orgId:${orgId} initiated`);
  try{
    const notificationData = await collection.find({orgId, isDeleted: false}, { projection: {
      _id: 1,
      orgId: 1,
      isViewed: 1,
      isExpired: 1
    }}).toArray();
    if(notificationData.length > 0)
    {
      info.info(`displayNotification orgId:${orgId} fetchedData:${JSON.stringify(notificationData)}`);
      res.status(200).json(generateResponse("Data fetched successfully...", 200, "Success", notificationData));
    }
    else{
      info.info(`displayNotification orgId:${orgId} no data found`);
      res.status(200).json(generateResponse("No data found", 200, "Success"));
    }
  }
  catch(err: any){
    error.error(`displayNotification orgId:${orgId} error:${err.message}`);
    res.status(500).json(generateResponse("Internal server error", 500, "Failed"));
  }
}

export const viewedNotification = async (req: Request, res: Response) => {
  info.info(`viewedNotification initialized`);
  info.info(`viewedNotification query data : ${JSON.stringify(req.query)}`);
  const id = req.query.id
  if(!id){
    error.error(`viewedNotification error: id missing`)
  }
  const objectId = new ObjectId(id as string);
  const updatedData = {
    isViewed: true,
    updatedAt: new Date()
  }
  try {

    const data = await collection.findOne({ _id : objectId });
    if (!data) return res.status(404).json(generateResponse(`Document not found...`, 404, "failed"));
 
    
    await collection.findOneAndUpdate(
      { _id : objectId },
      { $set: updatedData }
    )
    info.info(`viewedNotification updation completed`)
    res.status(200).json(generateResponse(`Notification updated as viewed`, 200, "success"))
  } catch (err: any) {
    error.error(`viewedNotification err.message: ${err.message}`)
    res.status(500).json(generateResponse(`Internal server error`, 500, "failed"))
  }
}

export const deleteNotification = async (req: Request, res: Response) => {
  
  info.info(`deleteNotification initialized`);
  info.info(`deleteNotification query data : ${JSON.stringify(req.query)}`);
  const { orgId } = req.body;
    
  try {
    const data = collection.findOne({orgId, isDeleted: false});
    if (!data) return res.status(404).json(generateResponse(`Document not found..`, 404, "failed"));

     await collection.findOneAndUpdate(
      { orgId, isDeleted:false},
      { $set: {
        isDeleted: true,
        updatedAt: new Date()
      } }
    );
    info.info(`deleteNotification updation completed`)
    res.status(200).json(generateResponse(`Notification updated as deleted`, 200, "success"))
  } catch (err: any) {
    error.error(`deleteNotification err.message: ${err.message}`)
    res.status(500).json(generateResponse(err.message, 500, "failed"))
  }
}