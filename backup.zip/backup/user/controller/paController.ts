import { Request, Response } from "express";
import { info, error } from "../config/loggerConfig";
import { createProductAdmin } from "../model/paModel";
import { ApiFeatures } from "../utils/apiFeatures";
import { addUser } from "../utils/userCounts";
import { generateResponse } from "../utils/responseGenerate";
import { createUser, deleteUser, disableUser, enableUser, getUserAccess, updateUser, updateUserSelf } from "../firebase";
import { convertAccessForHotel } from "./userAccessController";

let collection: any;
export const paInstance = async () => {
  collection = await createProductAdmin()
}

// create new prod admin
export async function createPa(req: Request, res: Response,) {
  info.info(`createPa initiated`);
  info.info(`createPa reqParams:${JSON.stringify(req.body)}`);

  try {
    const { name, email, mobileNumber } = req.body;
    const id = await addUser('pa');
    req.body.uid = id;
    req.body.userType = "pa";
    const userData = {
      _id: id,
      name,
      email,
      mobileNumber,
      isActive: true,
      isDeleted: false,
      createdAt: new Date(),
      updatedAt: new Date(),

    }
    await createUser(req)
    .then(async()=>{
      info.info("Firebase user created");
      await collection.insertOne(userData);
      info.info(`createPA userData:${JSON.stringify(userData)}`);
      const response = generateResponse('Product Admin created successfully', 200, 'success')
      res.status(200).json(response);
    })
    .catch((err)=>{
      error.error(`firebase user not created error:${err.message}`);
      res.status(err.status).send({message: err.message});
     return;
      });
  }
  catch (err: any) {
    error.error(`createPa errorMessage:${err}`);
    res.status(500).json(generateResponse("Internal server error",500,"failed"));
  }
}
// Get all Product Admins 
export async function getAllPa(req: Request, res: Response) {


  info.info(`getAllPa initiated`);
  info.info(`getAllPa queryParams:${JSON.stringify(req.query)}`);

  try {
    if (collection) {
      const { query, page, sort ,sortBy, pageSize} = req.query;
      const queryHandler = new ApiFeatures(collection, query, page, sort,sortBy, pageSize);
      const data = await queryHandler.searchAndPaginate();

      info.info(`getAllPa fetchedData:${JSON.stringify(data)}`);
      const response = generateResponse('userDocument fetched successfully', 200, 'success', data)
      res.status(200).json(response);
    }
    else {
      const response = generateResponse('Bad request', 400, 'error')
      res.status(400).json(response);
    }
  } catch (err: any) {
    error.error(`createProductAdminDocument errorMessage:${err.message}`);
    res.status(500).json(generateResponse("Internal server error",500,"failed"));    
  }
}

//Get Prod Admin him self

export async function self(req: Request, res: Response) {

  info.info(`Self initiated`);
  info.info(`Self reqParams:${JSON.stringify(req.headers)}`);

  try {
    const userAgent = JSON.parse((req as any).headers['x-user-agent']);
    const id = userAgent.userId
    if (!id) {
      error.error(`self error: id missing`)
      return res.status(404).json(generateResponse("Id is missing",404,"failed"))
    }
    if (collection) {

      const projection = {
        _id: 1,
        name: 1,
        email: 1,
        mobileNumber: 1,
      };

      const user = await collection.findOne({ _id: id }, { projection });
      if (user) {
        info.info(`self data:${user}`);
        const response = generateResponse('userDocument created successfully', 200, 'success', user)
        res.status(200).json(response);
      } else {
        const response = generateResponse('usernot found', 404, 'error')
        res.status(404).json(response);
      }

    }
  } catch (err: any) {
    error.error(`getUserById errorMessage:${err.message}`);
    res.status(500).json(generateResponse("Internal server error",500,"failed"));
  }
}

// Get single admin details

export async function getOnePa(req: Request, res: Response) {

  info.info(`getOnePa initiated`);
  info.info(`getOnePa reqParams:${JSON.stringify(req.query)}`);

  try {
    if (collection) {
      const { id } = req.params;
      const projection = {
        _id: 1,
        name: 1,
        email: 1,
        mobileNumber: 1,
        isActive:1
      };

      const user = await collection.findOne({ _id: id }, { projection });
      if (user) {
        info.info(`getUserById document fetched successfully for id : ${id}`);
      await getUserAccess(id)
      .then(async(access) =>{
        (user as any).access  = await convertAccessForHotel(access);
      })
      .catch((err: any) =>{
        error.error(`getUserById access error:${err.message}`);
      });
        const response = generateResponse('userDocument found', 200, 'success', user)
        res.status(200).json(response);
      } else {
        const response = generateResponse('user not found', 404, 'error')
        res.status(404).json(response);
        error.error(`getOnePa error: user not found`)
      }

    }
  } catch (err: any) {
    error.error(`getOnePa errorMessage:${err.message}`);
    res.status(500).json(generateResponse("Internal server error",500,"failed"));
  }
}


//update admin details

export async function updatePa(req: Request, res: Response) {
  info.info(`updatePa initiated`);
  info.info(`updatePa reqParams:${JSON.stringify(req.query)}`);

  const id = req.params.id;
  const data = req.body;
  const name = data.name;
  const email = data.email;
  const mobileNumber = data.mobileNumber;
  data.userType = "pa";

  try {
     await updateUser(id,data)
      .then(async()=>{
        await collection.findOneAndUpdate({ _id: id }, {
          $set: { name, mobileNumber,email, updatedAt: new Date() }
        },
          {
            new: true
          });
      info.info(`updatePa completed for id : ${id}`);
          const response = generateResponse('userDocument updated successfully', 200, 'success')
          res.status(200).json(response);
      })
      .catch((err)=>{
        res.status(500).send({
          message: "Something went wrong",
          error: err
        });
        });
  } catch (err: any) {
    error.error(`updatePa error : ${err.message}`)
    res.status(500).json(generateResponse("Internal server error",500,"failed"));
  }
}

//delete an product admin
export async function deletePa(req: Request, res: Response) {
  info.info(`deletePa initiated`);
  info.info(`deletePa reqParams:${JSON.stringify(req.params)}`);
 
  const { id } = req.params;

  try {
    await deleteUser(id)
    .then(async()=>{
      info.info(`firebase user deleted`);
        await collection.findOneAndUpdate({ _id: id }, {
          $set: {
            isDeleted: true,
            updatedAt: new Date()
          }
        }, { new: true });
        info.info(`deletePa completed for id : ${id}`);
        const response = generateResponse('userDocument deleted successfully', 200, 'success')
        res.status(200).json(response);
    })
    .catch((err:any)=>{
      error.error(`deletePa firebase error:${err.message}`)
      res.status(500).send({
        success: false,
        message: "Something went wrong"
      });
    })
    
  } catch (err: any) {
    error.error(`deletePa error : ${err.message}`)
    res.status(500).json(generateResponse("Internal server error",500,"failed"));
  }
}

export async function selfEdit (req: Request, res: Response){
  
  try {
    info.info(`selfEdit initiated`);
    info.info(`selfEdit req.body: ${JSON.stringify(req.body)}`);
    
    const userAgent = JSON.parse((req as any).headers['x-user-agent']);
    const id = userAgent.userId
    const data = req.body
    const name = data.name;
    const email = data.email;
    const mobileNumber = data.mobileNumber;
    const updatedData = {
      name,
      mobileNumber,
      email,
      updatedAt: new Date()
    };
    await updateUserSelf(id, updatedData)
    .then(async ()=>{
      await collection.findOneAndUpdate({_id:id},{
        $set : updatedData
      });
    })
    .catch((err) =>{
      error.error(`PA selfEdit firebase error:${err}`);
      res.status(err.status).send({
        message: err.message
      });
      throw err;
    })

    info.info(`selfEdit completed id:${id} updatedData:${JSON.stringify(updatedData)}`);
    const response  = generateResponse("Edited successfully..",200,"success");
    res.status(200).json(response)
  } catch (err:any) {
    error.error(`selfEdit Error : ${err.message}`);
    const response  = generateResponse("Internal server error",500,"failed");
    res.status(500).json(response)
  }
}

export async function deactivatePa (req: Request, res: Response) {
  const id = req.params.id;
  try{
    info.info(`deactivatePa initiated userId:${id}`);
    await disableUser(id)
    .then(async()=>{
      await collection.findOneAndUpdate({_id:id}, {
        $set: {
          isActive: false,
          updatedAt: new Date()
        }
      },
      {
        new: true
      });
      info.info(`deactivatePa id:${id} completed`);
      res.status(200).send({
        success: true,
        message: "Product Admin Disabled successfully"
      })
    })
    .catch((err: any)=>{
      error.error(`deactivatePa id:${id} firebase error:${JSON.stringify(err)}`);
      res.status(err.status).send({message: err.message});
    })
  }
  catch(err: any){
    error.error(`deactivatePa id:${id} error:${err.message}`);
    res.status(400).send({
      success: false,
      message: err.message
    });
  }
}

export async function activatePa (req: Request, res: Response) {
  const id = req.params.id;
  try{
    info.info(`activatePa initiated userId:${id}`);
    await enableUser(id)
    .then(async()=>{
      await collection.findOneAndUpdate({_id:id}, {
        $set: {
          isActive: true,
          updatedAt: new Date()
        }
      },
      {
        new: true
      });
      info.info(`activatePa id:${id} completed`);
      res.status(200).send({
        success: true,
        message: "Product Admin enabled successfully"
      })
    })
    .catch((err: any)=>{
      error.error(`activatePa id:${id} firebase error:${JSON.stringify(err)}`);
      res.status(err.status).send({message: err.message});
    })
  }
  catch(err: any){
    error.error(`activatePa id:${id} error:${err.message}`);
    res.status(400).send({
      success: false,
      message: err.message
    });
  }
}
