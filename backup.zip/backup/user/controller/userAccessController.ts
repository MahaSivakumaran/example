import { Request, Response } from "express";

export async function createNewUserAccess(req: Request, res: Response) {
    let { type } = req.params;
    let access = [];
    switch (type) {
        case "productAdmin":
            access.push(
                [
                    {
                        title: "User Management",
                        access: [
                            {
                                title: "Product Admin",
                                isAllowed: 1
                            },
                            {
                                title: "Hotel Owner",
                                isAllowed: 1
                            },
                            {
                                title: "Hotel Admin",
                                isAllowed: 1
                            },
                            {
                                title: "Branch Manager",
                                isAllowed: 1
                            },
                            {
                                title: "Supervisor",
                                isAllowed: 1
                            },
                            {
                                title: "Store Manager",
                                isAllowed: 1
                            },
                            {
                                title: "Pickup Counter User",
                                isAllowed: 1
                            }
 
                        ]
                    },
                    {
                        title: "Subscription Plan Management",
                        isAllowed: 1
                    },
                    {
                        title: "Hotel Management",
                        access: [
                            {
                                title: "Add/Remove Hotels",
                                isAllowed: 1
                            },
                            {
                                title: "Change/Update Subscription Plans",
                                isAllowed: 1
                            }
 
                        ]
                    },
                ]
            );
            break;
        case "hotelAdmin":
            access.push(
                [
                    {
                        title: "User Management",
                        access: [
 
                            {
                                title: "Hotel Admin",
                                isAllowed: 1
                            },
                            {
                                title: "Branch Manager",
                                isAllowed: 1
                            },
                            {
                                title: "Supervisor",
                                isAllowed: 1
                            },
                            {
                                title: "Store Manager",
                                isAllowed: 1
                            },
                            {
                                title: "Pickup Counter User",
                                isAllowed: 1
                            }
 
                        ]
                    },
                    {
                        title: "Product Management",
                        isAllowed: 1
                    },
                    {
                        title: "Reports",
                        access: [
                            {
                                title: "Store",
                                isAllowed: 1
                            },
                            {
                                title: "Wastage",
                                isAllowed: 1
                            },
                            {
                                title: "Kitchen",
                                isAllowed: 1
                            }
                        ]
                    },
                    {
                        title: "Approval Management",
                        access: [
                            {
                                title: "Production Approval",
                                isAllowed: 1
                            },
                            {
                                title: "Order Approval",
                                isAllowed: 1
                            }
                        ]
                    },
                    {
                        title: "Inventory Management",
                        access: [
                            {
                                title: "Placing Market Orders",
                                isAllowed: 1
                            },
                            {
                                title: "Notifying Branches",
                                isAllowed: 1
                            },
                            {
                                title: "Alert Limit Setting",
                                isAllowed: 1
                            },
 
                        ]
                    },
                    {
                        title: "Branch Management",
                        access: [
                            {
                                title: "Making As main branch",
                                isAllowed: 1
                            },
                            {
                                title: "Add/Remove Branch",
                                isAllowed: 1
                            },
                            {
                                title: "Add/Remove Shift",
                                isAllowed: 1
                            }
 
                        ]
                    },
                    {
                        title: "Branch Works",
                        access: [
                            {
                                title: "Taking Orders",
                                isAllowed: 1
                            },
                            {
                                title: "Raising Demands",
                                isAllowed: 1
                            }
                        ]
                    },
                ]
            );
            break;
        case "branchManager":
            access.push(
                [
                    {
                        title: 'User Management',
                        access: [
                            {
                                title: "Branch Manager",
                                isAllowed: 1
                            },
                            {
                                title: "Supervisor",
                                isAllowed: 1
                            },
                            {
                                title: "Store Manager",
                                isAllowed: 1
                            },
                            {
                                title: "Pickup Counter User",
                                isAllowed: 1
                            }
                        ]
                    },
                    {
                        title: "Reports",
                        access: [
                            {
                                title: "Store",
                                isAllowed: 1
                            },
                            {
                                title: "Kitchen",
                                isAllowed: 1
                            },
                            {
                                title: "Wastage",
                                isAllowed: 1
                            }
                        ]
                    },
                    {
                        title: "Raising Demands",
                        isAllowed: 1
                    },
                    {
                        title: "Taking Orders",
                        isAllowed: 1
                    },
                ]
            );
            break;
        case "branchSupervisor":
            access.push(
                [
                    {
                        title: 'User Management',
                        access: [
                            {
                                title: "Branch Manager",
                                isAllowed: 1
                            },
                            {
                                title: "Supervisor",
                                isAllowed: 1
                            },
                            {
                                title: "Store Manager",
                                isAllowed: 1
                            },
                            {
                                title: "Pickup Counter User",
                                isAllowed: 1
                            }
                        ]
                    },
                    {
                        title: "Reports",
                        access: [
                            {
                                title: "Store",
                                isAllowed: 1
                            },
                            {
                                title: "Kitchen",
                                isAllowed: 1
                            },
                            {
                                title: "Wastage",
                                isAllowed: 1
                            }
                        ]
                    },
                    {
                        title: "Raising Demands",
                        isAllowed: 1
                    },
                    {
                        title: "Taking Orders",
                        isAllowed: 1
                    },
                ]
            );
            break;
        case "storeUser":
            access.push(
                [
                    {
                        title: 'Placing Market Orders',
                        isAllowed: 1
                    }
                ]
            );
            break;
    }
    res.status(200).send({
        success: true,
        userAccess: access
    })
}

async function hotelAccessFinder (acc: any) {
    switch(acc)
    {
        case "UM":
            return "User Management";
        case "PA":
            return "Product Admin";
        case "orgOwner":
            return "Hotel Owner";
        case "orgAdmin":
            return "Hotel Admin";
        case "divM":
            return "Branch Manager";
        case "divS":
            return "Supervisor";
        case "gUser":
            return "Store Manager";
        case "tUser":
            return "Pickup Counter User";
        case "SPM":
            return "Subscription Plan Management";
        case "OM":
            return "Hotel Management";
        case "ARO":
            return "Add/Remove Hotels";
        case "CUSP":
            return "Change/Update Subscription Plans";
        case "PM":
            return "Product Management";
        case "RM":
            return "Reports";
        case "godown":
            return "Store";
        case "waste":
            return "Wastage";
        case "workstation":
            return "Kitchen";
        case "AM":
            return "Approval Management";
        case "prodA":
            return "Production Approval";
        case "ordA":
            return "Order Approval";
        case "IM":
            return "Inventory Management";
        case "PMO":
            return "Placing Market Orders";
        case "ND":
            return "Notifying Branches";
        case "ALS":
            return "Alert Limit Setting";
        case "DM":
            return "Branch Management";
        case "MMD":
            return "Making As main branch";
        case "ARD":
            return "Add/Remove Branch";
        case "ARS":
            return "Add/Remove Shift";
        case "DW":
            return "Branch Works";
        case "TO":
            return "Taking Orders";
        case "RD":
            return "Raising Demands";
        default:
            console.log("error in accessfinder", acc);
            return false;          
    }
}

async function generalAccessFinder (acc: any) {
    switch(acc)
    {
        case "User Management":
            return "UM";
        case "Product Admin":
            return "PA";
        case "Hotel Owner":
            return "orgOwner";
        case "Hotel Admin":
            return "orgAdmin";
        case "Branch Manager":
            return "divM";
        case "Supervisor":
            return "divS";
        case "Store Manager":
            return "gUser";
        case "Pickup Counter User":
            return "tUser";
        case "Subscription Plan Management":
            return "SPM";
        case "Hotel Management":
            return "OM";
        case "Add/Remove Hotels":
            return "ARO";
        case "Change/Update Subscription Plans":
            return "CUSP";
        case "Product Management":
            return "PM";
        case "Reports":
            return "RM";
        case "Store":
            return "godown";
        case "Wastage":
            return "waste";
        case "Kitchen":
            return "workstation";
        case "Approval Management":
            return "AM";
        case "Production Approval":
            return "prodA";
        case "Order Approval":
            return "ordA";
        case "Inventory Management":
            return "IM";
        case "Placing Market Orders":
            return "PMO";
        case "Notifying Branches":
            return "ND";
        case "Alert Limit Setting":
            return "ALS";
        case "Branch Management":
            return "DM";
        case "Making As main branch":
            return "MMD";
        case "Add/Remove Branch":
            return "ARD";
        case "Add/Remove Shift":
            return "ARS";
        case "Branch Works":
            return "DW";
        case "Taking Orders":
            return "TO";
        case "Raising Demands":
            return "RD";
        default:
            console.log("error in generalaccessfinder", acc);
            return false;          
    }
}

export async function convertAccessForHotel (access: any) {
    if (access){
        let convertedAcc;
        for(let outerObj of access)
        {
            if(outerObj.access)
            {
                convertedAcc = await hotelAccessFinder(outerObj.title);
                outerObj.title = convertedAcc;
                for(let innerObj of outerObj.access )
                {
                    convertedAcc = await hotelAccessFinder(innerObj.title);
                    innerObj.title = convertedAcc;
                }
            }
            else{
                convertedAcc = await hotelAccessFinder(outerObj.title);
                outerObj.title = convertedAcc;
            }
        }
        return access;
    }
}

export async function convertAccessToGeneral (access: any) {
    if (access){
        let convertedAcc;
        for(let outerObj of access)
        {
            if(outerObj.access)
            {
                convertedAcc = await generalAccessFinder(outerObj.title);
                outerObj.title = convertedAcc;
                for(let innerObj of outerObj.access )
                {
                    convertedAcc = await generalAccessFinder(innerObj.title);
                    innerObj.title = convertedAcc;
                }
            }
            else{
                convertedAcc = await generalAccessFinder(outerObj.title);
                outerObj.title = convertedAcc;
            }
        }
        return access;
    }
}