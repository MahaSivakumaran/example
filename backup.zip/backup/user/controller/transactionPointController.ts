import { NextFunction, Request, Response } from "express";
import { info, error } from "../config/loggerConfig";
import { ApiFeatures } from "../utils/apiFeatures";
import { addUser } from "../utils/userCounts";
import { transactionPoint } from "../model/transactionPointModel";
import { generateResponse } from "../utils/responseGenerate";
import { createUser, deleteUser, disableUser, enableUser, getUserAccess, updateUser } from "../firebase";
import axios from 'axios';
const baseURL = process.env.BASE_URL;
const orgPort = process.env.ORG_PORT;

let collection: any;

export const tpInstance = async () => {
  collection = await transactionPoint();
}

export async function createTpUser(req: Request, res: Response,) {
  info.info(`createTpUser initiated`);
  info.info(`createTpUser req.body:${JSON.stringify(req.body)}`);

  try {

    const { name, email, mobileNumber, shifts, orgId, divId} = req.body;
    const id = await addUser('tUser');
    req.body.uid = id;
    req.body.userType = "tUser";
    let isMain = false;
    const userApiEndpoint = `http://${baseURL}:${orgPort}/api/div/checkMainDiv?id=${divId}`;
    const response = await axios.get(userApiEndpoint).then((resp: any) => {
      if(resp.divData)
      {
        if(resp.divData.isMain == true)
        {
          isMain = true;
        }
      }
    }).catch((err: any) => {
      error.error(`createTpUser checkMainDiv error${err.response.data.message}`);
      return res.status(500).json(generateResponse("Internal server error", 500, "failed"));
    });
    req.body.isMain = isMain;

    await createUser(req)
    .then(async()=>{
      info.info("Firebase user created");
      const userData = {
        _id: id,
        orgId,
        divId,
        name,
        email,
        mobileNumber,
        shifts,
        isActive: true,
        isDeleted: false,
        createdAt: new Date(),
        updatedAt: new Date()
  
      }
      await collection.insertOne(userData);
      info.info(`createOrgtransactionPoint document created ${JSON.stringify(userData)}`);
      const response = generateResponse('userDocument created successfully', 200, 'success')
      res.status(200).json(response);
    })
    .catch((err)=>{
      error.error(`firebase user not created error:${err.message}`);
      res.status(err.status).send({message: err.message});
     return;
      });
    
  } catch (err: any) {
    error.error(`createOrgtransactionPoint errorMessage:${err}`);
    res.status(500).json({ success: false, error: 'Internal Server Error' });
  }
}


export async function oneTpUser(req: Request, res: Response) {
  info.info(`oneTpUser initiated`);
  info.info(`oneTpUser reqParams:${JSON.stringify(req.params)}`);

  try {
    if (collection) {
      const { id } = req.params;
      const projection = {
        _id: 1,
        name: 1,
        mobileNumber: 1,
        shifts: 1,
        orgId:1,
        divId:1,
        isActive:1
      };

      const user = await collection.findOne({ _id: id }, { projection });
      if (user) {
        const axiosOrgResponse = await axios.get(`http://${baseURL}:${orgPort}/api/org/orgDetails/${user.orgId}`);
        const divData = await axios.get(`http://${baseURL}:${orgPort}/api/div/getDivShift/${user.divId}`);
        let filteredShifts;
        if(user.shifts){
           filteredShifts = divData.data.shift.filter((divShift:any) => user.shifts.includes(divShift.shiftId));
        }
        else{
          filteredShifts = null;
        }
        const userData = {
          user,
          orgDetails: axiosOrgResponse.data,
          divDetails: {
            divName: divData.data.divName,
            shifts: filteredShifts,
          },
      };
      
      await getUserAccess(id)
      .then((access) =>{
        (userData as any).access  = access;
      })
      .catch((err) =>{
        console.log(err);
        error.error(`oneTpUser access error:${err}`);
      });

        info.info(`oneTpUser document found successfully`);
        const response = generateResponse('userDocument found', 200, 'success', userData)
        res.status(200).json(response);
      } else {
        res.status(404).json({
          success: false,
          error: 'User not found',
        });
      }

    }
  } catch (err: any) {
    error.error(`getOneTpUser errorMessage:${err.message}`);
    res.status(500).json({ success: false, error: 'Internal Server Error' });

  }
}

export async function editTpUser(req: Request, res: Response) {
  info.info(`editTpUser initiated`);
  info.info(`editTpUser req.params:${JSON.stringify(req.params)}`);

  const { id } = req.params;
  const data = req.body
  const name = data.name;
  const shifts = data.shifts;
  const email = data.email;
  const mobileNumber = data.mobileNumber;
  const divId = data.divId;
  data.userType = "tUser";
  const updatedData = {
    name,
    email,
    mobileNumber,
    divId,
    shifts,
    updatedAt: new Date()
  };
  try {
    await updateUser(id,data)
    .then(async()=>{
      await collection.findOneAndUpdate({ _id: id }, {
        $set: updatedData
      },
        {
          new: true
        })
        const response = generateResponse('userDocument updated successfully', 200, 'success')
        res.status(200).json(response);
    })
    .catch((err)=>{
      res.status(500).send({
        message: "Something went wrong",
        error: err
      });
      });
    
  } catch (error:any) {
    error.error(`editTpUser error : ${error.message}`)
    res.status(500).json({ success: false, error: 'Internal Server Error' });

  }
}

export async function removeTpUser(req: Request, res: Response) {
  info.info(`removeTpUser initiated`);
  info.info(`removeTpUser req.params:${JSON.stringify(req.params)}`);

  const { id } = req.params;
  try {
    await deleteUser(id)
    .then(async()=>{
      info.info(`firebase user deleted`);
      await collection.findOneAndUpdate({ _id: id }, {
        $set: {
          isDeleted: true,
          updatedAt: new Date()
        }
      }, { new: true });
    info.info(`removeTpUser completed for the Id ${id}`);
      const response = generateResponse('userDocument deleted successfully', 200, 'success')
      res.status(200).json(response);
    })
    .catch((err)=>{
      error.error(`deletePa firebase error:${err}`)
      res.status(500).send({
        success: false,
        message: "Something went wrong"
      });
    })
    
  } catch (error:any) {
    res.status(500).json({ success: false, error: 'Internal Server Error' });

  }
}


export async function getAllTpusers(req: Request, res: Response) {
  info.info(`getAllTpusers getAll initiated`);
  info.info(`getAllTpusers req.query:${JSON.stringify(req.query)}`);

  try {
    if (collection) {
      const { query, page, sort, sortBy, pageSize } = req.query;
      const queryHandler = new ApiFeatures(collection, query, page, sort, sortBy, pageSize);
      const userList = await queryHandler.searchAndPaginate();

      if (userList && userList.list && Array.isArray(userList.list)) {
        const ids  = userList.list.map((user: any) => user.orgId);    
        
        const orgDetailsResponse = await axios.post(`http://${baseURL}:${orgPort}/api/org/details`,{ids})        
        const orgDetailsMap = new Map(orgDetailsResponse.data.map((org: any) => [org._id, org]));
        const enrichedUserList = userList.list.map((user, index) => ({
          ...user,
          orgDetails: orgDetailsMap.get(user.orgId)
        }));
        if (userList) {
          const response = generateResponse('userDocument fetched successfully', 200, 'success', {
            ...userList,
            list: enrichedUserList,
          });
          res.status(200).json(response);
        } else {
          const response = generateResponse('invalid request', 404, 'error', userList);
          res.status(400).json(response);
        }
      }
    }
  } catch (err: any) {
    error.error(`getAllTpusers errorMessage:${err.message}`);
    res.status(500).json({ success: false, error: 'Internal Server Error' });
  }
}

export async function deactivateTpUser (req: Request, res: Response) {
  const id = req.params.id;
  try{
    info.info(`deactivateTpUser initiated userId:${id}`);
    if(!id){
      error.error(`deactivateTpUser error: Id missing`)
      return res.status(400).send({
        success: false,
        message: "User id is missing"
      });
    }
    await disableUser(id)
    .then(async()=>{
      await collection.findOneAndUpdate({_id:id}, {
        $set: {
          isActive: false,
          updatedAt: new Date()
        }
      },
      {
        new: true
      });
      info.info(`deactivateTpUser id:${id} completed`);
      res.status(200).send({
        success: true,
        message: "Pickup Counter user Disabled successfully"
      })
    })
    .catch((err: any)=>{
      error.error(`deactivateTpUser id:${id} firebase error:${JSON.stringify(err)}`);
      res.status(err.status).send({message: err.message});
    })
  }
  catch(err: any){
    error.error(`deactivateTpUser id:${id} error:${err.message}`);
    res.status(400).send({
      success: false,
      message: err.message
    });
  }
}

export async function activateTpUser (req: Request, res: Response) {
  const id = req.params.id;
  try{
    info.info(`activateTpUser initiated userId:${id}`);
    await enableUser(id)
    .then(async()=>{
      await collection.findOneAndUpdate({_id:id}, {
        $set: {
          isActive: true,
          updatedAt: new Date()
        }
      },
      {
        new: true
      });
      info.info(`activateTpUser id:${id} completed`);
      res.status(200).send({
        success: true,
        message: "Pickup Counter user enabled successfully"
      })
    })
    .catch((err: any)=>{
      error.error(`activateTpUser id:${id} firebase error:${JSON.stringify(err)}`);
      res.status(err.status).send({message: err.message});
    })
  }
  catch(err: any){
    error.error(`activateTpUser id:${id} error:${err.message}`);
    res.status(400).send({
      success: false,
      message: err.message
    });
  }
}


export const TPUserList = async (req: Request, res: Response) => {
  info.info(`TPUserList initiated`);
  info.info(`TPUserList queryParams: ${JSON.stringify(req.query)}`);
  
  const {orgId,page,pageSize, query}= req.query
  if(!orgId || orgId === ""){
    error.error(`TPUserList error: orgId is missing`);
    return res.status(400).json(generateResponse(`orgId is missing`,400,`failed`))
  }
  const currentPage = parseInt(page as string, 10) || 1;
  const page_Size = parseInt(pageSize as string, 10) || 10;
  const filter: {
    orgId: any ;
    isDeleted: boolean;
    isActive: boolean;
    name?: RegExp; 
  } = {
    orgId,
    isDeleted: false,
    isActive: true
  };

  if (query) {
    filter.name = new RegExp(query as string, 'i');
  }
  try {
    const pipeline = [
      { $match: filter }, 
      {
        $facet: {
          totalCount: [ 
            { $count: "count" }
          ],
          data: [ 
            { $skip: (currentPage - 1) * page_Size },
            { $limit: page_Size },
            { $project: { name: 1, mobileNumber: 1 } } 
          ]
        }
      },
      {
        $project: {
          count: { $arrayElemAt: ["$totalCount.count", 0] }, 
          data: 1 
        }
      }
    ];
    info.info(`TPUserList pipeLine :${JSON.stringify(pipeline)}`)
    const result = await collection.aggregate(pipeline).toArray();

    if (result.length > 0) {
      const responseData = {
        count: result[0].count, 
        data: result[0].data
      };

      if (responseData.data.length === 0) {
        res.status(404).json(generateResponse(`No data found.`, 404, "not found"));
      } else {
      info.info(`TPUserList data fetching completed`);
        res.status(200).json(generateResponse(`Data fetched.`, 200, "success", [responseData]));
      }
    } else {
      res.status(404).json(generateResponse(`No data found.`, 404, "not found"));
    }
  } catch (err: any) {
    error.error(`TPUserList error: ${err.message}`)
    res.status(500).json(generateResponse(`Internal server error.`, 500, "failed"));
  }
};


export async function TPUsersDetails(req: Request, res: Response) {
  info.info(`TPUsersDetails initiated`);
  info.info(`TPUsersDetails reqParams:${JSON.stringify(req.params)}`);

  try {
    if (collection) {
      const { orgId } = req.params;
      const page = parseInt(req.query.page as string) || 1; 
      const limit = parseInt(req.query.limit as string) || 10; 
      const query = req.query.query || '';
      const searchFilter = {
        orgId,
        isDeleted: false,
        isActive: true,
        $or: [
          { name: { $regex: query, $options: 'i' } },
          { email: { $regex: query, $options: 'i' } },
          { mobileNumber: { $regex: query, $options: 'i' } }
        ]
      };
      const projection = {
        _id: 1,
        name: 1,
        email: 1,
        mobileNumber: 1,
        orgId: 1,
      };

      const skip = (page - 1) * limit;
      const users = await collection.find(searchFilter, { projection })
      .skip(skip)
      .limit(limit)
      .toArray();
      const response = generateResponse('userDocument found', 200, 'success', users);
      res.status(200).json(response);
      info.info(`TPUsersDetails data:${JSON.stringify(users)}`)
    }
  } catch (err: any) {
    error.error(`getUserById errorMessage:${err.message}`);
    res.status(500).json(generateResponse("Internal server error",500,"failed"));
  }
}