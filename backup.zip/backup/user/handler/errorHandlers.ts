import { error } from "../config/loggerConfig";
import { NextFunction, Request, Response } from 'express';


export function handleAuthError(err:any) 
{
  console.log("handleAuthError error functions called")
  switch (err.code) 
    {
    case 'auth/email-already-exists':
      error.error('userCreation firebase error:Email already exist');
      return { status: 409, message: 'Email is already exist.' };

    case 'auth/invalid-email':
      error.error('userCreation firebase error:Invalid email address');
      return { status: 400, message: 'Invalid email address' };

    case 'auth/user-not-found':
      error.error('userCreation firebase error:User not found');
      return { status: 404, message: 'User not found' };

    case 'auth/wrong-password':
      error.error('userCreation firebase error:Invalid password');
      return { status: 401, message: 'Invalid password' };

    case 'auth/weak-password':
      error.error('userCreation firebase error:Password too weak');
      return { status: 400, message: 'Password is too weak' };

    default:
      error.error('userCreation firebase error:Internal server error');
      console.log(err);
      return { status: 500, message: err.message };
  }
}

export function handleSetCustomUserClaimsError(err:any) 
{
  console.log("handleSetCustomUserClaims error function called")
  switch (err.code) 
    {
    case 'auth/user-token-expired':
      error.error('userCreation setCustomerClaims firebase error:User token has expired');
      return { status: 401, message: 'User token has expired' };

    case 'auth/user-not-found':
      error.error('userCreation setCustomerClaims firebase error:User not found');
      return { status: 404, message: 'User not found' };

    case 'auth/invalid-argument':
      error.error('userCreation setCustomerClaims firebase error:Invalid arguments');
      return { status: 400, message: 'Invalid argument: Check your request parameters' };

    case 'auth/insufficient-permission':
      error.error('userCreation setCustomerClaims firebase error:Insufficient permissions');
      return { status: 403, message: 'Insufficient permissions to perform this action' };

    default:
      error.error(`userCreation setCustomerClaims firebase error:Internal server error`);
      return { status: 500, message: err.message };
  }
}
